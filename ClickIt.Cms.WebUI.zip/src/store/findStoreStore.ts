import { create } from 'zustand';
import { devtools } from 'zustand/middleware';

interface FindStoreStore {
    selectedStoreId: string | null;
    setSelectedStoreId: (storeId: string | null) => void;
    resetSelectedStoreId: () => void;
    resetStore: () => void;
}

export const useFindStoreStore = create<FindStoreStore>()(devtools((set, get) => ({
    selectedStoreId: null,

    setSelectedStoreId: (storeId: string | null) => set({ selectedStoreId: storeId }),

    resetSelectedStoreId: () => set({ selectedStoreId: null }),

    resetStore: () => {
        get().resetSelectedStoreId();
    }

})));