import type { ReactNode } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';

import { useProfile } from '@/hooks/useProfile';
import { useAuthStore } from '@/store/authStore';


type RequireAuthProps = {
    roles?: string[];
    redirectTo?: string;
    forbiddenTo?: string;
    fallback?: ReactNode;
    children?: ReactNode;
};


export const RequireAuth = ( {
    redirectTo = '/login',
    fallback = null,
    children,
}: RequireAuthProps ) => {

    const user = useAuthStore( (s) => s.user );
    const location = useLocation();

    // runs /me, syncs Zustand; React Query v5-safe (no onSuccess)
    const { isLoading, isFetching } = useProfile();
    const loading = isLoading || isFetching;

    const isRouteContext = children == null;

    if (loading) {
        // hold UI until we know if session is valid
        return <p>Loading...</p>; // replace with spinner if you want
    }

    // Not authenticated
    if (! user) {
        if (isRouteContext) {
            return <Navigate to={redirectTo} replace state={{ from: location }} />;
        }

        // Used inside components → show fallback or nothing
        return <>{fallback}</>;
    }

    // Route context → render nested routes; Component context → render children
    return isRouteContext ? <Outlet /> : <>{children}</>;
};


export default RequireAuth;
