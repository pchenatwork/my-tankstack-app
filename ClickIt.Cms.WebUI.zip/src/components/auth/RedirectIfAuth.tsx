// src/components/auth/RedirectIfAuth.tsx
import type { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';
import { useProfile } from '@/hooks/useProfile';

type RedirectIfAuthProps = {
    redirectTo?: string;
    fallback?: ReactNode;
    children: ReactNode;
};

export const RedirectIfAuth = ({ redirectTo = '/overview', fallback = null, children }: RedirectIfAuthProps) => {
    const user = useAuthStore((s) => s.user);
    const location = useLocation();

    const { isLoading, isFetching } = useProfile();
    const loading = isLoading || isFetching;

    if (loading) {
        return <>{fallback ?? null}</>;
    }

    if (user) {
        return <Navigate to={redirectTo} replace state={{ from: location }} />;
    }

    return <>{children}</>;
};

export default RedirectIfAuth;
