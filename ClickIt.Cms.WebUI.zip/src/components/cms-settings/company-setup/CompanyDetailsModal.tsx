import { Modal } from 'antd';
import React from 'react';

import type { Company } from '@/types/company';
import { getImagePath } from '@/utils';

interface CompanyDetailsModalProps {
    company: Company | null;
    open: boolean;
    onClose: () => void;
    onEdit?: (company: Company) => void;
}

const CompanyDetailsModal: React.FC<CompanyDetailsModalProps> = ({ company, open, onClose, onEdit }) => {
    if (!company) return null;

    // Format City/State/Zip as "City, State, Zip"
    const formatCityStateZip = () => {
        const parts: string[] = [];
        if (company.city) parts.push(company.city);
        if (company.state) parts.push(company.state);
        if (company.zip) parts.push(company.zip);
        
        if (parts.length === 0) return 'N/A';
     
        return parts.join(', ');
    };

    const handleEdit = (e: React.MouseEvent<HTMLAnchorElement>) => {
        e.preventDefault();
        if (company && onEdit) {
            onEdit(company);
            onClose();
        }
    };

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            width={600}
            closeIcon={<span className="text-xl text-gray-500">✕</span>}
            title={
                <div className="flex items-center gap-2 border-b border-gray-200 pb-2 text-xl font-semibold text-gray-700">
                    <img src={getImagePath('icons/icon-company.png')} alt="Company" width={24} />
                    <span>Company Details</span>
                </div>
            }
        >
            <div className="mt-4 rounded-lg border border-gray-300 bg-gray-100 p-6">
                <h2 className="mb-6 text-xl font-semibold text-gray-700">{company.name}</h2>

                <div className="grid grid-cols-[180px_1fr] gap-y-4 text-base">
                    <span className="text-gray-500">Address:</span>
                    <span className="font-medium text-gray-800">
                        {company.address1 || 'N/A'}
                    </span>

                    <span className="text-gray-500">City/State/Zip:</span>
                    <span className="font-medium text-gray-800">{formatCityStateZip()}</span>

                    <span className="text-gray-500">Country:</span>
                    <span className="font-medium text-gray-800">{company.country || 'N/A'}</span>

                    <span className="text-gray-500">CMS Manager Name:</span>
                    <span className="font-medium text-gray-800">{company.cmsManager || 'N/A'}</span>

                    <span className="text-gray-500">Phone #:</span>
                    <span className="font-medium text-gray-800">{company.phone || 'N/A'}</span>

                    <span className="text-gray-500">Fax:</span>
                    <span className="font-medium text-gray-800">{company.fax || 'N/A'}</span>

                    <span className="text-gray-500">Company URL:</span>
                    <span className="font-medium text-gray-800">
                        {company.companyUrl ? (
                            <a href={company.companyUrl} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline">
                                {company.companyUrl}
                            </a>
                        ) : (
                            'N/A'
                        )}
                    </span>
                </div>
            </div>

            <div className="mt-6 text-center text-base text-gray-500">
                Want to make changes?{' '}
                <a href="#" className="text-blue-500 hover:underline" onClick={handleEdit}>
                    Edit Company
                </a>
            </div>
        </Modal>
    );
};

export default CompanyDetailsModal;

