import { CloseOutlined, InboxOutlined } from '@ant-design/icons';
import { Button, Checkbox, Form, Input, Modal, Switch, Upload } from 'antd';
import type { UploadFile } from 'antd';
import React, { useEffect, useState } from 'react';

import type { Company } from '@/types/company';
import { getImagePath } from '@/utils';

import styles from './CompanyEditModal.module.scss';

type Mode = 'add' | 'edit';
type TabType = 'company-info' | 'email-settings' | 'alert-settings' | 'external-links';

const TAB_ORDER: TabType[] = ['company-info', 'email-settings', 'alert-settings', 'external-links'];

export interface CompanyFormValues {
    name: string;
    companyLogo?: string;
    cmsManager: string;
    companyUrl?: string;
    phone?: string;
    fax?: string;
    address1: string;
    address2?: string;
    city: string;
    state: string;
    zip: string;
    country: string;
    enableEmails?: boolean;
    emailServer?: string;
    emailAccount?: string;
    emailPassword?: string;
    useCustomPort?: boolean;
    customPortNumber?: number;
    useTlsSsl?: boolean;
    notifications?: string[];
}

interface CompanyEditModalProps {
    open: boolean;
    mode: Mode;
    initialCompany?: Company | null;
    onCancel: () => void;
    onSubmit: (values: CompanyFormValues) => void;
}

const { Dragger } = Upload;

const NOTIFICATION_TYPES = [
    'Analytics Events',
    'POS Data Events',
    'Panic Alert',
    'System Log Warning',
    'Contact Trigger Event',
    'Critical System Log',
    'Event Sequence',
    'System Log Info',
    'Motion Event',
    'Video Loss Event',
];

const CompanyEditModal: React.FC<CompanyEditModalProps> = ({ open, mode, initialCompany, onCancel, onSubmit }) => {
    const [form] = Form.useForm<CompanyFormValues>();
    const [activeTab, setActiveTab] = useState<TabType>('company-info');
    const [completedTabs, setCompletedTabs] = useState<Set<TabType>>(new Set());
    const [fileList, setFileList] = useState<UploadFile[]>([]);
    const [enableEmails, setEnableEmails] = useState(false);
    const [selectedNotifications, setSelectedNotifications] = useState<string[]>([]);

    useEffect(() => {
        if (open) {
            const enableEmailsValue = initialCompany?.emailServer ? true : false;
            setEnableEmails(enableEmailsValue);
            
            form.setFieldsValue({
                name: initialCompany?.name || '',
                cmsManager: initialCompany?.cmsManager || '',
                companyUrl: initialCompany?.companyUrl || '',
                phone: initialCompany?.phone || '',
                fax: initialCompany?.fax || '',
                address1: initialCompany?.address1 || '',
                address2: initialCompany?.address2 || '',
                city: initialCompany?.city || '',
                state: initialCompany?.state || '',
                zip: initialCompany?.zip || '',
                country: initialCompany?.country || '',
                enableEmails: enableEmailsValue,
                emailServer: initialCompany?.emailServer || '',
                emailAccount: initialCompany?.emailAccount || '',
                emailPassword: initialCompany?.emailPassword || '',
                useCustomPort: initialCompany?.customPortNumber ? true : false,
                customPortNumber: initialCompany?.customPortNumber || 25,
                useTlsSsl: false, // Default value, can be updated if needed
            });
            setFileList([]);

            // TODO: Initialize notifications - load from company data when available 
            setSelectedNotifications([]);
        } else {
            // Don't call form.resetFields() when modal is closed to avoid warning
            // The form will be reset when the modal opens next time via setFieldsValue
            setActiveTab('company-info');
            setCompletedTabs(new Set());
            setFileList([]);
        }
    }, [open, initialCompany, form]);

    const validateTab = async (tab: TabType): Promise<boolean> => {
        switch (tab) {
            case 'company-info':
                try {
                    await form.validateFields(['company', 'cmsManager', 'address1', 'city', 'state', 'zip', 'country']);
                    return true;
                } catch {
                    return false;
                }
            case 'email-settings':
                // Email settings validation - can be added later
                return true;
            case 'alert-settings':
                // Alert settings validation - can be added later
                return true;
            case 'external-links':
                // External links validation - can be added later
                return true;
            default:
                return true;
        }
    };

    const handleTabClick = async (targetTab: TabType) => {
        const currentTabIndex = TAB_ORDER.indexOf(activeTab);
        const targetTabIndex = TAB_ORDER.indexOf(targetTab);

        // Allow going back to previous tabs
        if (targetTabIndex < currentTabIndex) {
            setActiveTab(targetTab);
            return;
        }

        // If trying to move forward, validate current tab first
        if (targetTabIndex > currentTabIndex) {
            const isValid = await validateTab(activeTab);
            if (!isValid) {
                // Focus on first error field
                const fields = form.getFieldsError();
                const firstError = fields.find((field) => field.errors.length > 0);
                if (firstError) {
                    form.scrollToField(firstError.name[0] as string);
                }
                return;
            }

            // Mark current tab as completed
            setCompletedTabs((prev) => new Set(prev).add(activeTab));
        }

        // Allow moving to next tab or staying on current
        if (targetTabIndex <= currentTabIndex + 1) {
            setActiveTab(targetTab);
        }
    };

    const handleOk = async () => {
        // Validate current tab first
        const isValid = await validateTab(activeTab);
        if (!isValid) {
            const fields = form.getFieldsError();
            const firstError = fields.find((field) => field.errors.length > 0);
            if (firstError) {
                form.scrollToField(firstError.name[0] as string);
            }
            return;
        }

        // Validate all tabs before submitting
        for (const tab of TAB_ORDER) {
            const tabValid = await validateTab(tab);
            if (!tabValid) {
                // Switch to first invalid tab
                setActiveTab(tab);
                const fields = form.getFieldsError();
                const firstError = fields.find((field) => field.errors.length > 0);
                if (firstError) {
                    form.scrollToField(firstError.name[0] as string);
                }
                return;
            }
        }

        // All tabs valid, submit
        form.validateFields().then((values) => {
            onSubmit(values);
        });
    };

    const handleUploadChange = (info: any) => {
        setFileList(info.fileList);
        // TODO: Handle file upload
    };

    const renderCompanyInfoTab = () => (
        <>
            <div className={styles['section-title']}>Company Info</div>
            <div className={styles['section-card']}>
                <div className={styles['company-info-grid']}>
                    <Form.Item
                        label="Company:"
                        name="name"
                        rules={[{ required: true, message: 'Please enter a company name' }]}
                        className={styles['grid-left-1']}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label="CMS Manager Name:"
                        name="cmsManager"
                        rules={[{ required: true, message: 'Please enter CMS Manager Name' }]}
                        className={styles['grid-right-1']}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item label="Upload Logo:" name="companyLogo" className={styles['grid-left-2']}>
                        <Dragger
                            fileList={fileList}
                            onChange={handleUploadChange}
                            beforeUpload={() => false}
                            multiple={false}
                            accept="image/*"
                            className={styles['upload-area']}
                        >
                            <p className="ant-upload-drag-icon" style={{ fontSize: '48px', color: '#0168a7' }}>
                                <InboxOutlined style={{ fontSize: '48px' }} />
                            </p>
                            <p className="ant-upload-text">Click or drag file to this area to upload</p>
                        </Dragger>
                    </Form.Item>

                    <Form.Item label="Company URL:" name="companyUrl" className={styles['grid-right-2']}>
                        <Input />
                    </Form.Item>

                    <Form.Item label="Phone #:" name="phone" className={styles['grid-right-3']}>
                        <Input />
                    </Form.Item>

                    <Form.Item label="Fax:" name="fax" className={styles['grid-right-4']}>
                        <Input />
                    </Form.Item>
                </div>
            </div>

            <div className={styles['section-card']}>
                <div className={styles['section-title']}>Corporate Address</div>
                <div className={styles['company-info-grid']}>
                    <Form.Item
                        label="Address Line 1:"
                        name="address1"
                        rules={[{ required: true, message: 'Please enter Address Line 1' }]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item label="Address Line 2:" name="address2">
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label="City:"
                        name="city"
                        rules={[{ required: true, message: 'Please enter city' }]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label="State/Province/Region:"
                        name="state"
                        rules={[{ required: true, message: 'Please enter state/province/region' }]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label="Zip Code/Postal Code:"
                        name="zip"
                        rules={[{ required: true, message: 'Please enter zip code/postal code' }]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label="Country:"
                        name="country"
                        rules={[{ required: true, message: 'Please enter country' }]}
                    >
                        <Input />
                    </Form.Item>
                </div>
            </div>
        </>
    );

    const handleSelectAllNotifications = (checked: boolean) => {
        if (checked) {
            const allNotifications = [...NOTIFICATION_TYPES];
            setSelectedNotifications(allNotifications);
            form.setFieldValue('notifications', allNotifications);
        } else {
            setSelectedNotifications([]);
            form.setFieldValue('notifications', []);
        }
    };

    const handleNotificationChange = (notification: string, checked: boolean) => {
        let updatedNotifications: string[];
        if (checked) {
            updatedNotifications = [...selectedNotifications, notification];
        } else {
            updatedNotifications = selectedNotifications.filter((n) => n !== notification);
        }
        setSelectedNotifications(updatedNotifications);
        form.setFieldValue('notifications', updatedNotifications);
    };

    const renderEmailSettingsTab = () => (
        <>
            <div className={styles['section-title']}>Email Settings</div>
            <div className={styles['section-card']}>
                <div className={styles['toggle-row']}>
                    <span className={styles['toggle-label']}>Enable Emails</span>
                    <Switch
                        checked={enableEmails}
                        onChange={(checked) => {
                            setEnableEmails(checked);
                            form.setFieldValue('enableEmails', checked);
                            if (!checked) {
                                // Clear email fields when disabled
                                form.setFieldsValue({
                                    emailServer: '',
                                    emailAccount: '',
                                    emailPassword: '',
                                    useCustomPort: false,
                                    customPortNumber: 25,
                                    useTlsSsl: false,
                                });
                            }
                        }}
                    />
                    <span className={styles['toggle-status']}>{enableEmails ? 'On' : 'Off'}</span>
                </div>

                {enableEmails && (
                    <div className={styles['email-settings-grid']}>
                        <Form.Item
                            label="Email Server:"
                            name="emailServer"
                            rules={[{ required: true, message: 'Please enter Email Server' }]}
                            className={styles['email-grid-left-1']}
                        >
                            <Input />
                        </Form.Item>

                        <Form.Item label="Email Account:" name="emailAccount" className={styles['email-grid-left-2']}>
                            <Input autoComplete="off" />
                        </Form.Item>

                        <Form.Item label="Email Password:" name="emailPassword" className={styles['email-grid-right-1']}>
                            <Input.Password autoComplete="new-password" />
                        </Form.Item>

                        <Form.Item className={styles['email-grid-left-3']}>
                            <div className={styles['custom-port-row']}>
                                <Form.Item name="useCustomPort" valuePropName="checked" noStyle>
                                    <Checkbox>Use Custom Port</Checkbox>
                                </Form.Item>
                                <Form.Item
                                    noStyle
                                    shouldUpdate={(prevValues, currentValues) =>
                                        prevValues.useCustomPort !== currentValues.useCustomPort
                                    }
                                >
                                    {({ getFieldValue }) =>
                                        getFieldValue('useCustomPort') ? (
                                            <Form.Item name="customPortNumber" noStyle style={{ marginLeft: 12 }}>
                                                <Input type="number" className={styles['port-number-input']} />
                                            </Form.Item>
                                        ) : null
                                    }
                                </Form.Item>
                            </div>
                        </Form.Item>

                        <Form.Item name="useTlsSsl" valuePropName="checked" className={styles['email-grid-left-4']}>
                            <Checkbox>Use TLS/SSL</Checkbox>
                        </Form.Item>
                    </div>
                )}
            </div>

            {enableEmails && (
                <>
                    <div className={styles['section-title']}>
                        Notifications
                        <Checkbox
                            checked={selectedNotifications.length === NOTIFICATION_TYPES.length}
                            indeterminate={
                                selectedNotifications.length > 0 &&
                                selectedNotifications.length < NOTIFICATION_TYPES.length
                            }
                            onChange={(e) => handleSelectAllNotifications(e.target.checked)}
                            className={styles['select-all-checkbox']}
                        >
                            Select All
                        </Checkbox>
                    </div>
                    <div className={styles['section-card']}>

                    <div className={styles['notifications-grid']}>
                        {NOTIFICATION_TYPES.map((notification) => (
                            <Checkbox
                                key={notification}
                                checked={selectedNotifications.includes(notification)}
                                onChange={(e) => handleNotificationChange(notification, e.target.checked)}
                            >
                                {notification}
                            </Checkbox>
                        ))}
                    </div>
                    </div>
                </>
            )}
        </>
    );

    const renderAlertSettingsTab = () => (
        <div className={styles['section-card']}>
            <div className={styles['section-title']}>Alert Settings</div>
            <div className={styles['empty-message']}>
                <p>Alert Settings configuration coming soon.</p>
            </div>
        </div>
    );

    const renderExternalLinksTab = () => (
        <div className={styles['section-card']}>
            <div className={styles['section-title']}>External Links</div>
            <div className={styles['empty-message']}>
                <p>External Links configuration coming soon.</p>
            </div>
        </div>
    );

    return (
        <Modal
            open={open}
            onCancel={onCancel}
            footer={null}
            width="90%"
            style={{ maxWidth: 900 }}
            closeIcon={<CloseOutlined />}
            className={styles.modal}
            destroyOnHidden
        >
            <div className={styles.header}>
                <div className={styles['title-row']}>
                    <div className={styles.title}>Company Setup</div>
                </div>
            </div>

            <div className={styles.tabs}>
                <div className={styles['tab-row']}>
                    {TAB_ORDER.map((tab) => {
                        const currentTabIndex = TAB_ORDER.indexOf(activeTab);
                        const tabIndex = TAB_ORDER.indexOf(tab);
                        const isActive = activeTab === tab;
                        const isCompleted = completedTabs.has(tab);
                        const isDisabled = tabIndex > currentTabIndex + 1 && !isCompleted;

                        let tabLabel = '';
                        let tabIcon = '';
                        switch (tab) {
                            case 'company-info':
                                tabLabel = 'Company Info';
                                tabIcon = getImagePath('icons/icon-company.png');
                                break;
                            case 'email-settings':
                                tabLabel = 'Email Settings';
                                tabIcon = getImagePath('icons/icon-email.png');
                                break;
                            case 'alert-settings':
                                tabLabel = 'Alert Settings';
                                tabIcon = getImagePath('icons/icon-warning.png');
                                break;
                            case 'external-links':
                                tabLabel = 'External Links';
                                tabIcon = getImagePath('icons/icon-plus.png');
                                break;
                        }

                        return (
                            <button
                                key={tab}
                                type="button"
                                className={`${styles.tab} ${isActive ? styles['tab-active'] : ''}`}
                                onClick={() => handleTabClick(tab)}
                                disabled={isDisabled}
                            >
                                <img src={tabIcon} alt={tabLabel} className={styles['tab-icon']} />
                                <span className={styles['tab-label']}>{tabLabel}</span>
                            </button>
                        );
                    })}
                </div>
            </div>

            {open && (
                <Form form={form} layout="vertical">
                    {activeTab === 'company-info' && renderCompanyInfoTab()}
                    {activeTab === 'email-settings' && renderEmailSettingsTab()}
                    {activeTab === 'alert-settings' && renderAlertSettingsTab()}
                    {activeTab === 'external-links' && renderExternalLinksTab()}
                </Form>
            )}

            <div className={styles.footer}>
                <Button onClick={onCancel} size="large">
                    Cancel
                </Button>
                <Button type="primary" size="large" onClick={handleOk}>
                    {mode === 'edit' ? 'Save Changes' : 'Add Company'}
                </Button>
            </div>
        </Modal>
    );
};

export default CompanyEditModal;
