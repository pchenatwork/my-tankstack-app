import { Input } from 'antd';
import React from 'react';

import type { UserFilterState } from './types';
import { getImagePath } from '@/utils';

interface UserFilterProps {
    filter: UserFilterState;
    onChange: (newFilter: UserFilterState) => void;
}

const UserFilter: React.FC<UserFilterProps> = ({ filter, onChange }) => {
    const handleChange = (key: keyof UserFilterState, value: string) => {
        onChange({ ...filter, [key]: value });
    };

    return (
        <div className="flex items-center">
            {/* Search */}
            <div
                className="flex items-center overflow-hidden rounded-lg bg-white"
                style={{
                    width: 316,
                    height: 34,
                    border: '1px solid #c6c6c6',
                }}
            >
                <Input
                    placeholder="Search by Email, Name or Security Level"
                    value={filter.search}
                    onChange={(e) => handleChange('search', e.target.value)}
                    className="border-0 px-3 shadow-none focus:shadow-none"
                    style={{
                        flex: 1,
                        height: '100%',
                        border: 'none',
                        boxShadow: 'none',
                    }}
                    variant="outlined"
                />
                <div
                    className="flex h-full cursor-pointer items-center justify-center"
                    style={{
                        backgroundColor: '#0168a7',
                        width: 34,
                        borderRadius: '0 7px 7px 0',
                    }}
                >
                    <img
                        src={getImagePath('icons/search_icon.png')}
                        alt="Search"
                        width={16}
                        style={{ filter: 'brightness(0) invert(1)' }}
                    />
                </div>
            </div>
        </div>
    );
};

export default UserFilter;
