import { CloseOutlined } from '@ant-design/icons';
import { Checkbox, Form, Input, Modal, Radio, Select, Switch } from 'antd';
import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';

import { CIButton, CISearchBox } from '@/components/common';
import AddSecurityLevelModal from '@/components/security-levels/AddSecurityLevelModal';
import { MapAccessTab } from '@/components/user-cards/map-access';
import type { MapAccessState } from '@/components/user-cards/map-access/types';
import type { User } from '@/types/user';
import { getImagePath } from '@/utils';

import styles from './UserEditModal.module.scss';
import type { AdminAccessLevel } from '@/constants';

type Mode = 'add' | 'edit';

export interface UserFormValues {
    company: string;
    entryMethod: 'manual' | 'ad';
    firstName: string;
    lastName: string;
    email: string;
    jobTitle?: string;
    username: string;
    password: string;
    securityLevelKey: string;
    adminAccess?: AdminAccessLevel;
    hiddenCameras?: string[];
    enableEmail?: boolean;
    mapAccess?: MapAccessState;
}

type UserWithExtendedFields = Partial<User> & {
    hiddenCameras?: string[];
    enableEmail?: boolean;
    mapAccess?: MapAccessState;
};

interface UserEditModalProps {
    open: boolean;
    mode: Mode;
    initialUser?: UserWithExtendedFields | null;
    onCancel: () => void;
    onSubmit: (values: UserFormValues) => void;
}

const securityLevels = [
    { key: 'loss-prevention-admin', name: 'Loss Prevention - Admin', color: '#f97316', starType: 'half' },
    { key: 'loss-prevention', name: 'Loss Prevention', color: '#fb923c', starType: null },
    { key: 'it', name: 'Information Technology (IT)', color: '#6366f1', starType: 'half' },
    { key: 'business-leaders', name: 'Business Leaders', color: '#db2777', starType: null },
    { key: 'operations', name: 'Operations', color: '#2563eb', starType: null },
    { key: 'marketing', name: 'Marketing', color: '#16a34a', starType: null },
    { key: 'full-access', name: 'Full Access', color: '#eab308', starType: 'full' },
];

const mockCameras = [
    { id: '1', name: 'Front Door' },
    { id: '2', name: 'Front Door 2' },
    { id: '3', name: 'Public View' },
    { id: '4', name: 'POS Registers' },
    { id: '5', name: 'POS Registers 2' },
    { id: '6', name: 'Beverages' },
    { id: '7', name: 'Candy' },
    { id: '8', name: 'Snacks' },
    { id: '9', name: 'Coffee Station' },
    { id: '10', name: 'Dumpster' },
    { id: '11', name: 'Emergency Exit' },
];

type TabType = 'user-info' | 'security-access' | 'map-access' | 'camera-access' | 'email-notifications';

const TAB_ORDER: TabType[] = ['user-info', 'security-access', 'map-access', 'camera-access', 'email-notifications'];

const UserEditModal: React.FC<UserEditModalProps> = ({ open, mode, initialUser, onCancel, onSubmit }) => {
    const [form] = Form.useForm<UserFormValues>();
    const [activeTab, setActiveTab] = useState<TabType>('user-info');
    const [completedTabs, setCompletedTabs] = useState<Set<TabType>>(new Set());
    const tabContentRef = useRef<HTMLDivElement | null>(null);
    const [tabContentHeight, setTabContentHeight] = useState<number | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [isAddSecurityLevelModalOpen, setIsAddSecurityLevelModalOpen] = useState(false);
    const [hideCameras, setHideCameras] = useState(false);
    const [hiddenCameras, setHiddenCameras] = useState<string[]>([]);
    const [cameraSearchTerm, setCameraSearchTerm] = useState('');
    const [enableEmail, setEnableEmail] = useState(false);
    const [userPermission, setUserPermission] = useState<'admin' | 'non-admin'>('admin');
    const selectedSecurityLevelKey = Form.useWatch('securityLevelKey', form);

    const computeAdminAccess = (levelKey: string | undefined, permission: 'admin' | 'non-admin'): AdminAccessLevel => {
        const level = securityLevels.find((l) => l.key === levelKey);
        if (!level?.starType) return 'N';
        if (permission === 'non-admin') return 'N';
        return level.starType === 'full' ? 'F' : 'P';
    };

    useEffect(() => {
        if (open) {
            // Parse firstName and lastName from fullName
            let firstName = '';
            let lastName = '';
            if (initialUser?.fullName) {
                const nameParts = initialUser.fullName.trim().split(/\s+/);
                if (nameParts.length > 0) {
                    firstName = nameParts[0];
                    if (nameParts.length > 1) {
                        lastName = nameParts.slice(1).join(' ');
                    }
                }
            }

            // Map securityLevel name to securityLevelKey
            let securityLevelKey = '';
            if (initialUser?.securityLevel?.name) {
                const matchingLevel = securityLevels.find(
                    (level) => level.name.toLowerCase() === initialUser.securityLevel?.name.toLowerCase(),
                );
                if (matchingLevel) {
                    securityLevelKey = matchingLevel.key;
                }
            }

            const initialPermission: 'admin' | 'non-admin' = 'admin';

            form.setFieldsValue({
                company: initialUser?.company || 'ClickIt Inc.',
                entryMethod: 'manual',
                firstName: firstName,
                lastName: lastName,
                email: initialUser?.email || '',
                jobTitle: initialUser?.jobTitle || '',
                username: initialUser?.userName || '',
                password: '',
                securityLevelKey: securityLevelKey,
                adminAccess: computeAdminAccess(securityLevelKey || undefined, initialPermission),
                hiddenCameras: initialUser?.hiddenCameras || [],
                enableEmail: initialUser?.enableEmail || false,
                mapAccess: initialUser?.mapAccess || {
                    selectedMapId: null,
                    checkedKeys: {},
                    allowUnspecifiedLocations: false,
                },
            });
            setHideCameras((initialUser?.hiddenCameras?.length || 0) > 0);
            setHiddenCameras(initialUser?.hiddenCameras || []);
            setCameraSearchTerm('');
            setEnableEmail(initialUser?.enableEmail || false);
            setUserPermission(initialPermission);
        } else {
            form.resetFields();
            setActiveTab('user-info');
            setCompletedTabs(new Set());
            setTabContentHeight(null);
            setHideCameras(false);
            setHiddenCameras([]);
            setCameraSearchTerm('');
            setEnableEmail(false);
            setUserPermission('admin');
        }
    }, [open, initialUser, form]);

    useLayoutEffect(() => {
        if (!open) return;
        if (activeTab !== 'user-info') return;
        if (tabContentHeight !== null) return;

        const el = tabContentRef.current;
        if (!el) return;

        const rafId = requestAnimationFrame(() => {
            const measured = Math.ceil(el.getBoundingClientRect().height);
            if (measured > 0) setTabContentHeight(measured);
        });

        return () => cancelAnimationFrame(rafId);
    }, [open, activeTab, tabContentHeight]);

    const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const email = e.target.value;
        form.setFieldValue('email', email);
        const currentUsername = form.getFieldValue('username');
        if (!currentUsername) {
            const usernameFromEmail = email?.split('@')[0] || '';
            form.setFieldValue('username', usernameFromEmail);
        }
    };

    const handleCopyEmailToUsername = () => {
        const email = form.getFieldValue('email') || '';
        const usernameFromEmail = email.split('@')[0] || email;
        form.setFieldValue('username', usernameFromEmail);
    };

    const validateTab = async (tab: TabType): Promise<boolean> => {
        switch (tab) {
            case 'user-info':
                try {
                    await form.validateFields(['company', 'firstName', 'lastName', 'email', 'username', 'password']);
                    return true;
                } catch {
                    return false;
                }
            case 'security-access':
                try {
                    await form.validateFields(['securityLevelKey']);
                    return true;
                } catch {
                    return false;
                }
            case 'map-access':
                // Map Access is optional for now, always valid
                return true;
            case 'camera-access':
                // Camera Access is optional, always valid
                return true;
            case 'email-notifications':
                // Email Notifications is optional, always valid
                return true;
            default:
                return true;
        }
    };

    const handleTabClick = async (targetTab: TabType) => {
        const currentTabIndex = TAB_ORDER.indexOf(activeTab);
        const targetTabIndex = TAB_ORDER.indexOf(targetTab);

        // Allow going back to previous tabs
        if (targetTabIndex < currentTabIndex) {
            setActiveTab(targetTab);
            return;
        }

        // If trying to move forward, validate current tab first
        if (targetTabIndex > currentTabIndex) {
            const isValid = await validateTab(activeTab);
            if (!isValid) {
                // Focus on first error field
                const fields = form.getFieldsError();
                const firstError = fields.find((field) => field.errors.length > 0);
                if (firstError) {
                    form.scrollToField(firstError.name[0] as string);
                }
                return;
            }

            // Mark current tab as completed
            setCompletedTabs((prev) => new Set(prev).add(activeTab));
        }

        // Allow moving to next tab or staying on current
        if (targetTabIndex <= currentTabIndex + 1) {
            setActiveTab(targetTab);
        }
    };

    const handleOk = async () => {
        // Validate current tab first
        const isValid = await validateTab(activeTab);
        if (!isValid) {
            const fields = form.getFieldsError();
            const firstError = fields.find((field) => field.errors.length > 0);
            if (firstError) {
                form.scrollToField(firstError.name[0] as string);
            }
            return;
        }

        // Validate all tabs before submitting
        for (const tab of TAB_ORDER) {
            const tabValid = await validateTab(tab);
            if (!tabValid) {
                // Switch to first invalid tab
                setActiveTab(tab);
                const fields = form.getFieldsError();
                const firstError = fields.find((field) => field.errors.length > 0);
                if (firstError) {
                    form.scrollToField(firstError.name[0] as string);
                }
                return;
            }
        }

        // All tabs valid, submit
        const values = form.getFieldsValue(true) as UserFormValues;
        onSubmit(values);
    };

    const renderUserInfoTab = () => (
        <>
            <div className={styles['section-title']}>User Info</div>
            <div className={styles['section-card']}>
                <div className={styles['user-info-grid']}>
                    <Form.Item
                        label={<span>Company:</span>}
                        name="company"
                        rules={[{ required: true, message: 'Please select a company' }]}
                    >
                        <Select
                            options={[
                                { value: 'ClickIt Inc.', label: 'ClickIt Inc.' },
                                { value: 'Other', label: 'Other' },
                            ]}
                        />
                    </Form.Item>

                    <div />

                    <Form.Item label="Entry Method:" name="entryMethod" initialValue="manual">
                        <Radio.Group>
                            <Radio.Button value="manual">Manual Entry</Radio.Button>
                            <Radio.Button value="ad" disabled>
                                Active Directory
                            </Radio.Button>
                        </Radio.Group>
                    </Form.Item>

                    <div />

                    <Form.Item
                        label={<span>First Name:</span>}
                        name="firstName"
                        rules={[{ required: true, message: 'Please enter first name' }]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label={<span>Last Name:</span>}
                        name="lastName"
                        rules={[{ required: true, message: 'Please enter last name' }]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label={<span>Email:</span>}
                        name="email"
                        rules={[
                            { required: true, message: 'Please enter email' },
                            { type: 'email', message: 'Please enter a valid email' },
                        ]}
                    >
                        <Input onChange={handleEmailChange} />
                    </Form.Item>

                    <Form.Item label="Job Title:" name="jobTitle">
                        <Input />
                    </Form.Item>
                </div>
            </div>

            <div className={styles['section-title']}>Login Credentials</div>
            <div className={styles['section-card']}>
                <div className={styles['login-grid']}>
                    <Form.Item
                        className={styles['username-field']}
                        labelCol={{ span: 24 }}
                        label={
                            <div className={styles['username-label-row']}>
                                <span>Username:</span>
                                <button
                                    type="button"
                                    className={styles['copy-email']}
                                    onClick={handleCopyEmailToUsername}
                                >
                                    Copy email
                                </button>
                            </div>
                        }
                        name="username"
                        rules={[{ required: true, message: 'Please enter username' }]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label={<span>Password:</span>}
                        name="password"
                        rules={[{ required: true, message: 'Please enter password' }]}
                    >
                        <Input.Password />
                    </Form.Item>
                </div>
            </div>
        </>
    );

    const renderSecurityAccessTab = () => {
        const filteredLevels = securityLevels.filter((level) =>
            level.name.toLowerCase().includes(searchTerm.toLowerCase()),
        );

        return (
            <>
                <div className={styles['search-row']}>
                    <div>
                        <div className={styles['section-title']}>
                            <span className={styles['required-mark']}>*</span>Security Access
                        </div>
                        <div className={styles['section-subtitle']}>
                            Select which security level to give this user access to
                        </div>
                    </div>
                    <CIButton
                        variant="primary2"
                        size="small"
                        className={styles['add-level-button']}
                        onClick={() => setIsAddSecurityLevelModalOpen(true)}
                        icon={<img src={getImagePath('icons/icon-plus.png')} alt="Add" width={12} height={12} />}
                    >
                        Add New Level
                    </CIButton>
                </div>

                <div className={styles['section-card']}>
                    <div className={styles['security-table']}>
                        <div className={styles['security-toolbar']}>
                            <span className={styles['levels-count']}>
                                Security Levels:{' '}
                                <span className={styles['levels-number']}>{securityLevels.length}</span>
                            </span>
                            <CISearchBox
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                placeholder="Search by Security Level Name"
                                size="small"
                                className="w-[316px]"
                                inputClassName="!w-full md:!w-full"
                            />
                        </div>

                        <div className={styles['security-header']}>
                            <span />
                            <span className={styles['security-header-label']}>Security Level</span>
                            <span className={styles['security-header-permission']}>User Permission</span>
                            <span className={styles['security-header-view']}>View</span>
                        </div>
                        <Form.Item
                            name="securityLevelKey"
                            rules={[{ required: true, message: 'Please select a security level' }]}
                            style={{ marginBottom: 0 }}
                        >
                            <Radio.Group
                                style={{ width: '100%' }}
                                onChange={(e) => {
                                    const nextKey = String(e.target.value);
                                    const selected = securityLevels.find((level) => level.key === nextKey);
                                    if (selected?.starType) {
                                        setUserPermission('admin');
                                        form.setFieldValue('adminAccess', computeAdminAccess(nextKey, 'admin'));
                                    } else {
                                        form.setFieldValue('adminAccess', 'N');
                                    }
                                }}
                            >
                                {filteredLevels.map((level, index) => (
                                    <div
                                        key={level.key}
                                        className={`${styles['security-row']} ${index % 2 === 1 ? styles['security-row-alt'] : ''}`}
                                        onClick={() => {
                                            form.setFieldValue('securityLevelKey', level.key);
                                            if (level.starType) {
                                                setUserPermission('admin');
                                                form.setFieldValue(
                                                    'adminAccess',
                                                    computeAdminAccess(level.key, 'admin'),
                                                );
                                            } else {
                                                form.setFieldValue('adminAccess', 'N');
                                            }
                                        }}
                                    >
                                        <Radio value={level.key} />
                                        <div className={styles['security-label-container']}>
                                            <span
                                                className={styles['security-label']}
                                                style={{ backgroundColor: level.color }}
                                            >
                                                {level.name}
                                            </span>
                                            {level.starType && (
                                                <span className={styles['star-icon']}>
                                                    <img
                                                        src={
                                                            level.starType === 'full'
                                                                ? getImagePath('icons/full_star.png')
                                                                : getImagePath('icons/half_star.png')
                                                        }
                                                        alt={
                                                            level.starType === 'full' ? 'Full Access' : 'Partial Access'
                                                        }
                                                        width={20}
                                                        height={20}
                                                    />
                                                </span>
                                            )}
                                        </div>

                                        <div className={styles['security-permission']}>
                                            {selectedSecurityLevelKey === level.key && level.starType ? (
                                                <div
                                                    className={styles['permission-radio-group']}
                                                    onClick={(e) => e.stopPropagation()}
                                                >
                                                    <Radio.Group
                                                        value={userPermission}
                                                        onChange={(e) => {
                                                            const nextPermission = e.target.value as
                                                                | 'admin'
                                                                | 'non-admin';
                                                            setUserPermission(nextPermission);
                                                            form.setFieldValue(
                                                                'adminAccess',
                                                                computeAdminAccess(level.key, nextPermission),
                                                            );
                                                        }}
                                                    >
                                                        <Radio value="admin">Admin</Radio>
                                                        <Radio value="non-admin">Non Admin</Radio>
                                                    </Radio.Group>
                                                </div>
                                            ) : null}
                                        </div>

                                        <span className={styles['view-icon']}>
                                            <img
                                                src={getImagePath('icons/maximize-6.png')}
                                                alt="View"
                                                width={18}
                                                height={18}
                                            />
                                        </span>
                                    </div>
                                ))}
                            </Radio.Group>
                        </Form.Item>
                    </div>
                </div>
            </>
        );
    };

    const handleHideCamerasChange = (checked: boolean) => {
        setHideCameras(checked);
        if (!checked) {
            setHiddenCameras([]);
            form.setFieldValue('hiddenCameras', []);
        }
    };

    const handleCameraCheckboxChange = (cameraId: string, checked: boolean) => {
        if (checked) {
            setHiddenCameras((prev) => {
                const updated = [...prev, cameraId];
                form.setFieldValue('hiddenCameras', updated);
                return updated;
            });
        } else {
            setHiddenCameras((prev) => {
                const updated = prev.filter((id) => id !== cameraId);
                form.setFieldValue('hiddenCameras', updated);
                return updated;
            });
        }
    };

    const renderCameraAccessTab = () => {
        const filteredCameras = mockCameras.filter((camera) =>
            camera.name.toLowerCase().includes(cameraSearchTerm.toLowerCase()),
        );
        const allSelected =
            filteredCameras.length > 0 && filteredCameras.every((camera) => hiddenCameras.includes(camera.id));
        const someSelected = filteredCameras.some((camera) => hiddenCameras.includes(camera.id));

        const handleSelectAllCameras = (checked: boolean) => {
            if (checked) {
                const allCameraIds = filteredCameras.map((camera) => camera.id);
                setHiddenCameras(allCameraIds);
                form.setFieldValue('hiddenCameras', allCameraIds);
            } else {
                setHiddenCameras([]);
                form.setFieldValue('hiddenCameras', []);
            }
        };

        return (
            <>
                <div className={styles['section-title']}>Camera Access</div>
                <div className={styles['section-card']}>
                    <div className={styles['toggle-row']}>
                        <span className={styles['toggle-label']}>Hide Cameras</span>
                        <Switch checked={hideCameras} onChange={handleHideCamerasChange} />
                        <span className={styles['toggle-status']}>{hideCameras ? 'On' : 'Off'}</span>
                        {hideCameras && (
                            <span className={styles['hidden-count']}>
                                Hidden Cameras:{' '}
                                <span className={styles['hidden-count-number']}>{hiddenCameras.length}</span>
                            </span>
                        )}
                        {hideCameras && (
                            <div className={styles['camera-search-container']}>
                                <CISearchBox
                                    value={cameraSearchTerm}
                                    onChange={(e) => setCameraSearchTerm(e.target.value)}
                                    placeholder="Search by Camera Name"
                                    size="small"
                                    className="w-[316px]"
                                    inputClassName="!w-full md:!w-full"
                                />
                            </div>
                        )}
                        {!hideCameras && <div className={styles['toggle-row-spacer']} />}
                    </div>

                    {!hideCameras ? (
                        <div className={styles['empty-message']}>
                            <p>This user has access to all cameras.</p>
                            <p>Enable &quot;Hide Cameras&quot; to control visibility by Global Camera Name</p>
                        </div>
                    ) : (
                        <>
                            <div className={styles['camera-table']}>
                                <div className={styles['camera-header']}>
                                    <Checkbox
                                        checked={allSelected}
                                        indeterminate={someSelected && !allSelected}
                                        onChange={(e) => handleSelectAllCameras(e.target.checked)}
                                    />
                                    <span className={styles['camera-header-label']}>Cameras</span>
                                </div>
                                <div className={styles['camera-list']}>
                                    {filteredCameras.map((camera, index) => (
                                        <div
                                            key={camera.id}
                                            className={`${styles['camera-row']} ${index % 2 === 1 ? styles['camera-row-alt'] : ''}`}
                                        >
                                            <Checkbox
                                                checked={hiddenCameras.includes(camera.id)}
                                                onChange={(e) =>
                                                    handleCameraCheckboxChange(camera.id, e.target.checked)
                                                }
                                            />
                                            <img
                                                src={getImagePath('icons/icon-cameras.png')}
                                                alt="Camera"
                                                className={styles['camera-icon']}
                                                width={14}
                                                height={14}
                                            />
                                            <span className={styles['camera-name']}>{camera.name}</span>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </>
                    )}
                </div>
            </>
        );
    };

    const renderEmailNotificationsTab = () => {
        return (
            <>
                <div className={styles['section-title']}>Email Notifications</div>
                <div className={styles['section-card']}>
                    <div className={styles['toggle-row']}>
                        <span className={styles['toggle-label']}>Enable Email</span>
                        <Switch
                            checked={enableEmail}
                            onChange={(checked) => {
                                setEnableEmail(checked);
                                form.setFieldValue('enableEmail', checked);
                            }}
                        />
                        <span className={styles['toggle-status']}>{enableEmail ? 'On' : 'Off'}</span>
                    </div>
                </div>
            </>
        );
    };

    return (
        <Modal
            open={open}
            onCancel={onCancel}
            footer={null}
            width="90%"
            style={{ maxWidth: 900 }}
            closeIcon={<CloseOutlined />}
            className={styles.modal}
            forceRender
        >
            <div className={styles.header}>
                <div className={styles['title-row']}>
                    <div className={styles.title}>{mode === 'edit' ? 'Edit User' : 'New User'}</div>
                </div>
            </div>

            <div className={styles.tabs}>
                <div className={styles['tab-row']}>
                    {TAB_ORDER.map((tab) => {
                        const currentTabIndex = TAB_ORDER.indexOf(activeTab);
                        const tabIndex = TAB_ORDER.indexOf(tab);
                        const isActive = activeTab === tab;
                        const isCompleted = completedTabs.has(tab);
                        const isDisabled = tabIndex > currentTabIndex + 1 && !isCompleted;

                        let tabLabel = '';
                        let tabIcon = '';
                        switch (tab) {
                            case 'user-info':
                                tabLabel = 'User Info';
                                tabIcon = getImagePath('icons/user_details_icon.png');
                                break;
                            case 'security-access':
                                tabLabel = 'Security Access';
                                tabIcon = getImagePath('icons/icon-lock.png');
                                break;
                            case 'map-access':
                                tabLabel = 'Map Access';
                                tabIcon = getImagePath('icons/icon-map.png');
                                break;
                            case 'camera-access':
                                tabLabel = 'Camera Access';
                                tabIcon = getImagePath('icons/icon-cameras.png');
                                break;
                            case 'email-notifications':
                                tabLabel = 'Email Notifications';
                                tabIcon = getImagePath('icons/icon-email.png');
                                break;
                        }

                        return (
                            <button
                                key={tab}
                                type="button"
                                className={`${styles.tab} ${isActive ? styles['tab-active'] : ''}`}
                                onClick={() => handleTabClick(tab)}
                                disabled={isDisabled}
                            >
                                <img src={tabIcon} alt={tabLabel} className={styles['tab-icon']} />
                                <span className={styles['tab-label']}>{tabLabel}</span>
                            </button>
                        );
                    })}
                </div>
            </div>

            <div
                ref={tabContentRef}
                className={styles['tab-content']}
                style={tabContentHeight ? { height: tabContentHeight } : undefined}
            >
                <Form form={form} layout="vertical">
                    <Form.Item name="adminAccess" hidden>
                        <Input />
                    </Form.Item>
                    {activeTab === 'user-info' && renderUserInfoTab()}
                    {activeTab === 'security-access' && renderSecurityAccessTab()}
                    {activeTab === 'map-access' && (
                        <>
                            <div className={styles['section-header']}>
                                <div className={styles['section-title']}>
                                    <span className={styles['required-mark']}>*</span>Map Access
                                </div>
                                <div className={styles['section-subtitle']}>
                                    Select the maps and hierarchy this user should have access to
                                </div>
                            </div>
                            <div className={styles['section-card']}>
                                <Form.Item name="mapAccess" style={{ marginBottom: 0 }}>
                                    <MapAccessTab
                                        value={form.getFieldValue('mapAccess')}
                                        onChange={(value) => form.setFieldValue('mapAccess', value)}
                                    />
                                </Form.Item>
                            </div>
                        </>
                    )}
                    {activeTab === 'camera-access' && renderCameraAccessTab()}
                    {activeTab === 'email-notifications' && renderEmailNotificationsTab()}
                </Form>
            </div>

            <div className={styles.footer}>
                <CIButton variant="secondary" size="small" onClick={onCancel}>
                    Cancel
                </CIButton>
                <CIButton variant="primary2" size="small" onClick={handleOk}>
                    {mode === 'edit' ? 'Save Changes' : 'Add User'}
                </CIButton>
            </div>

            <AddSecurityLevelModal
                open={isAddSecurityLevelModalOpen}
                onClose={() => setIsAddSecurityLevelModalOpen(false)}
                onSubmit={(values) => {
                    // TODO: Handle new security level creation
                    // For now, just close the modal
                    // In the future, this should refresh the securityLevels list
                    console.log('New security level created:', values);
                    setIsAddSecurityLevelModalOpen(false);
                }}
            />
        </Modal>
    );
};

export default UserEditModal;
