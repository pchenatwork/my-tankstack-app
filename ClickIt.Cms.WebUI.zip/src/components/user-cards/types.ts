export type ViewType = 'grid' | 'list';

export interface UserFilterState {
    securityLevel: string;
    admin: string;
    lastLogin: string | null;
    search: string;
}
