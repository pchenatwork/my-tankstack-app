import { Avatar, Dropdown, Table, Tag } from 'antd';
import type { ColumnsType, TableProps } from 'antd/es/table';
import React from 'react';

import { AdminAccessLevel } from '@/constants';
import type { UserType } from '@/types/user';
import { getImagePath } from '@/utils';

import { createUserMenuItems, type UserMenuCallbacks } from './userMenuItems';

import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc'; // Import the UTC plugin
import type { SorterResult } from 'antd/es/table/interface';

dayjs.extend(utc); // Extend dayjs with the UTC plugin

interface UserListProps {
    users: UserType[];
    onUserClick?: (user: UserType) => void;
    onDetails?: (user: UserType) => void;
    onEdit?: (user: UserType) => void;
    onDuplicate?: (user: UserType) => void;
    onDelete?: (user: UserType) => void;
    onSort?: (columnKey: string, isDescending: boolean) => void;
}

const UserList: React.FC<UserListProps> = (props: UserListProps) => {
    const callbacks: UserMenuCallbacks = {
        onDetails: props.onDetails || (() => {}),
        onEdit: props.onEdit || (() => {}),
        onDuplicate: props.onDuplicate || (() => {}),
        onDelete: props.onDelete || (() => {}),
    };

    const columns: ColumnsType<UserType> = [
        {
            title: <span style={{ fontWeight: 'normal' }}>Name</span>,
            key: 'name',
            dataIndex: 'fullName',
            sorter: true,
            width: '30%',
            render: (_, record: UserType) => {
                const initials = record.fullName
                    .split(' ')
                    .map((n: string) => n[0])
                    .join('')
                    .toUpperCase()
                    .substring(0, 2);

                return (
                    <div className="flex items-center gap-3">
                        <Avatar
                            style={{
                                backgroundColor: record.isCurrentUser ? record.securityLevel.backColor : '',
                                color: record.isCurrentUser
                                    ? record.securityLevel.foreColor || 'var(--white)'
                                    : 'var(--white)',
                            }}
                        >
                            {initials}
                        </Avatar>
                        <div className="flex flex-col">
                            <span className="font-medium">
                                {record.fullName}
                                {record.isCurrentUser ? ' (IsCurrentUser == true )' : ''}
                            </span>
                        </div>
                    </div>
                );
            },
        },
        {
            title: <span style={{ fontWeight: 'normal' }}>Username</span>,
            dataIndex: 'userName',
            key: 'userName',
            width: '20%',
            sorter: true,
        },
        {
            title: <span style={{ fontWeight: 'normal' }}>Security Level</span>,
            key: 'securityLevel',
            dataIndex: 'securityLevel',
            sorter: true,
            width: '20%',
            render: (_, record: UserType) => (
                <div className="flex items-center gap-2">
                    <Tag
                        color={record.securityLevel.backColor}
                        style={{ border: 'none', color: record.securityLevel.foreColor || 'var(--white)' }}
                    >
                        {record.securityLevel.name}
                    </Tag>
                    <div className="cursor-pointer" onClick={(e) => e.stopPropagation()}>
                        <img
                            src={
                                record.securityLevel.accessLevel === AdminAccessLevel.Full
                                    ? getImagePath('icons/full_star.png')
                                    : getImagePath('icons/half_star.png')
                            }
                            alt="Access level"
                            width={20}
                        />
                    </div>
                </div>
            ),
        },
        {
            title: <span style={{ fontWeight: 'normal' }}>Last Login</span>,
            dataIndex: 'lastLoginOn',
            key: 'lastLoginOn',
            sorter: true,
            width: '20%',
            render: (_, record: UserType) => {
                return (
                    <div className="flex items-center gap-3">
                        {record.lastLogin && dayjs.utc(record.lastLogin).local().format('MM/DD/YYYY hh:mm:ss A')}
                    </div>
                );
            },
        },
        {
            title: <span style={{ fontWeight: 'normal' }}>Actions</span>,
            key: 'actions',
            width: 80,
            align: 'center',
            sorter: false,
            render: (_, record: UserType) => (
                <div onClick={(e) => e.stopPropagation()}>
                    <Dropdown menu={{ items: createUserMenuItems(record, callbacks) }} trigger={['click']}>
                        <img
                            src={getImagePath('icons/3dots.png')}
                            alt="Menu"
                            className="cursor-pointer"
                            width={24}
                            style={{ opacity: 0.6 }}
                        />
                    </Dropdown>
                </div>
            ),
        },
    ];

    const handleTableChange: TableProps<UserType>['onChange'] = (
        _pagination,
        _filters,
        sorter: SorterResult<UserType> | SorterResult<UserType>[],
    ) => {
        // Handle single sorter only
        const sorterResult = sorter as SorterResult<UserType>;
        const sortColumn = (sorterResult.field ?? 'fullName') as keyof UserType;
        const isDescending = sorterResult.order === 'descend';
        props.onSort?.(sortColumn, isDescending);
    };

    return (
        <Table
            columns={columns}
            dataSource={props.users}
            rowKey="apiUserId"
            pagination={false}
            rowClassName={(_, index) => (index % 2 === 0 ? 'bg-white cursor-pointer' : 'bg-gray-50 cursor-pointer')}
            size="small"
            onRow={(record) => ({
                onClick: () => props.onUserClick?.(record),
            })}
            onChange={handleTableChange}
        />
    );
};

export default UserList;
