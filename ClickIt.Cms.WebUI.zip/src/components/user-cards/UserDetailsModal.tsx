import { Modal, Tag } from 'antd';
import React from 'react';

import type { UserType } from '@/types/user';
import { getImagePath } from '@/utils';

import dayjs from 'dayjs';

interface UserDetailsModalProps {
    user: UserType | null;
    open: boolean;
    onClose: () => void;
    onEdit?: (u: UserType) => void;
}

const UserDetailsModal: React.FC<UserDetailsModalProps> = ({ user, open, onClose, onEdit }) => {
    if (!user) return null;

    function handleEditUser(event: React.MouseEvent<HTMLAnchorElement>): void {
        event.preventDefault();
        event.stopPropagation();

        if (!user) return;

        if (onEdit) {
            onEdit(user);
            onClose();
            return;
        }
    }
    
    return (
        <Modal
            open={open}
            onCancel={onClose}
            maskClosable={false}
            footer={null}
            width={600}
            closeIcon={<span className="text-xl text-gray-500">✕</span>}
            title={
                <div className="flex items-center gap-2 border-b border-gray-200 pb-2 text-xl font-semibold text-gray-700">
                    <img src={getImagePath('icons/user_icon.png')} alt="User" width={24} />
                    <span>User Details</span>
                </div>
            }
        >
            <div className="mt-4 rounded-lg border border-gray-300 bg-gray-100 p-6">
                <h2 className="mb-6 text-xl font-semibold text-gray-700">
                    {user.fullName}
                    {user.isCurrentUser ? ' (You)' : ''}
                </h2>

                <div className="grid grid-cols-[140px_1fr] gap-y-4 text-base">
                    <span className="text-gray-500">Company:</span>
                    <span className="font-medium text-gray-800">{user.companyName}</span>

                    <span className="text-gray-500">Username:</span>
                    <span className="font-medium text-gray-800">{user.userName}</span>

                    <span className="text-gray-500">Email:</span>
                    <span className="font-medium text-gray-800">{user.email || '-'}</span>

                    <span className="self-center text-gray-500">Security Level:</span>
                    <div className="flex items-center gap-2">
                        <Tag
                            color={user.securityLevel.backColor}
                            style={{
                                border: 'none',
                                padding: '4px 12px',
                                fontSize: '14px',
                                borderRadius: '4px',
                                color: user.securityLevel.foreColor,
                            }}
                        >
                            {user.securityLevel.name}
                        </Tag>
                        {user.securityLevel.hasFullAccess ? (
                            <img src={getImagePath('icons/full_star.png')} alt="Star" width={24} />
                        ) : (
                            <img src={getImagePath('icons/half_star.png')} alt="Star" width={24} />
                        )}
                    </div>

                    <span className="text-gray-500">Job Title:</span>
                    <span className="font-medium text-gray-800">{user.jobTitle || 'N/A'}</span>

                    <span className="text-gray-500">Active Since:</span>
                    <span className="font-medium text-gray-800">{user.activeSince || '12/22/2018'}</span>

                    <span className="text-gray-500">Last Login:</span>
                    <span className="font-medium text-gray-800">
                        {user.lastLogin ? dayjs.utc(user.lastLogin).local().format('MM/DD/YYYY hh:mm:ss A') : '-'}
                    </span>
                </div>
            </div>

            <div className="mt-6 text-center text-base text-gray-500">
                Want to make changes?{' '}
                <a href="#" className="text-blue-500 hover:underline" onClick={handleEditUser}>
                    Edit User
                </a>
            </div>
        </Modal>
    );
};

export default UserDetailsModal;
