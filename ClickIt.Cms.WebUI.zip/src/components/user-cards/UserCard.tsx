import { Avatar, Card, Dropdown, Tag } from 'antd';
import React from 'react';

import { AdminAccessLevel } from '@/constants';
import type { UserType } from '@/types/user';
import { getImagePath } from '@/utils';

import styles from './UserCard.module.scss';
import { createUserMenuItems, type UserMenuCallbacks } from './userMenuItems';

interface UserCardProps {
    user: UserType;
    onClick?: (user: UserType) => void;
    onDetails?: (user: UserType) => void;
    onEdit?: (user: UserType) => void;
    onDuplicate?: (user: UserType) => void;
    onDelete?: (user: UserType) => void;
}

const UserCard: React.FC<UserCardProps> = ({ user, onClick, onDetails, onEdit, onDuplicate, onDelete }) => {
    const callbacks: UserMenuCallbacks = {
        onDetails: onDetails || (() => {}),
        onEdit: onEdit || (() => {}),
        onDuplicate: onDuplicate || (() => {}),
        onDelete: onDelete || (() => {}),
    };

    const items = createUserMenuItems(user, callbacks);

    // Extract initials from fullName
    const initials = user.fullName
        .split(' ')
        .map((n) => n[0])
        .join('')
        .toUpperCase()
        .substring(0, 2);

    return (
        <Card
            className={`${styles['user-card']} cursor-pointer transition-all duration-200`}
            variant="outlined"
            onClick={() => onClick?.(user)}
            style={{
                padding: '24px 16px',
                borderRadius: 4,
                textAlign: 'center',
                position: 'relative',
                background: 'var(--color-bg-card)',
                boxShadow: '0px 4px 4px 0px rgba(144, 146, 148, 0.2)',
            }}
            hoverable
        >
            {/* Star Icon */}
            <div className="absolute top-4 left-4 z-10 cursor-pointer" onClick={(e) => e.stopPropagation()}>
                <img
                    src={getImagePath(
                        user.securityLevel.accessLevel === AdminAccessLevel.Full
                            ? '/icons/full_star.png'
                            : '/icons/half_star.png',
                    )}
                    alt="Access level"
                    width={20}
                />
            </div>

            {/* Menu Icon */}
            <div className="absolute top-4 right-4 z-10" onClick={(e) => e.stopPropagation()}>
                <Dropdown menu={{ items }} trigger={['click']}>
                    <img
                        src={getImagePath('icons/3dots.png')}
                        alt="Menu"
                        className="cursor-pointer"
                        width={24}
                        style={{ opacity: 0.6 }}
                    />
                </Dropdown>
            </div>

            {/* Avatar */}
            <div className="mb-4 flex justify-center">
                <Avatar
                    size={52}
                    style={{
                        backgroundColor: user.isCurrentUser ? user.securityLevel.backColor : 'var(--avatar-bg-default)',
                        color: user.isCurrentUser ? user.securityLevel.foreColor : 'var(--color-text-main)',
                        fontSize: 26,
                        fontWeight: 700,
                        fontFamily: 'var(--font-body)',
                        lineHeight: 1.2,
                        letterSpacing: '0.52px',
                    }}
                >
                    {initials}
                </Avatar>
            </div>

            {/* Name & Username */}
            <h3
                style={{
                    fontFamily: 'var(--font-body)',
                    fontSize: 'var(--font-size-body)',
                    fontWeight: 400,
                    color: 'var(--color-text-main)',
                    lineHeight: 1.5,
                    letterSpacing: '0.28px',
                    marginBottom: '4px',
                    marginTop: 0,
                }}
            >
                {user.fullName}
                {user.isCurrentUser ? ' (You)' : ''}
            </h3>
            <p
                style={{
                    fontFamily: 'var(--font-body)',
                    fontSize: 'var(--font-size-body)',
                    fontWeight: 400,
                    color: 'var(--color-text-main)',
                    lineHeight: 1.5,
                    letterSpacing: '0.28px',
                    marginBottom: '16px',
                    marginTop: 0,
                }}
            >
                {user.userName}
            </p>

            {/* Role Badge */}
            <Tag
                color={user.securityLevel.backColor}
                style={{
                    borderRadius: 4,
                    padding: '1px 7px',
                    fontSize: 'var(--font-size-small)',
                    fontWeight: 400,
                    border: 'none',
                    color: user.securityLevel.foreColor || 'var(--white)',
                    fontFamily: 'var(--font-body)',
                    lineHeight: 1.5,
                    letterSpacing: '0.28px',
                    height: 24,
                    display: 'inline-flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                }}
            >
                {user.securityLevel.name}
            </Tag>
        </Card>
    );
};

export default UserCard;
