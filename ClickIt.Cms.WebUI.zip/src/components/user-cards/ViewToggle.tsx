import { Button } from 'antd';
import React from 'react';

import type { ViewType } from './types';
import { getImagePath } from '@/utils';

interface ViewToggleProps {
    view: ViewType;
    onChange: (view: ViewType) => void;
}

const ViewToggle: React.FC<ViewToggleProps> = ({ view, onChange }) => {
    return (
        <div className="flex items-center rounded-sm border border-gray-200 bg-gray-100">
            <div
                style={{
                    backgroundColor: view === 'list' ? 'var(--color-side-panel-view-options-selected)' : 'transparent',
                }}
                className="rounded-l-sm rounded-r-none border-r-gray-200"
            >
                <Button
                    type="text"
                    icon={<img src={getImagePath('icons/list_view.png')} alt="List" width={20} />}
                    onClick={() => onChange('list')}
                    className={`flex items-center justify-center ${view === 'list' ? 'shadow-sm' : ''}`}
                    style={{
                        borderRadius: 4,
                        margin: '0px',
                    }}
                    size="small"
                />
            </div>
            <div
                style={{
                    backgroundColor: view === 'grid' ? 'var(--color-side-panel-view-options-selected)' : 'transparent',
                }}
                className="rounded-l-none rounded-r-sm"
            >
                <Button
                    type="text"
                    icon={<img src={getImagePath('icons/grid_view.png')} alt="Grid" width={20} />}
                    onClick={() => onChange('grid')}
                    className={`flex items-center justify-center ${view === 'grid' ? 'shadow-sm' : ''}`}
                    style={{
                        borderRadius: 4,
                        margin: '0px',
                    }}
                    size="small"
                />
            </div>
        </div>
    );
};

export default ViewToggle;
