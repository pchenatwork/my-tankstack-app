import type { MenuProps } from 'antd';

import type { UserType } from '@/types/user';
import { getImagePath } from '@/utils';

export interface UserMenuCallbacks {
    onDetails: (user: UserType) => void;
    onPreviewProfile?: (user: UserType) => void;
    onEdit: (user: UserType) => void;
    onDuplicate: (user: UserType) => void;
    onDelete: (user: UserType) => void;
}

export const createUserMenuItems = (user: UserType, callbacks: UserMenuCallbacks): MenuProps['items'] => [
    {
        key: 'details',
        label: 'User Details',
        icon: <img src={getImagePath('icons/user_details_icon.png')} alt="Details" width={16} />,
        onClick: () => callbacks.onDetails(user),
    },
    {
        key: 'preview',
        label: 'Preview Profile',
        icon: <img src={getImagePath('icons/preview_profile_icon.png')} alt="Preview" width={16} />,
        onClick: () => callbacks.onPreviewProfile?.(user),
    },
    {
        key: 'edit',
        label: 'Edit',
        icon: <img src={getImagePath('icons/edit_icon.png')} alt="Edit" width={16} />,
        onClick: () => callbacks.onEdit(user),
    },
    {
        key: 'duplicate',
        label: 'Duplicate',
        icon: <img src={getImagePath('icons/duplicate_icon.png')} alt="Duplicate" width={16} />,
        onClick: () => callbacks.onDuplicate(user),
    },
    {
        key: 'delete',
        label: 'Delete',
        danger: true,
        icon: <img src={getImagePath('icons/delete_icon.png')} alt="Delete" width={16} />,
        onClick: () => callbacks.onDelete(user),
    },
];
