import { QuestionCircleOutlined } from '@ant-design/icons';
import { Switch, Tooltip } from 'antd';
import React from 'react';

import { getImagePath } from '@/utils';

import styles from './MapAccess.module.scss';
import type { AccessLevel, MapItem } from './types';

interface MapAccessSidebarProps {
    maps: MapItem[];
    selectedMapId: string | null;
    mapAccessLevels: Record<string, AccessLevel>;
    allowUnspecifiedLocations: boolean;
    onMapSelect: (mapId: string) => void;
    onUnspecifiedLocationsToggle: (checked: boolean) => void;
    onUnspecifiedLocationsConfirm: () => void;
}

const MapAccessSidebar: React.FC<MapAccessSidebarProps> = ({
    maps,
    selectedMapId,
    mapAccessLevels,
    allowUnspecifiedLocations,
    onMapSelect,
    onUnspecifiedLocationsToggle,
    onUnspecifiedLocationsConfirm,
}) => {
    const handleUnspecifiedToggle = (checked: boolean) => {
        if (checked) {
            // Show confirmation modal first
            onUnspecifiedLocationsConfirm();
        } else {
            // Directly turn off if unchecking
            onUnspecifiedLocationsToggle(false);
        }
    };

    const getAccessBadge = (accessLevel: AccessLevel) => {
        if (accessLevel === 'none') return null;
        return (
            <span className={styles['access-badge']}>{accessLevel === 'full' ? 'Full Access' : 'Partial Access'}</span>
        );
    };

    return (
        <div className={styles.sidebar}>
            <div className={styles['map-list']}>
                {maps.map((map) => {
                    const isSelected = selectedMapId === map.id;
                    const accessLevel = mapAccessLevels[map.id] || 'none';

                    return (
                        <div
                            key={map.id}
                            className={`${styles['map-item']} ${isSelected ? styles['map-item-selected'] : ''}`}
                            onClick={() => onMapSelect(map.id)}
                        >
                            <img
                                src={getImagePath('icons/icon-map.png')}
                                alt="Map"
                                className={styles['map-icon']}
                                width={14}
                                height={14}
                            />
                            <span className={styles['map-name']}>{map.name}</span>
                            {getAccessBadge(accessLevel)}
                        </div>
                    );
                })}
            </div>

            <div className={styles['unspecified-row']}>
                <div className={styles['unspecified-label-container']}>
                    <span className={styles['unspecified-label']}>Unspecified Locations</span>
                    <Tooltip
                        title="Enable to allow this user to view locations that have not been added to the map hierarchy."
                        placement="top"
                    >
                        <QuestionCircleOutlined className={styles['info-icon']} />
                    </Tooltip>
                </div>
                <div className={styles['toggle-container']}>
                    <Switch checked={allowUnspecifiedLocations} onChange={handleUnspecifiedToggle} />
                    <span className={styles['toggle-status']}>{allowUnspecifiedLocations ? 'On' : 'Off'}</span>
                </div>
            </div>
        </div>
    );
};

export default MapAccessSidebar;
