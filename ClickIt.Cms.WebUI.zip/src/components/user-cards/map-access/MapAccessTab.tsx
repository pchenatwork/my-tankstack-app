import React, { useEffect, useMemo, useState } from 'react';

import styles from './MapAccess.module.scss';
import MapAccessSidebar from './MapAccessSidebar';
import MapHierarchyTree from './MapHierarchyTree';
import type { AccessLevel, MapAccessState } from './types';
import UnspecifiedLocationsModal from './UnspecifiedLocationsModal';

interface MapAccessTabProps {
    value?: MapAccessState;
    onChange?: (value: MapAccessState) => void;
}

// Mock data - replace with API calls later
const mockMaps = [
    { id: 'cvs-map', name: 'CVS Map' },
    { id: 'cvs-distribution', name: 'CVS Distribution' },
];

const mockHierarchies: Record<string, any[]> = {
    'cvs-map': [
        {
            key: 'northeast',
            title: 'Northeast (2,720)',
            icon: 'trapezoid',
            children: [
                {
                    key: 'region-1',
                    title: 'Region 1 (177)',
                    children: [
                        {
                            key: 'district-1',
                            title: 'District 1 (25)',
                            hasManageStores: true,
                            excludedStoresCount: 0,
                        },
                        { key: 'district-2', title: 'District 2 (25)' },
                        { key: 'district-3', title: 'District 3 (25)' },
                        { key: 'district-4', title: 'District 4 (25)' },
                        { key: 'district-5', title: 'District 5 (25)' },
                        { key: 'district-6', title: 'District 6 (25)' },
                        { key: 'district-7', title: 'District 7 (25)' },
                        { key: 'district-8', title: 'District 8 (25)' },
                        { key: 'district-9', title: 'District 9 (25)' },
                    ],
                },
                { key: 'region-2', title: 'Region 2 (176)' },
                { key: 'region-3', title: 'Region 3 (174)' },
                { key: 'region-4', title: 'Region 4 (178)' },
            ],
        },
        { key: 'southeast', title: 'Southeast (2,035)', icon: 'icons/icon-store.png' },
        { key: 'midwest', title: 'Midwest (1,928)', icon: 'icons/icon-store.png' },
        { key: 'southwest', title: 'Southwest (1,701)', icon: 'icons/icon-store.png' },
        { key: 'northwest', title: 'Northwest (1,581)', icon: 'icons/icon-store.png' },
        { key: 'pacific', title: 'Pacific (1,384)', icon: 'icons/icon-store.png' },
    ],
    'cvs-distribution': [
        { key: 'region-1', title: 'Region 1 (100)' },
        { key: 'region-2', title: 'Region 2 (95)' },
    ],
};

const MapAccessTab: React.FC<MapAccessTabProps> = ({ value, onChange }) => {
    const [state, setState] = useState<MapAccessState>({
        selectedMapId: mockMaps[0]?.id || null,
        checkedKeys: {},
        allowUnspecifiedLocations: false,
    });

    const [isUnspecifiedModalOpen, setIsUnspecifiedModalOpen] = useState(false);

    // Initialize from prop value
    useEffect(() => {
        if (value) {
            setState(value);
        }
    }, [value]);

    // Count all nodes in a hierarchy
    const countAllNodes = (nodes: any[]): number => {
        let count = 0;
        nodes.forEach((node) => {
            count += 1;
            if (node.children) {
                count += countAllNodes(node.children);
            }
        });
        return count;
    };

    // Calculate access level for a map
    const getAccessLevel = (mapId: string): AccessLevel => {
        const hierarchy = mockHierarchies[mapId] || [];
        const totalNodes = countAllNodes(hierarchy);
        const checkedCount = state.checkedKeys[mapId]?.length || 0;

        if (checkedCount === 0) return 'none';
        if (checkedCount === totalNodes) return 'full';
        return 'partial';
    };

    // Calculate access levels for all maps
    const mapAccessLevels = useMemo(() => {
        const levels: Record<string, AccessLevel> = {};
        mockMaps.forEach((map) => {
            levels[map.id] = getAccessLevel(map.id);
        });
        return levels;
    }, [state.checkedKeys]);

    const handleMapSelect = (mapId: string) => {
        const newState = { ...state, selectedMapId: mapId };
        setState(newState);
        onChange?.(newState);
    };

    const handleTreeCheck = (mapId: string, checkedKeys: React.Key[]) => {
        const newState = {
            ...state,
            checkedKeys: {
                ...state.checkedKeys,
                [mapId]: checkedKeys,
            },
        };
        setState(newState);
        onChange?.(newState);
    };

    const handleUnspecifiedLocationsToggle = (checked: boolean) => {
        const newState = { ...state, allowUnspecifiedLocations: checked };
        setState(newState);
        onChange?.(newState);
    };

    const handleUnspecifiedLocationsConfirm = () => {
        setIsUnspecifiedModalOpen(true);
    };

    const handleUnspecifiedModalOk = () => {
        handleUnspecifiedLocationsToggle(true);
        setIsUnspecifiedModalOpen(false);
    };

    const handleUnspecifiedModalCancel = () => {
        setIsUnspecifiedModalOpen(false);
    };

    const handleManageStores = (nodeKey: string) => {
        // TODO: Implement manage stores popup
        console.log('Manage stores for node:', nodeKey);
    };

    const currentHierarchy = state.selectedMapId ? mockHierarchies[state.selectedMapId] || [] : [];
    const currentCheckedKeys = state.selectedMapId ? state.checkedKeys[state.selectedMapId] || [] : [];

    return (
        <>
            <div className={styles['map-access-container']}>
                <div className={styles['map-access-content']}>
                    <MapAccessSidebar
                        maps={mockMaps}
                        selectedMapId={state.selectedMapId}
                        mapAccessLevels={mapAccessLevels}
                        allowUnspecifiedLocations={state.allowUnspecifiedLocations}
                        onMapSelect={handleMapSelect}
                        onUnspecifiedLocationsToggle={handleUnspecifiedLocationsToggle}
                        onUnspecifiedLocationsConfirm={handleUnspecifiedLocationsConfirm}
                    />

                    {state.selectedMapId && (
                        <MapHierarchyTree
                            hierarchy={currentHierarchy}
                            checkedKeys={currentCheckedKeys}
                            onCheck={(keys) => handleTreeCheck(state.selectedMapId!, keys)}
                            onManageStores={handleManageStores}
                        />
                    )}
                </div>
            </div>

            <UnspecifiedLocationsModal
                open={isUnspecifiedModalOpen}
                onCancel={handleUnspecifiedModalCancel}
                onConfirm={handleUnspecifiedModalOk}
            />
        </>
    );
};

export default MapAccessTab;
