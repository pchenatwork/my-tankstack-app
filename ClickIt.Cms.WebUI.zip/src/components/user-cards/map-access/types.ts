export interface MapItem {
    id: string;
    name: string;
}

export interface HierarchyNode {
    key: string;
    title: string;
    icon?: string;
    count?: number;
    hasManageStores?: boolean;
    excludedStoresCount?: number;
    children?: HierarchyNode[];
}

export type AccessLevel = 'full' | 'partial' | 'none';

export interface MapAccessState {
    selectedMapId: string | null;
    checkedKeys: Record<string, React.Key[]>; // Per-map checked node keys
    allowUnspecifiedLocations: boolean;
}

export interface MapAccessData {
    maps: MapItem[];
    hierarchies: Record<string, HierarchyNode[]>;
}
