import { QuestionCircleOutlined } from '@ant-design/icons';
import { Checkbox, type CheckboxChangeEvent, Tooltip, Tree } from 'antd';
import type { DataNode } from 'antd/es/tree';
import React, { useMemo } from 'react';

import { getImagePath } from '@/utils';

import styles from './MapAccess.module.scss';
import type { HierarchyNode } from './types';

interface MapTreeNode extends DataNode {
    key: React.Key;
    title: string;
    icon?: string;
    hasManageStores?: boolean;
    excludedStoresCount?: number;
    children?: MapTreeNode[];
}

const countAllNodes = (nodes: MapTreeNode[]): number => {
    let count = 0;
    nodes.forEach((node) => {
        count += 1;
        if (node.children) {
            count += countAllNodes(node.children);
        }
    });
    return count;
};

const buildPartialSelectionMap = (
    nodes: MapTreeNode[],
    checkedKeySet: ReadonlySet<React.Key>,
): Map<React.Key, boolean> => {
    const nodeMap = new Map<React.Key, boolean>();

    const traverse = (currentNodes: MapTreeNode[]) => {
        currentNodes.forEach((node) => {
            if (node.children && node.children.length > 0) {
                const childKeys = node.children.map((child) => child.key);
                const checkedChildCount = childKeys.filter((key) => checkedKeySet.has(key)).length;
                nodeMap.set(node.key, checkedChildCount > 0 && checkedChildCount < childKeys.length);

                traverse(node.children);
            }
        });
    };

    traverse(nodes);
    return nodeMap;
};

interface MapHierarchyTreeProps {
    hierarchy: HierarchyNode[];
    checkedKeys: React.Key[];
    onCheck: (checkedKeys: React.Key[]) => void;
    onManageStores?: (nodeKey: string) => void;
}

const MapHierarchyTree: React.FC<MapHierarchyTreeProps> = ({ hierarchy, checkedKeys, onCheck, onManageStores }) => {
    // Convert hierarchy nodes to Ant Design Tree format
    const treeData = useMemo(() => {
        const convertNode = (node: HierarchyNode): MapTreeNode => {
            return {
                key: node.key,
                title: node.title,
                icon: node.icon,

                hasManageStores: node.hasManageStores,
                excludedStoresCount: node.excludedStoresCount,
                children: node.children?.map(convertNode),
            };
        };

        return hierarchy.map(convertNode);
    }, [hierarchy]);

    // Check if a node has partial selection (some but not all children selected)
    const hasPartialSelection = useMemo(() => {
        const checkedKeySet = new Set<React.Key>(checkedKeys);
        return buildPartialSelectionMap(treeData, checkedKeySet);
    }, [treeData, checkedKeys]);

    const totalNodes = useMemo(() => countAllNodes(treeData), [treeData]);
    const checkedCount = checkedKeys.length;
    const isFullAccess = checkedCount > 0 && checkedCount === totalNodes;
    const isIndeterminate = checkedCount > 0 && checkedCount < totalNodes;

    const handleFullAccessChange = (e: CheckboxChangeEvent) => {
        if (e.target.checked) {
            // Select all nodes
            const getAllKeys = (nodes: DataNode[]): React.Key[] => {
                const keys: React.Key[] = [];
                nodes.forEach((node) => {
                    keys.push(node.key);
                    if (node.children) {
                        keys.push(...getAllKeys(node.children));
                    }
                });
                return keys;
            };
            onCheck(getAllKeys(treeData));
        } else {
            // Deselect all
            onCheck([]);
        }
    };

    return (
        <div className={styles['tree-panel']}>
            <div className={styles['tree-header']}>
                <div className={styles['full-access-row']}>
                    <Checkbox
                        checked={isFullAccess}
                        indeterminate={isIndeterminate}
                        onChange={handleFullAccessChange}
                    />
                    <span className={styles['full-access-label']}>Full Access</span>
                    <Tooltip title="Grants the user full visibility to every location in this map." placement="top">
                        <QuestionCircleOutlined className={styles['info-icon']} />
                    </Tooltip>
                </div>
            </div>
            <div className={styles['tree-container']}>
                <Tree
                    checkable
                    checkedKeys={checkedKeys}
                    onCheck={(keys) => {
                        onCheck(Array.isArray(keys) ? keys : keys.checked || []);
                    }}
                    treeData={treeData}
                    defaultExpandAll={false}
                    className={styles.tree}
                    showLine={false}
                    switcherIcon={({ expanded }) => {
                        if (expanded) {
                            return (
                                <img
                                    src={getImagePath('icons/caretdown.svg')}
                                    alt="Collapse"
                                    width={16}
                                    height={16}
                                    style={{ display: 'block', flexShrink: 0 }}
                                />
                            );
                        }
                        return (
                            <img
                                src={getImagePath('icons/caretdown-2.svg')}
                                alt="Expand"
                                width={16}
                                height={16}
                                style={{ display: 'block', flexShrink: 0 }}
                            />
                        );
                    }}
                    titleRender={(nodeData: MapTreeNode) => {
                        const nodeHasPartialSelection = hasPartialSelection.get(nodeData.key) ?? false;

                        return (
                            <div className={styles['tree-node-title']}>
                                {typeof nodeData.icon === 'string' && nodeData.icon.length > 0 && (
                                    <img
                                        src={getImagePath(nodeData.icon)}
                                        alt=""
                                        className={styles['tree-node-icon']}
                                        width={18}
                                        height={18}
                                    />
                                )}
                                <span>{nodeData.title}</span>
                                {nodeHasPartialSelection && (
                                    <button
                                        type="button"
                                        className={styles['view-selected-button']}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            // TODO: Implement view selected functionality
                                        }}
                                    >
                                        View Selected
                                    </button>
                                )}
                                {nodeData.hasManageStores && (
                                    <button
                                        type="button"
                                        className={styles['manage-stores-button']}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            onManageStores?.(String(nodeData.key));
                                        }}
                                    >
                                        <img
                                            src={getImagePath('icons/edit_icon.png')}
                                            alt="Manage"
                                            width={12}
                                            height={12}
                                        />
                                        <span>Manage Stores</span>
                                        {nodeData.excludedStoresCount !== undefined &&
                                            nodeData.excludedStoresCount > 0 && (
                                                <span className={styles['excluded-count']}>
                                                    (Excluded: {nodeData.excludedStoresCount} Store
                                                    {nodeData.excludedStoresCount !== 1 ? 's' : ''})
                                                </span>
                                            )}
                                    </button>
                                )}
                            </div>
                        );
                    }}
                />
            </div>
        </div>
    );
};

export default MapHierarchyTree;
