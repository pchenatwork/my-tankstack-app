import { CloseOutlined } from '@ant-design/icons';
import { Checkbox, Modal } from 'antd';
import React, { useState } from 'react';

import { CIButton } from '@/components/common';

import styles from './UnspecifiedLocationsModal.module.scss';

interface UnspecifiedLocationsModalProps {
    open: boolean;
    onCancel: () => void;
    onConfirm: () => void;
}

const UnspecifiedLocationsModal: React.FC<UnspecifiedLocationsModalProps> = ({ open, onCancel, onConfirm }) => {
    const [grantAbility, setGrantAbility] = useState(false);

    const handleOk = () => {
        if (grantAbility) {
            onConfirm();
            setGrantAbility(false);
        }
    };

    const handleCancel = () => {
        setGrantAbility(false);
        onCancel();
    };

    return (
        <Modal
            open={open}
            onCancel={handleCancel}
            footer={null}
            closable={false}
            centered
            width={510}
            className={styles.modal}
        >
            <div className={styles.container}>
                {/* Header */}
                <div className={styles.header}>
                    <div className={styles['header-left']}>
                        <span className={styles.title}>Allow User to View Unspecified Locations?</span>
                    </div>
                    <button type="button" className={styles['close-button']} onClick={handleCancel}>
                        <CloseOutlined />
                    </button>
                </div>

                {/* Divider */}
                <div className={styles.divider} />

                {/* Body */}
                <div className={styles.body}>
                    <p className={styles.message}>
                        This gives the user the ability to view unassigned locations that have not been added to the map
                        hierarchy.
                    </p>
                    <div className={styles.checkboxRow}>
                        <Checkbox checked={grantAbility} onChange={(e) => setGrantAbility(e.target.checked)}>
                            Grant this ability to the user
                        </Checkbox>
                    </div>
                </div>

                {/* Footer */}
                <div className={styles.footer}>
                    <CIButton variant="secondary" size="small" onClick={handleCancel}>
                        Cancel
                    </CIButton>
                    <CIButton variant="primary2" size="small" onClick={handleOk} disabled={!grantAbility}>
                        OK
                    </CIButton>
                </div>
            </div>
        </Modal>
    );
};

export default UnspecifiedLocationsModal;
