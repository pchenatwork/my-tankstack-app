import './Sidebar.scss';

import { LeftOutlined, RightOutlined } from '@ant-design/icons';
import { Menu, type MenuProps, Tooltip } from 'antd';
import Sider from 'antd/es/layout/Sider';
import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

import { useAuthStore } from '@/store/authStore';
import type { MenuItem } from '@/types/user';
import { getImagePath } from '@/utils';

type AntMenuItem = NonNullable<MenuProps['items']>[number];

type ViewOption = { key: string; icon: string; alt: string };

const renderMenuItemLabel = (label: string, icon?: string, badge?: number) => (
    <div className="sidebar-menu-item-label">
        {icon && (
            <span className="icon-wrap">
                <img className="sidebar-menu-item-icon" src={icon} alt="" />
            </span>
        )}
        <span className="label">{label}</span>
        {badge && <span className="badge">{badge}</span>}
    </div>
);

type SidebarProps = {
    collapsed: boolean;
    onCollapse: () => void;
    mobile: boolean;
    view: string;
    onViewChange: (view: string) => void;
};

export default function Sidebar({ collapsed, onCollapse, mobile, view, onViewChange }: SidebarProps) {
    const location = useLocation();
    const navigate = useNavigate();
    const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
    const [openKeys, setOpenKeys] = useState<string[]>([]);
    const user = useAuthStore((s) => s.user);

    // Extract permissions and view option icons from payload
    const rawPermissions = user?.payLoad?.permissions;
    const permissions = useMemo(() => rawPermissions ?? [], [rawPermissions]);
    const viewOptionIconsIds = user?.payLoad?.viewOptionIcons;

    // Separate sticky items and regular menu items
    const { stickyItems, regularMenuItems } = useMemo(() => {
        const stickyItems: MenuItem[] = [];
        const regularMenuItems: MenuItem[] = [];

        const viewOptionIds = viewOptionIconsIds ? Object.values(viewOptionIconsIds) : [];

        permissions.forEach((p) => {
            // Check if this group contains view option icons (to identify it as the View Options group)
            const isViewOptionsGroup = p.children?.some((c) => c.id && viewOptionIds.includes(c.id));

            // Filter children to exclude icons
            // We create a new array for children to avoid mutating the original permissions
            const filteredChildren = p.children?.filter((c) => !c.id || !viewOptionIds.includes(c.id)) || [];

            // Create a copy of the item with filtered children
            const itemWithFilteredChildren = { ...p, children: filteredChildren };

            // IMPORTANT: Respect each child's isSticky so only truly-sticky items stay sticky.
            if (isViewOptionsGroup) {
                const stickyChildren = filteredChildren
                    .filter((c) => c.isSticky)
                    .map((c) => ({ ...c, order: p.order }));

                const nonStickyChildren = filteredChildren
                    .filter((c) => !c.isSticky)
                    .map((c) => ({ ...c, order: p.order }));

                if (stickyChildren.length) stickyItems.push(...stickyChildren);
                if (nonStickyChildren.length) regularMenuItems.push(...nonStickyChildren);
                return;
            }

            if (p.isSticky) {
                // Add the whole group as a sticky item, but with filtered children
                if (filteredChildren.length > 0 || !p.children) {
                    stickyItems.push(itemWithFilteredChildren);
                }
            } else {
                // Regular item
                if (filteredChildren.length > 0 || !p.children) {
                    regularMenuItems.push(itemWithFilteredChildren);
                }
            }
        });

        return { stickyItems, regularMenuItems };
    }, [permissions, viewOptionIconsIds]);

    // Generate view options from API
    const viewOptions: ViewOption[] = useMemo(() => {
        if (!viewOptionIconsIds || permissions.length === 0) return [];

        // Find the group that contains the view options
        // We look for any group that has children matching the IDs
        const viewOptionIds = Object.values(viewOptionIconsIds);
        const viewOptionsGroup = permissions.find((p) => p.children?.some((c) => c.id && viewOptionIds.includes(c.id)));

        if (!viewOptionsGroup?.children) return [];

        const icons: ViewOption[] = [];
        const { companyIconId, regionIconId, districtIconId, storeIconId } = viewOptionIconsIds;

        // Helper to find item by ID
        const findItem = (id: number) => viewOptionsGroup.children?.find((c) => c.id === id);

        const companyItem = findItem(companyIconId);
        if (companyItem)
            icons.push({
                key: 'global',
                icon: getImagePath(`icons/${companyItem.icon}`),
                alt: companyItem.tooltip || companyItem.text,
            });

        const regionItem = findItem(regionIconId);
        if (regionItem)
            icons.push({
                key: 'map',
                icon: getImagePath(`icons/${regionItem.icon}`),
                alt: regionItem.tooltip || regionItem.text,
            });

        const districtItem = findItem(districtIconId);
        if (districtItem)
            icons.push({
                key: 'alerts',
                icon: getImagePath(`icons/${districtItem.icon}`),
                alt: districtItem.tooltip || districtItem.text,
            });

        const storeItem = findItem(storeIconId);
        if (storeItem)
            icons.push({
                key: 'store',
                icon: getImagePath(`icons/${storeItem.icon}`),
                alt: storeItem.tooltip || storeItem.text,
            });

        return icons;
    }, [permissions, viewOptionIconsIds]);

    const activeView = useMemo(() => viewOptions.find((v) => v.key === view) ?? viewOptions[0], [viewOptions, view]);

    const menuItemsData = useMemo(() => {
        const normalizeRouteKey = (route?: string | null): string | undefined => {
            if (!route) return undefined;
            const trimmed = route.replace(/^\/+/, '').replace(/\/+$/, '');
            return trimmed || undefined;
        };

        /**
         * Navigate to a route and update selected state
         */
        const handleMenuNavigation = (link: string) => {
            // Close any open flyouts immediately so they don't "ghost" over content.
            setOpenKeys([]);
            navigate(link);
            if (mobile) onCollapse();
        };

        /**
         * Generate a unique key for menu items
         */
        const generateMenuKey = (item: MenuItem, parentKey?: string): string => {
            const normalizedRoute = normalizeRouteKey(item.route);
            if (normalizedRoute) return normalizedRoute;
            const slug = item.text.toLowerCase().replace(/\s+/g, '-');
            return parentKey ? `${parentKey}-${slug}` : slug;
        };

        /**
         * Sort menu items by order field
         */
        const sortByOrder = (items: MenuItem[]): MenuItem[] => {
            return [...items].sort((a, b) => a.order - b.order);
        };

        const transformNode = (item: MenuItem, parentKey?: string): AntMenuItem | null => {
            const key = generateMenuKey(item, parentKey);
            const iconPath = item.icon ? getImagePath(`icons/${item.icon}`) : undefined;

            const normalizedRoute = normalizeRouteKey(item.route);
            const routePath = normalizedRoute ? `/${normalizedRoute}` : undefined;

            if (item.children?.length) {
                const sortedChildren = sortByOrder(item.children);

                if (item.embedChildren) {
                    const embeddedChildren = sortedChildren
                        .map((child) => transformNode(child, key))
                        .filter(Boolean) as AntMenuItem[];

                    return {
                        key: `${key}-group`,
                        type: 'group' as const,
                        label: <div className="group-heading">{item.text}</div>,
                        children: embeddedChildren,
                    };
                }

                const menuItem: AntMenuItem = {
                    key,
                    label: renderMenuItemLabel(item.text, iconPath),
                };

                if (routePath) {
                    menuItem.onClick = () => handleMenuNavigation(routePath);
                }

                const transformedChildren = sortedChildren
                    .map((child) => transformNode(child, key))
                    .filter(Boolean) as AntMenuItem[];

                if (transformedChildren.length > 0) {
                    Object.assign(menuItem, { children: transformedChildren });
                }

                return menuItem;
            }

            const leaf: AntMenuItem = {
                key,
                label: renderMenuItemLabel(item.text, iconPath),
            };

            if (routePath) {
                leaf.onClick = () => handleMenuNavigation(routePath);
            }

            return leaf;
        };

        /**
         * Transform top-level API items into menu groups
         * Top-level items (VMS, ADMIN) become group headers
         * Their children become the actual menu items
         */
        const transformMenuItemsToGroups = (items: MenuItem[]): MenuProps['items'] => {
            return sortByOrder(items).map((item) => {
                // Top-level items with children become groups (VMS, ADMIN, etc.)
                if (item.children?.length) {
                    const groupKey = generateMenuKey(item);
                    const transformedChildren = sortByOrder(item.children)
                        .map((child) => transformNode(child, groupKey))
                        .filter(Boolean) as AntMenuItem[];

                    return {
                        key: `${groupKey}-top-group`,
                        type: 'group' as const,
                        label: <div className="group-heading">{item.text}</div>,
                        children: transformedChildren,
                    };
                }

                // Items without children are rendered as regular menu items
                return transformNode(item);
            });
        };

        // Build menu: sticky items + dynamic API items
        // Use transformMenuItemsToGroups for sticky items as well to support groups in sticky section
        const stickyMenuItems: MenuProps['items'] = stickyItems.length
            ? transformMenuItemsToGroups(stickyItems) || []
            : [];

        const dynamicMenuItems: MenuProps['items'] = regularMenuItems.length
            ? transformMenuItemsToGroups(regularMenuItems) || []
            : [];

        return { stickyMenuItems, dynamicMenuItems, allMenuItems: [...stickyMenuItems, ...dynamicMenuItems] };
    }, [navigate, mobile, onCollapse, stickyItems, regularMenuItems]);

    const { stickyMenuItems, dynamicMenuItems, allMenuItems } = menuItemsData;

    const rootSubmenuKeys = useMemo(() => {
        const keys: string[] = [];

        const collectLevel = (items: MenuProps['items'] | undefined) => {
            if (!items) return;
            for (const item of items) {
                if (!item) continue;

                // Flatten group containers; their children are effectively top-level
                if (item.type === 'group' && 'children' in item && item.children) {
                    collectLevel(item.children);
                    continue;
                }

                // Only consider actual submenus at this level
                if ('children' in item && item.children && item.key) {
                    keys.push(item.key as string);
                }
            }
        };

        // Track root submenus for both sticky + dynamic sections
        collectLevel(stickyMenuItems);
        collectLevel(dynamicMenuItems);

        return Array.from(new Set(keys));
    }, [stickyMenuItems, dynamicMenuItems]);

    useEffect(() => {
        const normalizePathname = (pathname: string): string => {
            // Remove leading/trailing slashes but keep internal slashes for nested routes
            return pathname.replace(/^\/+|\/+$/g, '') || 'overview';
        };

        const collectAllMenuKeys = (items: MenuProps['items']): Set<string> => {
            const menuKeys = new Set<string>();

            if (!items) return menuKeys;

            const stack: MenuProps['items'] = [...items];

            while (stack.length > 0) {
                const item = stack.pop();

                if (item) {
                    if (item.key) {
                        menuKeys.add(item.key as string);
                    }

                    if ('children' in item && item.children) {
                        stack.push(...item.children);
                    }
                }
            }

            return menuKeys;
        };

        const syncSelectedKeyFromRoute = () => {
            const normalizedPath = normalizePathname(location.pathname);
            const allMenuKeys = collectAllMenuKeys(allMenuItems);

            // Check for exact match first
            if (allMenuKeys.has(normalizedPath)) {
                setSelectedKeys((prev) => {
                    if (prev.length === 0 || prev[0] !== normalizedPath) {
                        return [normalizedPath];
                    }
                    return prev;
                });
                return;
            }

            // Check if any menu key matches the path (for nested routes)
            // e.g., path "vms/web-client/live-view" should match key "vms/web-client/live-view"
            for (const key of allMenuKeys) {
                if (key === normalizedPath || normalizedPath.startsWith(key + '/')) {
                    setSelectedKeys((prev) => {
                        if (prev.length === 0 || prev[0] !== key) {
                            return [key];
                        }
                        return prev;
                    });
                    return;
                }
            }
        };

        syncSelectedKeyFromRoute();
    }, [location.pathname, allMenuItems]);

    useEffect(() => {
        // Any route change should close flyout popups.
        // Selected highlighting is still driven from the route via selectedKeys.
        setOpenKeys([]);
    }, [location.pathname]);

    // Handle View Option Logic (N, A, S)
    useEffect(() => {
        if (!selectedKeys.length || permissions.length === 0) return;

        const normalizeRouteKey = (route?: string | null): string | undefined => {
            if (!route) return undefined;
            const trimmed = route.replace(/^\/+/, '').replace(/\/+$/, '');
            return trimmed || undefined;
        };

        const findMenuItemByKey = (items: MenuItem[], key: string): MenuItem | null => {
            for (const item of items) {
                const itemKey = normalizeRouteKey(item.route) || item.text.toLowerCase().replace(/\s+/g, '-');
                if (itemKey === key) return item;

                if (item.children) {
                    const found = findMenuItemByKey(item.children, key);
                    if (found) return found;
                }
            }
            return null;
        };

        const selectedItem = findMenuItemByKey(permissions, selectedKeys[0]);

        if (selectedItem?.viewOption) {
            switch (selectedItem.viewOption) {
                case 'N':
                    // Disable all view options (unselect current)
                    if (view) onViewChange('');
                    break;
                case 'S':
                    // Select Store view option
                    if (view !== 'store') onViewChange('store');
                    break;
                case 'A':
                    // All enabled (do nothing or ensure one is selected? "A" usually means All available)
                    // If none selected, maybe select default? For now, leave as is.
                    break;
            }
        }
    }, [selectedKeys, permissions, view, onViewChange]);

    useEffect(() => {
        if (!collapsed) return;
        // Ensure popups close when the sidebar collapses.
        setOpenKeys([]);
    }, [collapsed]);

    const handleOpenChange = (keys: string[]) => {
        // Ensure only one root submenu is open at a time.
        // Keep nested keys under the currently-open root when applicable.
        const latestOpenKey = keys.find((k) => !openKeys.includes(k));
        if (!latestOpenKey) {
            setOpenKeys(keys);
            return;
        }

        if (rootSubmenuKeys.includes(latestOpenKey)) {
            setOpenKeys([latestOpenKey]);
            return;
        }

        setOpenKeys(keys);
    };

    const currentViewOptionRule = useMemo(() => {
        if (!selectedKeys.length || permissions.length === 0) return null;

        const normalizeRouteKey = (route?: string | null): string | undefined => {
            if (!route) return undefined;
            const trimmed = route.replace(/^\/+/, '').replace(/\/+$/, '');
            return trimmed || undefined;
        };

        const findMenuItemByKey = (items: MenuItem[], key: string): MenuItem | null => {
            for (const item of items) {
                const itemKey = normalizeRouteKey(item.route) || item.text.toLowerCase().replace(/\s+/g, '-');
                if (itemKey === key) return item;
                if (item.children) {
                    const found = findMenuItemByKey(item.children, key);
                    if (found) return found;
                }
            }
            return null;
        };
        const selectedItem = findMenuItemByKey(permissions, selectedKeys[0]);
        return selectedItem?.viewOption;
    }, [selectedKeys, permissions]);

    return (
        <Sider
            theme="light"
            trigger={null}
            collapsible
            collapsed={collapsed}
            width={260}
            collapsedWidth={74}
            className="sidebar relative flex flex-col border-r border-gray-200 bg-white"
        >
            {/* Logo + collapse button */}
            <div
                className="logo-area brand relative flex flex-none cursor-pointer items-center px-1"
                onClick={() => navigate('/overview')}
            >
                <img
                    className={`logo h-[64px] w-full flex-1 border-b border-gray-200 object-contain ${collapsed ? 'p-3' : ''}`}
                    src={
                        collapsed
                            ? getImagePath('icons/icon-cms-collapsed.png')
                            : getImagePath('icons/icon-central-logo.png')
                    }
                    alt="Central Management"
                />
                <button
                    className="collapse-btn flex h-[27px] w-[15px] cursor-pointer items-center justify-center rounded-r-[3px] border-none bg-green-600 p-0 text-white transition-colors duration-200"
                    title={collapsed ? 'Expand' : 'Collapse'}
                    onClick={(e) => {
                        e.stopPropagation();
                        onCollapse();
                    }}
                >
                    {collapsed ? <RightOutlined style={{ fontSize: 10 }} /> : <LeftOutlined style={{ fontSize: 10 }} />}
                </button>
            </div>

            {/* Sticky Section (View Options + Sticky Menu Items) */}
            <div className="flex-none">
                {/* View options / quick links */}
                <div
                    className={`view-options px-3 py-3 ${collapsed ? 'collapsed' : ''} ${currentViewOptionRule === 'N' ? 'pointer-events-none opacity-50' : ''}`}
                >
                    {!collapsed && (
                        <>
                            <div className="text-text-explanatory mb-2 text-[11px] leading-normal font-normal uppercase">
                                View Options
                            </div>
                            <div className="toggles grid grid-cols-4 gap-2">
                                {viewOptions.map((vo) => {
                                    const isDisabled = currentViewOptionRule === 'S' && vo.key !== 'store';
                                    return (
                                        <Tooltip key={vo.key} title={vo.alt}>
                                            <button
                                                className={[
                                                    'toggle hover:bg-side-panel-menu-hover grid h-12 w-12 cursor-pointer place-items-center border-0 border-transparent',
                                                    view === vo.key ? 'active' : '',
                                                    isDisabled ? 'cursor-not-allowed opacity-50' : '',
                                                ]
                                                    .filter(Boolean)
                                                    .join(' ')}
                                                onClick={() => !isDisabled && onViewChange(vo.key)}
                                                disabled={isDisabled}
                                            >
                                                <img className="w-8" src={vo.icon} alt={vo.alt} />
                                            </button>
                                        </Tooltip>
                                    );
                                })}
                            </div>
                        </>
                    )}

                    {collapsed && activeView && (
                        <Tooltip title={activeView.alt} placement="right">
                            <button
                                className="active bg-side-panel-view-options-selected hover:bg-side-panel-menu-hover mx-auto grid h-12 w-12 cursor-pointer place-items-center border-0 border-transparent"
                                onClick={() => onViewChange(activeView.key)}
                            >
                                <img className="w-8" src={activeView.icon} alt={activeView.alt} />
                            </button>
                        </Tooltip>
                    )}
                </div>

                {/* Sticky Menu Items */}
                {stickyMenuItems && stickyMenuItems.length > 0 && (
                    <div className="border-b border-gray-100 px-2 pb-2">
                        <Menu
                            mode="vertical"
                            selectedKeys={selectedKeys}
                            openKeys={collapsed ? undefined : openKeys}
                            onOpenChange={(keys) => handleOpenChange(keys as string[])}
                            items={stickyMenuItems}
                            className="ant-menu-custom"
                            style={{ border: 'none', background: 'transparent' }}
                            triggerSubMenuAction="hover"
                            subMenuCloseDelay={0}
                            subMenuOpenDelay={0}
                            getPopupContainer={(triggerNode) =>
                                ((triggerNode as HTMLElement).closest('.sidebar') as HTMLElement) || document.body
                            }
                            expandIcon={<RightOutlined />}
                        />
                    </div>
                )}
            </div>

            {/* Scrollable Menu Section */}
            <div className="flex-1 overflow-x-hidden overflow-y-auto px-2 py-3">
                <Menu
                    mode="vertical"
                    selectedKeys={selectedKeys}
                    openKeys={collapsed ? undefined : openKeys}
                    onOpenChange={(keys) => handleOpenChange(keys as string[])}
                    items={dynamicMenuItems}
                    className="ant-menu-custom"
                    style={{ border: 'none', background: 'transparent' }}
                    triggerSubMenuAction="hover"
                    subMenuCloseDelay={0}
                    subMenuOpenDelay={0}
                    getPopupContainer={(triggerNode) =>
                        ((triggerNode as HTMLElement).closest('.sidebar') as HTMLElement) || document.body
                    }
                    expandIcon={<RightOutlined />}
                />
            </div>
        </Sider>
    );
}
