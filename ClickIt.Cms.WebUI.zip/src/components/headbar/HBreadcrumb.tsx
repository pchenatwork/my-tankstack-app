// src/components/Breadcrumbs.tsx
import { useMemo } from 'react';
import { Breadcrumb, type BreadcrumbProps } from 'antd';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';
import { buildRouteMap, getRouteLabel } from '@/utils/breadcrumbUtils';
import { getImagePath } from '@/utils';


// Separator component (memoized)
const BreadcrumbSeparator = (
  <img
    src={getImagePath('icons/carot-right.png')}
    alt="separator"
    className="inline-block"
    style={{ width: 'auto', height: '18px' }}
  />
);

const HBreadcrumb = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const permissions = useAuthStore((s) => s.user?.payLoad?.permissions);

  // Build route map synchronously so it updates when permissions change
  // This ensures breadcrumbItems recalculates when permissions load after refresh
  const routeMap = useMemo(() => {
    return buildRouteMap(permissions);
  }, [permissions]);

  const segments = useMemo(
    () => location.pathname.split('/').filter(Boolean),
    [location.pathname],
  );

  const breadcrumbItems = useMemo<BreadcrumbProps['items']>(() => {
    // Pre-compute all cumulative paths incrementally to avoid redundant joins and slices
    const cumulativePaths: string[] = [];
    if (segments.length > 0) {
      cumulativePaths.push(segments[0]);
      for (let i = 1; i < segments.length; i++) {
        cumulativePaths.push(`${cumulativePaths[i - 1]}/${segments[i]}`);
      }
    }

    return cumulativePaths.map((routePath, idx) => {
      const url = `/${routePath}`;
      const segment = segments[idx];

      // Get label from route map, with fallback using the segment directly
      const label = getRouteLabel(routePath, routeMap, segment);

      const isLast = idx === segments.length - 1;

      const title = isLast ? (
        <span className="text-xs font-semibold text-white">{label}</span>
      ) : (
        <button
          type="button"
          onClick={() => navigate(url)}
          className="text-cms-text-white cursor-pointer text-xs font-semibold underline-offset-2 hover:underline"
        >
          {label}
        </button>
      );

      return {
        key: url,
        title,
      };
    });
  }, [segments, routeMap, navigate]);

  return (
    <div className="bg-cms-text-hyperlink rounded-b-sm border-b border-gray-200 px-5 py-2">
      <Breadcrumb separator={BreadcrumbSeparator} items={breadcrumbItems} />
    </div>
  );
};

export default HBreadcrumb;
