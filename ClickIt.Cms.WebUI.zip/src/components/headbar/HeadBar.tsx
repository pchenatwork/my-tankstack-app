// src/components/HeaderBar.tsx
import { type FC } from 'react';
import { BellFilled } from '@ant-design/icons';
import { Avatar, Button, Dropdown } from 'antd';
import { useNavigate } from 'react-router-dom';

import ClickitLogo from '@/assets/clickit-logo.png';
import ProfileDropdown, { type DisplayProfile } from './ProfileDropdown';
import HeaderBreadcrumb from './HBreadcrumb';
import { auth } from '@/api/auth';
import { useAuthStore } from '@/store/authStore';
import { getImagePath } from '@/utils';
import { AdminAccessLevel } from '@/constants';

const HeadBar: FC = () => {
    const navigate = useNavigate();
    const clearUser = useAuthStore((s) => s.clearUser);
    const user = useAuthStore((s) => s.user)?.payLoad?.user;

    const handleSettings = () => {
        // TODO: route to settings page
        console.log('Go to settings');
    };

    const handleLogout = async () => {
        try {
            await auth.logout();
        } catch {
            // TODO: proper error handling
        }
        clearUser();
        navigate('/login', { replace: true });
    };

    const firstName = user?.firstName || '';
    const lastName = user?.lastName || '';
    const role = user?.securityLevel?.name || 'User';
    const initials = ((firstName?.[0] || '') + (lastName?.[0] || '')).toUpperCase();

    const mainProfile: DisplayProfile = {
        name: `${firstName} ${lastName}`.trim() || 'User',
        initials,
        role,
        bgColor: user?.securityLevel?.backColor,
        hasFullAccess: user?.accessLevel === AdminAccessLevel.Full,
    };

    return (
        <>
            {/* Fixed top bar aligned with sidebar width */}
            <div className="box-border flex h-16 w-full items-center justify-between bg-white px-5 py-3">
                {/* Left: Powered by + logo */}
                <div className="flex items-center gap-2">
                    <span className="text-cms-text-main hidden text-xs leading-none md:inline">Powered by</span>
                    <img src={ClickitLogo} alt="ClickIt Logo" className="block h-10" />
                </div>

                {/* Right: bell + user */}
                <div className="flex items-center gap-5">
                    <Button type="text" className="relative flex !p-0 items-center justify-center">
                        <BellFilled className="text-cms-text-main text-2xl" width={24} height={24} />
                    </Button>

                    <Dropdown
                        trigger={['click']}
                        placement="bottomRight"
                        popupRender={() => (
                            <ProfileDropdown
                                onSettings={handleSettings}
                                onLogout={handleLogout}
                                mainProfile={mainProfile}
                            />
                        )}
                    >
                        <div className="flex cursor-pointer items-center gap-2">
                            <Avatar
                                size="small"
                                style={{ backgroundColor: mainProfile.bgColor }}
                                className="font-semibold flex-shrink-0"
                            >
                                {mainProfile.initials}
                            </Avatar>
                            <span className="text-cms-text-main hidden text-sm font-normal md:inline">
                                {mainProfile.name}
                            </span>
                            <img
                                src={getImagePath('icons/icon-arrow-down.png')}
                                alt="dropdown"
                                className="hidden h-5 w-5 flex-shrink-0 md:inline"
                            />
                        </div>
                    </Dropdown>
                </div>
            </div>

            {/* Breadcrumb bar under the fixed header */}
            <HeaderBreadcrumb />
        </>
    );
};

export default HeadBar;
