// src/components/ProfileDropdown.tsx
import { CheckCircleFilled, SettingOutlined, ArrowLeftOutlined } from '@ant-design/icons';
import { Avatar, Divider } from 'antd';
import { getImagePath } from '@/utils';

export type DisplayProfile = {
    name: string;
    initials: string;
    role?: string;
    bgColor?: string;
    hasFullAccess?: boolean;
    shared?: boolean;
    sharedUntil?: string;
};

export type ProfileDropdownProps = {
    onSettings: () => void;
    onLogout: () => void;
    mainProfile: DisplayProfile;
    profileList?: DisplayProfile[];
};

const DEFAULT_AVATAR_BG = '#F18524';

const ProfileDropdown = ({ onSettings, onLogout, mainProfile, profileList }: ProfileDropdownProps) => {
    const starIcon = mainProfile.hasFullAccess ? getImagePath('icons/icon-star-filled.png') : getImagePath('icons/icon-star-half-filled.png');
    const avatarBg = mainProfile.bgColor ?? DEFAULT_AVATAR_BG;

    const effectiveProfileList = profileList && profileList.length > 0 ? profileList : [mainProfile];

    return (
        <div className="bg-side-panel-background w-[280px] rounded-lg p-4 shadow-[0_4px_4px_rgba(0,0,0,0.25)]">
            {/* Top: Star + avatar + name + role */}
            <div className="relative mb-4">
                <img src={starIcon} alt="star" className="absolute top-1 left-0 h-5 w-5" />

                <div className="flex flex-col items-center gap-3">
                    <Avatar
                        size="large"
                        className="text-xl font-semibold"
                        style={{ backgroundColor: avatarBg, color: 'white' }}
                    >
                        {mainProfile.initials}
                    </Avatar>

                    {mainProfile.role && (
                        <span
                            style={{ backgroundColor: avatarBg }}
                            className="inline-flex items-center rounded-sm px-1 py-0 text-sm font-normal text-white"
                        >
                            {mainProfile.role}
                        </span>
                    )}
                </div>
            </div>

            <Divider className="!my-3" />

            {/* Profiles section */}
            <div className="text-cms-text-main mb-2 text-xs">Profile(s)</div>

            {effectiveProfileList.map((profile, idx) => (
                <div className="mb-2 flex items-center justify-between" key={`${profile.name}-${idx}`}>
                    <div className="flex items-center gap-2">
                        <Avatar
                            size="small"
                            style={{
                                backgroundColor: profile.bgColor || avatarBg,
                                color: 'white',
                            }}
                        >
                            {profile.initials}
                        </Avatar>
                        <span className="text-cms-text-main text-base">{profile.name}</span>
                    </div>

                    {!profile.shared && <CheckCircleFilled className="!text-cms-level-green" />}

                    {profile.shared && (
                        <span className="text-cms-text-explanatory text-[11px]">
                            (Shared until {profile.sharedUntil})
                        </span>
                    )}
                </div>
            ))}

            <Divider className="!my-3" />

            {/* My Account */}
            <div className="text-cms-text-main mb-2 text-xs">My Account</div>

            <button
                type="button"
                onClick={onSettings}
                className="text-cms-text-main hover:text-cms-btn-secondary-hover-text-stroke flex w-full cursor-pointer items-center gap-2 py-1.5 text-left text-sm"
            >
                <SettingOutlined className="text-base" />
                <span>Settings</span>
            </button>

            <button
                type="button"
                onClick={onLogout}
                className="text-cms-text-main hover:text-cms-btn-secondary-hover-text-stroke mt-1 flex w-full cursor-pointer items-center gap-2 py-1.5 text-left text-sm"
            >
                <ArrowLeftOutlined className="text-base" />
                <span>Logout</span>
            </button>
        </div>
    );
};

export default ProfileDropdown;
