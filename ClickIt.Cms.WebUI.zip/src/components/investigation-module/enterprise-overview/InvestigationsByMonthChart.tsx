import ChartComponent from "./ChartComponent";

//  Documentation:
//  https://echarts.apache.org/en/option.html#series-bar.itemStyle

const barColorOpen = '#007BFF';
const barColorClosed = '#6AD2F8';

function Title() {
    return (
        <div className="absolute border-[#d8d8d8] border-[0px_0px_0.5px] border-solid h-[40px] left-[8px] top-[2px] w-[1100px]" data-name="Overview.Title">
            <p className="absolute font-['Open_Sans:SemiBold',sans-serif] font-semibold leading-[1.3] left-[4px] text-[#4d5154] text-[16px] text-nowrap top-[9.5px] tracking-[0.32px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
                Investigations By Month
            </p>
        </div>
    );
}


export type IMOverviewChartData =
    {
        foo: any;
    };

export default function InvestigationsByMonthChart() {

    const cornerRadius = 5;

    const chartOption = {
        title: {
            text: '',
        },
        tooltip: {},
        xAxis: {
            data: ['Jan 2025', 'Feb 2025', 'Mar 2025', 'Apr 2025', 'May 2025', 'Jun 2025', 'Jul 2025', 'Aug 2025', 'Sep 2025', 'Oct 2025', 'Nov 2025', 'Dec 2025'],
        },
        yAxis: {},
        series: [
            {
                name: 'Investigations Opened',
                type: 'bar',
                data: [5, 20, 36, 10, 10, 20, 5, 20, 36, 10, 10, 20],
                itemStyle: {
                    color: barColorOpen,
                    borderRadius: [cornerRadius, cornerRadius, 0, 0]
                },
            },
            {
                name: 'Investigations Closed',
                type: 'bar',
                data: [10, 12, 2, 13, 14, 11, 10, 12, 2, 33, 14, 11],
                itemStyle: {
                    color: barColorClosed,
                    borderRadius: [cornerRadius, cornerRadius, 0, 0]
                },
            },
        ],
    }

    return (
        <div className="bg-white relative rounded-[10px] shadow-[0px_2px_6px_0px_rgba(144,146,148,0.2)] h-[full] w-[1125px]" data-name="OverviewContent">
        <Title />
            <ChartComponent option={chartOption} />
        </div>
    );
}
