//import type { CSSProperties, FC } from 'react';
import svgPaths from './svgPaths';
//import React = require('react');

function OverviewContentOpenInvestigations({ openInvestigations }: any) {
    return (
        <div className="h-[99px] relative shrink-0 w-[296px]" data-name="Overview.Content.OpenInvestigations">
            <div aria-hidden="true" className="absolute border-[#d8d8d8] border-[0px_1px_0px_0px] border-solid inset-0 pointer-events-none" />
            <p className="absolute font-['Open_Sans:Bold',sans-serif] font-bold leading-[78px] left-[5px] text-[#4d5154] text-[32px] text-nowrap top-0 whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
                {openInvestigations}
            </p>
            <p className="[text-underline-position:from-font] absolute decoration-solid font-['Open_Sans:Regular',sans-serif] font-normal leading-[1.5] left-[5px] text-[#0168a7] text-[14px] text-nowrap top-[68px] tracking-[0.28px] underline whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
                View Details
            </p>
            <p className="absolute font-['Open_Sans:SemiBold',sans-serif] font-semibold leading-[1.3] left-[79px] text-[#4d5154] text-[16px] text-nowrap top-[30px] tracking-[0.32px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
                Open Investigations
            </p>
        </div>
    );
}

function OverviewContentVideoAvailableBadge({ percentage }: any) {
    return (
        <div className="bg-[#d6efea] content-stretch flex gap-[5px] items-center px-[8px] py-[4px] relative rounded-[90px] shrink-0" data-name="Overview.Content.VideoAvailableBadge">
            <p className="font-['Figtree:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#009908] text-[11px] text-nowrap uppercase whitespace-pre">
                {percentage.toLocaleString(undefined, { maximumFractionDigits: 2 })}%
            </p>
        </div>
    );
}

function VideoAvailableWithBadge({ openVideoAvailable, openTotal }: any) {

    const percentage = openTotal == 0 ? 0 : (openVideoAvailable / openTotal) * 100;

    return (
        <div className="content-stretch flex gap-[10px] items-center relative shrink-0" data-name="VideoAvailableWithBadge">
            <p className="[text-underline-position:from-font] decoration-solid font-['Open_Sans:Bold',sans-serif] font-bold leading-[1.2] relative shrink-0 text-[#0168a7] text-[26px] text-nowrap tracking-[0.52px] underline whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
                {openVideoAvailable}
            </p>
            <OverviewContentVideoAvailableBadge percentage={percentage} />
        </div>
    );
}

function Legend() {
    return (
        <div className="content-stretch flex gap-[10px] items-center relative shrink-0" data-name="Legend">
            <div className="relative shrink-0 size-[14px]" data-name="Ellipse">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
                    <circle cx="7" cy="7" fill="var(--fill-0, #00AA28)" id="Ellipse" r="7" />
                </svg>
            </div>
            <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[1.5] relative shrink-0 text-[#7a7c7f] text-[12px] text-nowrap tracking-[0.24px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
                Video Available
            </p>
        </div>
    );
}

function OverviewContentVideoAvailable({ totalOpenVideoAvailable, openTotal }: any) {
    return (
        <div className="content-stretch flex flex-col gap-[5px] items-start relative shrink-0 w-[115px]" data-name="Overview.Content.VideoAvailable">
            <VideoAvailableWithBadge openVideoAvailable={totalOpenVideoAvailable} openTotal={openTotal} />
            <Legend />
        </div>
    );
}

function TotalInvestigationsSectionVideoExpiringSoonBadge({ percentage }: any) {

    return (
        <div className="bg-[#fff7e1] content-stretch flex gap-[5px] items-center px-[8px] py-[4px] relative rounded-[90px] shrink-0" data-name="Total InvestigationsSectionVideoExpiringSoonBadge">
            <p className="font-['Figtree:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#f47600] text-[11px] text-nowrap uppercase whitespace-pre">
                {percentage.toLocaleString(undefined, { maximumFractionDigits: 2 })}%
            </p>
        </div>
    );
}

function VideoExpiringSoonWithBadge({ openVideoExpiringSoon, openTotal }: any) {
    const percentage = openTotal == 0 ? 0 : (openVideoExpiringSoon / openTotal) * 100;

    return (
        <div className="content-stretch flex gap-[10px] items-center relative shrink-0" data-name="VideoExpiringSoonWithBadge">
            <p className="[text-underline-position:from-font] decoration-solid font-['Open_Sans:Bold',sans-serif] font-bold leading-[1.2] relative shrink-0 text-[#0168a7] text-[26px] text-nowrap tracking-[0.52px] underline whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
                {openVideoExpiringSoon}
            </p>
            <TotalInvestigationsSectionVideoExpiringSoonBadge percentage={percentage} />
        </div>
    );
}

function Legend1() {
    return (
        <div className="content-stretch flex gap-[10px] items-center relative shrink-0" data-name="Legend">
            <div className="relative shrink-0 size-[14px]" data-name="Ellipse">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
                    <circle cx="7" cy="7" fill="var(--fill-0, #F47600)" id="Ellipse" r="7" />
                </svg>
            </div>
            <p className="font-['Figtree:Regular',sans-serif] font-normal leading-[20px] relative shrink-0 text-[#7a7c7f] text-[13px] text-nowrap whitespace-pre">Video Expiring Soon</p>
        </div>
    );
}

function OverviewContentVideoExpiringSoon({ openVideoExpiringSoon, openTotal }: any) {
    return (
        <div className="content-stretch flex flex-col gap-[5px] items-start relative shrink-0 w-[155px]" data-name="Overiew.Content.VideoExpiringSoon">
            <VideoExpiringSoonWithBadge openVideoExpiringSoon={openVideoExpiringSoon} openTotal={openTotal} />
            <Legend1 />
        </div>
    );
}

function VideoExpiredBadge({ percentage }: any) {
    return (
        <div className="bg-[#ffe1e2] content-stretch flex gap-[5px] items-center px-[8px] py-[4px] relative rounded-[90px] shrink-0" data-name="VideoExpiredBadge">
            <p className="font-['Figtree:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[11px] text-[red] text-nowrap uppercase whitespace-pre">
                {percentage.toLocaleString(undefined, { maximumFractionDigits: 2 })}%
            </p>
        </div>
    );
}

function VideoExpiredWithBadge({ openVideoExpired, openTotal }: any) {

    const percentage = openTotal == 0 ? 0 : (openVideoExpired / openTotal) * 100;

    return (
        <div className="content-stretch flex gap-[10px] items-center relative shrink-0" data-name="VideoExpiredWithBadge">
            <p className="[text-underline-position:from-font] decoration-solid font-['Open_Sans:Bold',sans-serif] font-bold leading-[1.2] relative shrink-0 text-[#0168a7] text-[26px] text-nowrap tracking-[0.52px] underline whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
                {openVideoExpired}
            </p>
            <VideoExpiredBadge percentage={percentage} />
        </div>
    );
}

function Legend2() {
    return (
        <div className="content-stretch flex gap-[10px] items-center relative shrink-0" data-name="Legend">
            <div className="relative shrink-0 size-[14px]" data-name="Ellipse">
                <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 14">
                    <circle cx="7" cy="7" fill="var(--fill-0, #FF0000)" id="Ellipse" r="7" />
                </svg>
            </div>
            <p className="font-['Figtree:Regular',sans-serif] font-normal leading-[20px] relative shrink-0 text-[13px] text-[red] text-nowrap whitespace-pre">Video Expired</p>
        </div>
    );
}

function VideoExpired({ openVideoExpired, openTotal }: any) {
    return (
        <div className="content-stretch flex flex-col gap-[5px] items-start relative shrink-0 w-[155px]" data-name="VideoExpired">
            <VideoExpiredWithBadge openVideoExpired={openVideoExpired} openTotal={openTotal} />
            <Legend2 />
        </div>
    );
}

function OverviewContentNumbers(
    { openTotal,
        openVideoAvailable,
        openVideoExpiringSoon,
        openVideoExpired }: any) {

    return (
        <div className="content-stretch flex gap-[78px] items-center relative shrink-0 w-[1088px]" data-name="Overview.Content.Numbers">
            <OverviewContentOpenInvestigations openInvestigations={openTotal} />
            <OverviewContentVideoAvailable totalOpenVideoAvailable={openVideoAvailable} openTotal={openTotal} />
            <OverviewContentVideoExpiringSoon openVideoExpiringSoon={openVideoExpiringSoon} openTotal={openTotal} />
            <VideoExpired openVideoExpired={openVideoExpired} openTotal={openTotal} />
        </div>
    );
}

function OverviewContentProgressBar({ ratioAvailable, ratioExpiringSoon, ratioExpired }: any) {

    const fullWidth = 1088;

    //  Calculate the relative widths
    const availableWidth = (fullWidth * ratioAvailable)
    const expiringWidth = (fullWidth * ratioExpiringSoon)
    const expiredWidth = (fullWidth * ratioExpired)


    //  Put them in an array
    const bars = [
        { value: ratioAvailable, key: 'available', color: '#00aa28', width: availableWidth },
        { value: ratioExpiringSoon, key: 'expiring', color: '#f47600', width: expiringWidth },
        { value: ratioExpired, key: 'expired', color: '#ff0000', width: expiredWidth },
    ]

    //  Sort so we have the largest value on the bottom
    const sortedBars = [...bars].sort((a, b) => a.value - b.value);

    let styles: (any)[] | { width: string; backgroundColor: string; }[] = [];

    let index = 0;

    sortedBars.forEach((bar) => {

        let sWidth = '';

        //  First one is the bottom-most one, at full width since
        //  the other ones paint over some of it
        if (index == 0)
            sWidth = fullWidth.toString() + "px";
        else
            //  Second one is the middle one, it's width is that of itself
            //  AND of the bar underneath it.
            if (index == 1) {
                sWidth = (sortedBars[2].width + bar.width).toString() + "px";
            }
            else
                //  The highest-percentage one is the top-most one
                if (index == 2) {
                    sWidth = bar.width.toString() + "px";
                }

        let style = {
            width: sWidth,
            backgroundColor: bar.color,
        }

        styles.push(style);

        index += 1;
    });

    {/*
        <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0 w-full" data-name="Overview.Content.ProgressBar.Bar">
            <div className="[grid-area:1_/_1] bg-[red] h-[30px] ml-0 mt-0 rounded-[6px] w-[1088px]" data-name="barVideoExpired" />
            <div className="[grid-area:1_/_1] bg-[#f47600] h-[30px] ml-0 mt-0 rounded-bl-[6px] rounded-tl-[6px] w-[1033px]" data-name="barVideoExpiringSoon" />
            <div className="[grid-area:1_/_1] bg-[#00aa28] h-[30px] ml-0 mt-0 rounded-bl-[6px] rounded-tl-[6px] w-[898px]" data-name="barVideoAvailable" />
        </div>
        */}


    return (
        <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0 w-full" data-name="Overview.Content.ProgressBar.Bar">
            <div className="[grid-area:1_/_1] h-[30px] ml-0 mt-0 rounded-[6px]" style={styles[0]} data-name="barBottom" />
            <div className="[grid-area:1_/_1] h-[30px] ml-0 mt-0 rounded-bl-[6px] rounded-tl-[6px]" style={styles[1]} data-name="barMiddle" />
            <div className="[grid-area:1_/_1] h-[30px] ml-0 mt-0 rounded-bl-[6px] rounded-tl-[6px]" style={styles[2]} data-name="barTop" />
        </div>
    );
}

function OverviewContent({
    openTotal,
    openVideoAvailable,
    openVideoExpiringSoon,
    openVideoExpired,
    closedTotal,
    closedArchived,
    closedDeleted,
    averageDurationInDays,
    totalInvestigations,
    yearToDate }: IMOverview) {

    const ratioAvailable = openTotal == 0 ? 0 : (openVideoAvailable / openTotal);
    const ratioExpiringSoon = openTotal == 0 ? 0 : (openVideoExpiringSoon / openTotal);
    const ratioExpired = openTotal == 0 ? 0 : (openVideoExpired / openTotal);

    return (
        <div className="absolute content-stretch flex flex-col gap-[17px] h-[171px] items-start left-[19px] top-[49px] w-[auto]" data-name="Overview.Content">
            <OverviewContentNumbers
                closedArchived={closedArchived}
                closedDeleted={closedDeleted}
                closedTotal={closedTotal}
                averageDurationInDays={averageDurationInDays}
                openTotal={openTotal}
                openVideoAvailable={openVideoAvailable}
                openVideoExpired={openVideoExpired}
                openVideoExpiringSoon={openVideoExpiringSoon}
                totalInvestigations={totalInvestigations}
                yearToDate={yearToDate}
            />
            <OverviewContentProgressBar
                ratioAvailable={ratioAvailable}
                ratioExpiringSoon={ratioExpiringSoon}
                ratioExpired={ratioExpired}
            />
        </div>
    );
}

function ClosedInvestigationsSectionArchived({ archived }: any) {
    return (
        <div className="absolute content-stretch flex gap-[5px] items-center left-[374px] text-nowrap top-[14px] whitespace-pre" data-name="ClosedInvestigationsSection.Archived">
            <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[1.5] relative shrink-0 text-[#4d5154] text-[14px] tracking-[0.28px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                Archived:
            </p>
            <p className="[text-underline-position:from-font] decoration-solid font-['Open_Sans:Bold',sans-serif] font-bold leading-[1.3] relative shrink-0 text-[#0168a7] text-[16px] tracking-[0.32px] underline" style={{ fontVariationSettings: "'wdth' 100" }}>
                {archived.toLocaleString(undefined)}
            </p>
        </div>
    );
}

function ClosedInvestigationsSectionDeleted({ deleted }: any) {
    return (
        <div className="absolute content-stretch flex gap-[5px] items-center left-[560px] text-nowrap top-[14px] whitespace-pre" data-name="ClosedInvestigationsSection.Deleted">
            <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[1.5] relative shrink-0 text-[#4d5154] text-[14px] tracking-[0.28px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                Deleted:
            </p>
            <p className="[text-underline-position:from-font] decoration-solid font-['Open_Sans:Bold',sans-serif] font-bold leading-[1.3] relative shrink-0 text-[#0168a7] text-[16px] tracking-[0.32px] underline" style={{ fontVariationSettings: "'wdth' 100" }}>
                {deleted.toLocaleString(undefined)}
            </p>
        </div>
    );
}

function ClosedInvestigationsSectionAverageInvestigationLength({ averageInvestigationDuration }: any) {
    return (
        <div className="absolute content-stretch flex gap-[5px] items-center leading-[0] left-[758px] text-[#4d5154] text-[0px] text-nowrap top-[14px] w-[283px] whitespace-pre" data-name="ClosedInvestigationsSection.AverageInvestigationLength">
            <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[1.5] relative shrink-0 text-[14px] tracking-[0.28px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                <span>Average Investigation Length: </span>
                <span className="text-[#4d5154] font-bold">{averageInvestigationDuration} days</span>
            </p>
        </div>
    );
}

function ClosedInvestigationsSection({ closedTotal, closedArchived, closedDeleted, averageDuration }: any) {
    return (
        <div className="absolute bg-white border border-[#c6c6c6] border-solid h-[53px] left-[19px] overflow-clip rounded-[10px] shadow-[0px_2px_6px_0px_rgba(144,146,148,0.2)] top-[217px] w-[1088px]" data-name="ClosedInvestigationsSection">
            <ClosedInvestigationsSectionArchived archived={closedArchived} />
            <ClosedInvestigationsSectionDeleted deleted={closedDeleted} />
            <ClosedInvestigationsSectionAverageInvestigationLength averageInvestigationDuration={averageDuration} />
            <div className="absolute flex h-[36px] items-center justify-center left-[294px] top-[7px] w-0" style={{ "--transform-inner-width": "36", "--transform-inner-height": "0" } as React.CSSProperties}>
                <div className="flex-none rotate-[270deg]">
                    <div className="h-0 relative w-[36px]" data-name="ClosedInvestigationsSection.Line">
                        <div className="absolute bottom-0 left-0 right-0 top-[-1px]">
                            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 1">
                                <line id="ClosedInvestigationsSection.Line" stroke="var(--stroke-0, #D8D8D8)" x2="36" y1="0.5" y2="0.5" />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
            <p className="absolute font-['Open_Sans:Regular',sans-serif] font-normal leading-[1.5] left-[13px] text-[#4d5154] text-[0px] text-[14px] text-nowrap top-[14px] tracking-[0.28px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
                Closed Investigations<span style={{ fontVariationSettings: "'wdth' 100" }}>:</span>{" "}
            </p>
            <p className="absolute font-['Open_Sans:Bold',sans-serif] font-bold leading-[1.3] left-[166px] text-[#4d5154] text-[16px] text-nowrap top-[14px] tracking-[0.32px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
                {closedTotal.toLocaleString(undefined)}
            </p>
        </div>
    );
}

function TotalInvestigationsSectionYearToDate({ yearToDate }: any) {
    return (
        <div className="absolute content-stretch flex gap-[5px] items-center left-[374px] text-nowrap top-[14px] whitespace-pre" data-name="TotalInvestigationsSection.Year to Date">
            <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[1.5] relative shrink-0 text-[#4d5154] text-[14px] tracking-[0.28px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                Year to Date:
            </p>
            <p className="[text-underline-position:from-font] decoration-solid font-['Open_Sans:Bold',sans-serif] font-bold leading-[1.3] relative shrink-0 text-[#0168a7] text-[16px] tracking-[0.32px] underline" style={{ fontVariationSettings: "'wdth' 100" }}>
                {yearToDate.toLocaleString(undefined)}
            </p>
        </div>
    );
}

function TotalInvestigationsSectionTotalInvestigations({ total }: any) {
    return (
        <div className="absolute content-stretch flex gap-[5px] items-center left-[13px] text-[#4d5154] text-nowrap top-[14px] whitespace-pre" data-name="TotalInvestigationsSection/TotalInvestigations">
            <p className="font-['Open_Sans:Regular',sans-serif] font-normal leading-[1.5] relative shrink-0 text-[0px] text-[14px] tracking-[0.28px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                Total Investigations
                <span className="text-[#4d5154]" style={{ fontVariationSettings: "'wdth' 100" }}>
                    :
                </span>
                <span className="text-[#4d5154]"> </span>
            </p>
            <p className="font-['Open_Sans:Bold',sans-serif] font-bold leading-[1.3] relative shrink-0 text-[16px] tracking-[0.32px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                {total.toLocaleString(undefined)}
            </p>
        </div>
    );
}

function TrendUp() {
    return (
        <div className="relative shrink-0 size-[13px]" data-name="TrendUp">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13 13">
                <g id="TrendUp">
                    <path d={svgPaths.pathCommands} fill="var(--fill-0, #00997E)" id="Vector" />
                </g>
            </svg>
        </div>
    );
}

function TotalInvestigationsSectionYearToDateBadge({ percentage }: any) {

    return (
        <div className="bg-[rgba(0,153,126,0.16)] content-stretch flex gap-[5px] items-center px-[8px] py-[4px] relative rounded-[90px] shrink-0" data-name="Total InvestigationsSection.YearToDateBadge">
            <TrendUp />
            <p className="font-['Figtree:SemiBold',sans-serif] font-semibold leading-[normal] relative shrink-0 text-[#00997e] text-[11px] text-nowrap uppercase whitespace-pre">
                {percentage.toLocaleString(undefined, { maximumFractionDigits: 2 })}%
            </p>
        </div>
    );
}

function TotalInvestigationsSectionPercentage({ totalYearToDate, totalInvestigations }: any) {

    const percentage = totalInvestigations == 0 ? 0 : (totalYearToDate / totalInvestigations) * 100;

    return (
        <div className="absolute content-stretch flex flex-col items-end left-[514px] top-[15px]" data-name="TotalInvestigationsSection.Percentage">
            <TotalInvestigationsSectionYearToDateBadge percentage={percentage} />
        </div>
    );
}

function TotalInvestigationsSection({ totalYearToDate, totalInvestigations }: any) {
    return (
        <div className="absolute bg-white border border-[#c6c6c6] border-solid h-[53px] left-[19px] overflow-clip rounded-[10px] shadow-[0px_2px_6px_0px_rgba(144,146,148,0.2)] top-[286px] w-[1088px]" data-name="Total InvestigationsSection">
            <TotalInvestigationsSectionYearToDate
                yearToDate={totalYearToDate}
            />
            <div className="absolute flex h-[36px] items-center justify-center left-[294px] top-[7px] w-0" style={{ "--transform-inner-width": "36", "--transform-inner-height": "0" } as React.CSSProperties}>
                <div className="flex-none rotate-[270deg]">
                    <div className="h-0 relative w-[36px]" data-name="TotalInvestigationsSection.Line">
                        <div className="absolute bottom-0 left-0 right-0 top-[-1px]">
                            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 36 1">
                                <line id="ClosedInvestigationsSection.Line" stroke="var(--stroke-0, #D8D8D8)" x2="36" y1="0.5" y2="0.5" />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
            <TotalInvestigationsSectionTotalInvestigations total={totalInvestigations} />
            <TotalInvestigationsSectionPercentage totalYearToDate={totalYearToDate} totalInvestigations={totalInvestigations} />
        </div>
    );
}

function OverviewTitle() {
    return (
        <div className="absolute border-[#d8d8d8] border-[0px_0px_0.5px] border-solid h-[40px] left-[8px] top-[2px] w-[1100px]" data-name="Overview.Title">
            <p className="absolute font-['Open_Sans:SemiBold',sans-serif] font-semibold leading-[1.3] left-[4px] text-[#4d5154] text-[16px] text-nowrap top-[9.5px] tracking-[0.32px] whitespace-pre" style={{ fontVariationSettings: "'wdth' 100" }}>
                Overview
            </p>
        </div>
    );
}

export type IMOverview =
    {
        openTotal: number;
        openVideoAvailable: number;
        openVideoExpiringSoon: number;
        openVideoExpired: number;

        closedTotal: number;
        closedArchived: number;
        closedDeleted: number;
        averageDurationInDays: number;

        totalInvestigations: number;
        yearToDate: number;
    };

export default function InvestigationModuleOverview(
    { openTotal,
        openVideoAvailable,
        openVideoExpiringSoon,
        openVideoExpired,
        closedTotal,
        closedArchived,
        closedDeleted,
        averageDurationInDays,
        totalInvestigations,
        yearToDate }: IMOverview) {

    return (
        <div className="bg-white relative rounded-[10px] shadow-[0px_2px_6px_0px_rgba(144,146,148,0.2)] h-[370px] w-[1125px]" data-name="OverviewContent">
            <OverviewContent
                openTotal={openTotal}
                openVideoAvailable={openVideoAvailable}
                openVideoExpiringSoon={openVideoExpiringSoon}
                openVideoExpired={openVideoExpired}
                closedTotal={closedTotal}
                closedArchived={closedArchived}
                closedDeleted={closedDeleted}
                averageDurationInDays={averageDurationInDays}
                totalInvestigations={totalInvestigations}
                yearToDate={yearToDate}
            />
            <ClosedInvestigationsSection
                closedTotal={closedTotal}
                closedArchived={closedArchived}
                closedDeleted={closedDeleted}
                averageDuration={averageDurationInDays}
            />

            <TotalInvestigationsSection
                totalInvestigations={totalInvestigations}
                totalYearToDate={yearToDate}
            />
            <OverviewTitle />
        </div>
    );
}
