import { useRef, useEffect } from 'react';
import * as echarts from 'echarts/core';

// Import only the necessary charts and components to reduce bundle size
import { BarChart } from 'echarts/charts';
import { GridComponent, TitleComponent, TooltipComponent } from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';

// Register the required components
echarts.use([GridComponent, TitleComponent, TooltipComponent, BarChart, CanvasRenderer]);

const ChartComponent = ({ option, style = { width: '100%', height: '350px' } } : any) => {
    const chartRef = useRef(null);

    useEffect(() => {
        // Initialize chart
        let chart: any;

        if (chartRef.current) {
            chart = echarts.init(chartRef.current);
            chart.setOption(option);
        }

        // Add resize listener for responsiveness
        function resizeChart() {
            chart?.resize();
        }
        window.addEventListener('resize', resizeChart);

        // Return cleanup function
        return () => {
            chart?.dispose(); // Dispose chart instance on component unmount
            window.removeEventListener('resize', resizeChart);
        };
    }, []); // Empty dependency array ensures this runs once on mount

    useEffect(() => {
        // Update chart when the option prop changes
        if (chartRef.current) {
            const chart = echarts.getInstanceByDom(chartRef.current);
            chart?.setOption(option);
        }
    }, [option]); // Rerender when option prop changes

    return <div ref={chartRef} style={style} />;
};

export default ChartComponent;
