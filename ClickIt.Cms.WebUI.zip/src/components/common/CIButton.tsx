import React, { forwardRef, useMemo, memo } from 'react';
import { Spin } from 'antd';

/**
 * Button variant styles. Use 'icon' for icon-only buttons (children ignored).
 *
 * Available values:
 * - `'primary1'` - Primary button variant 1 (currently yellow)
 * - `'primary2'` - Primary button variant 2 (currently blue)
 * - `'secondary'` - Secondary button with border
 * - `'tertiary'` - Transparent button with text only
 * - `'icon'` - Icon-only button (ignores children)
 */
export type ButtonVariant = 'primary1' | 'primary2' | 'secondary' | 'tertiary' | 'icon';

/**
 * Button size options.
 *
 * Available values: 'small' | 'medium' | 'large'
 */
export type ButtonSize = 'small' | 'medium' | 'large';

/**
 * Props for the CIButton component.
 */
export interface CIButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'style'> {
    /**
     * Button style variant. Defaults to 'primary1'.
     *
     * Available values: 'primary1' | 'primary2' | 'secondary' | 'tertiary' | 'icon'
     */
    variant?: ButtonVariant;
    /**
     * Button size. Defaults to 'medium'.
     *
     * Available values: 'small' | 'medium' | 'large'
     */
    size?: ButtonSize;
    /** Shows loading spinner and disables button. Spinner color adapts to variant. */
    loading?: boolean;
    /** Icon element to display. For icon variants, this is the only content shown. */
    icon?: React.ReactNode;
    children?: React.ReactNode;
    /** Additional CSS classes. Applied before variant/size classes. */
    className?: string;
    /** Inline styles for direct overrides. */
    style?: React.CSSProperties;
}

const BASE_CLASSES =
    'inline-flex items-center justify-center font-semibold rounded-[4px] transition-colors cursor-pointer duration-200 focus:ring-cms-text-main disabled:cursor-not-allowed disabled:opacity-100 whitespace-nowrap min-w-fit';

const SIZE_CLASSES: Record<ButtonSize, string> = {
    small: 'h-8 px-3 text-xs',
    medium: 'h-[34px] px-4 text-sm',
    large: 'h-11 px-5 text-sm',
};

const ICON_SIZE_CLASSES: Record<ButtonSize, string> = {
    small: 'w-8 h-8 min-w-8',
    medium: 'w-[34px] h-[34px] min-w-[34px]',
    large: 'w-11 h-11 min-w-11',
};

const VARIANT_CLASSES: Record<ButtonVariant, string> = {
    primary1: `
        bg-cms-chart-yellow text-cms-text-main border border-none
        hover:bg-cms-chart-yellow/70 hover:border-none
        active:bg-cms-chart-yellow/80 active:border-none
        disabled:bg-cms-btn-primary-disabled-bg
        disabled:text-cms-text-white
    `
        .replace(/\s+/g, ' ')
        .trim(),
    primary2: `
        bg-cms-btn-primary-default-bg text-cms-text-white border border-none
        hover:bg-cms-btn-primary-hover-bg hover:border-none
        active:bg-cms-btn-primary-active-bg active:border-none
        disabled:bg-cms-btn-primary-disabled-bg
    `
        .replace(/\s+/g, ' ')
        .trim(),
    secondary: `
        bg-white text-cms-btn-secondary-default-text-stroke border border-cms-btn-secondary-default-text-stroke
        hover:bg-cms-btn-secondary-hover-bg hover:text-cms-btn-secondary-hover-text-stroke hover:border-cms-btn-secondary-hover-text-stroke
        active:bg-cms-btn-secondary-active-bg active:text-cms-btn-secondary-active-text-stroke active:border-cms-btn-secondary-active-text-stroke
        disabled:bg-cms-white disabled:text-cms-btn-secondary-text-disabled disabled:border-cms-btn-secondary-text-disabled
    `
        .replace(/\s+/g, ' ')
        .trim(),
    tertiary: `
        bg-transparent text-cms-text-main border-0
        hover:text-cms-btn-secondary-hover-text-stroke hover:bg-transparent
        active:text-cms-btn-secondary-active-text-stroke active:bg-transparent active:outline-none
        disabled:text-cms-btn-secondary-text-disabled disabled:bg-transparent
    `
        .replace(/\s+/g, ' ')
        .trim(),
    icon: `
        bg-white text-cms-btn-secondary-default-text-stroke border border-cms-btn-secondary-default-text-stroke
        hover:bg-cms-btn-secondary-hover-bg hover:text-cms-btn-secondary-hover-text-stroke hover:border-cms-btn-secondary-hover-text-stroke
        active:bg-cms-btn-secondary-active-bg active:text-cms-btn-secondary-active-text-stroke active:border-cms-btn-secondary-active-text-stroke
        disabled:bg-cms-white disabled:text-cms-btn-secondary-text-disabled disabled:border-cms-btn-secondary-text-disabled
    `
        .replace(/\s+/g, ' ')
        .trim(),
};

const combineClassNames = (...classes: (string | undefined | null | false)[]): string => {
    return classes.filter(Boolean).join(' ');
};

const CIButton = forwardRef<HTMLButtonElement, CIButtonProps>(
    (
        {
            variant = 'primary1',
            size = 'medium',
            loading = false,
            disabled,
            icon,
            children,
            className = '',
            style,
            type = 'button',
            ...props
        },
        ref,
    ) => {
        const isIconOnly = useMemo(() => variant === 'icon', [variant]);

        const sizeClass = useMemo(
            () => (isIconOnly ? ICON_SIZE_CLASSES[size] : SIZE_CLASSES[size]),
            [isIconOnly, size],
        );

        const variantClass = useMemo(() => VARIANT_CLASSES[variant], [variant]);

        const buttonClasses = useMemo(() => {
            const classes = [
                BASE_CLASSES,
                sizeClass,
                variantClass,
                loading && 'cursor-wait',
                className
            ];
            return combineClassNames(...classes);
        }, [sizeClass, variantClass, loading, className]);

        const spinnerSize = useMemo(() => (size === 'small' ? 'small' : 'default'), [size]);

        const isDisabled = disabled || loading;

        return (
            <button ref={ref} type={type} disabled={isDisabled} className={buttonClasses} style={style} {...props}>
                {loading ? (
                    <span className="flex items-center gap-2">
                        <Spin size={spinnerSize} style={{ color: 'white' }} />
                        {children && <span>{children}</span>}
                    </span>
                ) : (
                    <>
                        {icon && !isIconOnly && <span className="mr-2 flex items-center">{icon}</span>}
                        {isIconOnly ? icon : children}
                    </>
                )}
            </button>
        );
    },
);

CIButton.displayName = 'CIButton';

/**
 * Reusable button component with multiple variants and sizes.
 *
 * @param {CIButtonProps} props - Component props
 *
 * **Props:**
 * - `variant?: ButtonVariant` - Button style variant (default: 'primary1')
 *   - Available: 'primary1' | 'primary2' | 'secondary' | 'tertiary' | 'icon'
 * - `size?: ButtonSize` - Button size (default: 'medium')
 *   - Available: 'small' | 'medium' | 'large'
 * - `loading?: boolean` - Shows loading spinner and disables button (default: false)
 * - `icon?: React.ReactNode` - Icon element to display
 * - `children?: React.ReactNode` - Button content
 * - `className?: string` - Additional CSS classes
 * - `style?: React.CSSProperties` - Inline styles
 * - `disabled?: boolean` - Disables the button
 * - `type?: 'button' | 'submit' | 'reset'` - Button type (default: 'button')
 *
 * **Also accepts all standard HTML button attributes:**
 * - Event handlers: `onClick`, `onFocus`, `onBlur`, `onMouseEnter`, `onMouseLeave`, etc.
 * - ARIA attributes: `aria-label`, `aria-describedby`, `aria-labelledby`, etc.
 * - Data attributes: `data-*`
 * - Form attributes: `form`, `formAction`, `formMethod`, `formNoValidate`, `formTarget`
 * - Other: `id`, `name`, `tabIndex`, `title`, etc.
 *
 * @example
 * // Basic usage
 * <CIButton variant="primary2" onClick={handleClick}>Submit</CIButton>
 *
 * @example
 * // With icon
 * <CIButton variant="secondary" icon={<Icon />}>Save</CIButton>
 *
 * @example
 * // Icon-only button
 * <CIButton variant="icon" icon={<CloseIcon />} aria-label="Close" />
 *
 * @example
 * // Loading state
 * <CIButton loading={isSubmitting}>Submit</CIButton>
 */
const CIButtonComponent = memo(CIButton);
CIButtonComponent.displayName = 'CIButton';

export default CIButtonComponent;
