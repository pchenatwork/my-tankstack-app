import React from 'react';
import { Select } from 'antd';
import type { SelectProps } from 'antd';
import { useCompanies } from '@/hooks/useCompanies';
import type { Option } from '@/types/common';

const { Option } = Select;

interface SelectOption {
    label: React.ReactNode;
    value: string | number;
}

interface CustomSelectProps extends Omit<SelectProps<string | number>, 'options' | 'onChange'> {
    value?: string | number;
    onChange?: (value: string | null) => void;
    //isloading?: boolean;
    //options: SelectOption[];
}

const CustomSelect: React.FC<CustomSelectProps> = ({ value, onChange, ...restProps }) => {
    const { data: companiesResponse, isLoading: isLoading } = useCompanies();
    const options: Option[] =
        companiesResponse?.isSuccessful && companiesResponse.payLoad
            ? companiesResponse.payLoad.map((x) => ({
                  label: x.name,
                  value: x.id,
              }))
            : [];
    const handleChange = (selectedValue: string | number) => {
        // Call the onChange function provided by Form.Item
        if (onChange) {
            const option = options.find((o) => o.value == selectedValue);
            console.log('CICompanyDropdown onChange value', value, option);
            onChange(option?.label ?? null);
            //onChange(selectedValue);
        }
    };

    return (
        <Select value={value} onChange={handleChange} loading={isLoading} placeholder="Select a company" {...restProps}>
            {options.map((option) => (
                <Option key={option.value} value={option.value}>
                    {option.label}
                </Option>
            ))}
        </Select>
    );
};

export default CustomSelect;
