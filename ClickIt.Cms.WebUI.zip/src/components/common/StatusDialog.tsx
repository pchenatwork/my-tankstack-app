import { CheckCircleFilled, CloseOutlined, ExclamationCircleFilled } from '@ant-design/icons';
import { Modal } from 'antd';
import React from 'react';

import { CIButton } from '.';
import styles from './StatusDialog.module.scss';

type StatusType = 'success' | 'error';

interface StatusDialogProps {
    open: boolean;
    type: StatusType;
    title: string;
    message: string;
    onClose: () => void;
}

const StatusDialog: React.FC<StatusDialogProps> = ({ open, type, title, message, onClose }) => {
    const isSuccess = type === 'success';

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            closable={false}
            centered
            width={510}
            className={styles['status-dialog-modal']}
        >
            <div className={styles.container}>
                {/* Header */}
                <div className={styles.header}>
                    <div className={styles['header-left']}>
                        {isSuccess ? (
                            <CheckCircleFilled className={styles['icon-success']} />
                        ) : (
                            <ExclamationCircleFilled className={styles['icon-error']} />
                        )}
                        <span className={styles.title}>{title}</span>
                    </div>
                    <button type="button" className={styles['close-button']} onClick={onClose}>
                        <CloseOutlined />
                    </button>
                </div>

                {/* Divider */}
                <div className={styles.divider} />

                {/* Body */}
                <div className={styles.body}>
                    <p className={styles.message}>{message}</p>
                </div>

                {/* Footer */}
                <div className={styles.footer}>
                    <CIButton variant="primary2" size="small" onClick={onClose}>
                        OK
                    </CIButton>
                </div>
            </div>
        </Modal>
    );
};

export default StatusDialog;
