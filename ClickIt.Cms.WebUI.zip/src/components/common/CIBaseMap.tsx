import { useState, useEffect } from 'react';
import { MapContainer, TileLayer, useMap, ZoomControl } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default Leaflet marker icons in React
// @ts-ignore - Leaflet icon fix
delete L.Icon.Default.prototype._getIconUrl;
// @ts-ignore - Leaflet icon fix
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Map server base URL
const MAP_SERVER_BASE = "http://10.10.85.53/map-poc/mapapi";

interface MapStyle {
  id?: string;
  name?: string;
  style?: string;
}

interface MapInstanceHandlerProps {
  onMapReady?: (map: any) => void;
}

/**
 * Helper component to handle map instance
 */
function MapInstanceHandler({ onMapReady }: MapInstanceHandlerProps): null {
  const map = useMap();

  useEffect(() => {
    if (map && onMapReady) {
      onMapReady(map);
    }
  }, [map, onMapReady]);

  return null;
}

interface BaseMapProps {
  center?: [number, number];
  zoom?: number;
  className?: string;
  style?: any;
  onMapReady?: (map: any) => void;
  children?: any;
}

/**
 * BaseMap Component
 *
 * A reusable Leaflet map component with custom tile server support.
 * This component handles the basic map setup and tile loading.
 *
 * @param props - Component props
 * @param props.center - Map center [lat, lng] (default: [39.8283, -98.5795])
 * @param props.zoom - Initial zoom level (default: 4)
 * @param props.className - Additional CSS classes
 * @param props.style - Inline styles for the map container
 * @param props.onMapReady - Callback when map instance is ready
 * @param props.children - Child components (markers, polygons, etc.)
 */
const CIBaseMap = ({
  center = [39.8283, -98.5795], // Default to center of USA
  zoom = 4,
  className = '',
  style = {},
  onMapReady,
  children
}: BaseMapProps) => {
  const [tileUrl, setTileUrl] = useState(null as string | null);
  // TODO(Madhu):  Error TS2721: Cannot invoke an object which is possibly 'null'.
  // const [setTileStyleId] = useState(null as string | null);
  const [isLoading, setIsLoading] = useState(true);

  // Load tile server styles
  useEffect(() => {
    const loadTileserverStyle = async (): Promise<void> => {
      // Allow ?style={id} override via query string
      const queryParams = new URLSearchParams(window.location.search);
      const explicitStyleId = queryParams.get('style');

      try {
        const listUrl = `${MAP_SERVER_BASE}/styles.json`;
        const resp = await fetch(listUrl, {
          headers: { 'Accept': 'application/json' }
        });

        if (!resp.ok) {
          throw new Error(`Failed to list styles (${resp.status})`);
        }

        const styles: MapStyle[] = await resp.json();
        if (!Array.isArray(styles) || styles.length === 0) {
          throw new Error('No styles available');
        }

        // Determine which style to use
        const chosen = explicitStyleId
          ? styles.find(s => (s.id || s.name || s.style) === explicitStyleId) || styles[1]
          : styles[0];

        const id = chosen.id || chosen.name || chosen.style || 'default';

        // Construct raster tile URL template: /styles/{id}/{z}/{x}/{y}.png
        const rasterTileUrl = `${MAP_SERVER_BASE}/styles/${encodeURIComponent(id)}/{z}/{x}/{y}.png`;

        // TODO(Madhu):  Error TS2721: Cannot invoke an object which is possibly 'null'.
        // setTileStyleId(id);
        setTileUrl(rasterTileUrl);
      } catch (e) {
        console.warn('Could not load tile server styles, using OpenStreetMap:', e);
        // Fallback to OpenStreetMap
        setTileUrl('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png');
      } finally {
        setIsLoading(false);
      }
    };

    loadTileserverStyle();
  }, []);

  // Default styles for map container
  const defaultStyle = {
    height: '100%',
    width: '100%',
    ...style
  };

  return (
    <MapContainer
      center={center}
      zoom={zoom}
      className={className}
      style={defaultStyle}
      scrollWheelZoom={true}
      zoomControl={false}
    >
      {onMapReady && <MapInstanceHandler onMapReady={onMapReady} />}
      <ZoomControl position="bottomright" />
      {!isLoading && tileUrl ? (
        <TileLayer
          attribution='© Map Tiles'
          url={tileUrl}
          maxZoom={20}
          minZoom={0}
        />
      ) : (
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          maxZoom={20}
          minZoom={0}
        />
      )}

      {children}
    </MapContainer>
  );
};

export default CIBaseMap;
