import { Input, Space } from 'antd';
import React, { forwardRef, memo } from 'react';

import { getImagePath } from '@/utils';

/**
 * Search box size options.
 *
 * Available values: 'small' | 'medium' | 'large'
 */
export type SearchBoxSize = 'small' | 'medium' | 'large';

/**
 * Props for the CISearchBox component.
 */
export interface CISearchBoxProps {
    /** Current input value (controlled component). */
    value?: string;
    /** Callback fired when input value changes. */
    onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    /** Placeholder text for the input. Defaults to 'Search...'. */
    placeholder?: string;
    /** Additional CSS classes for the container div. */
    className?: string;
    /** Additional CSS classes for the input element. */
    inputClassName?: string;
    /** Additional CSS classes for the search button. */
    buttonClassName?: string;
    /** Callback fired when search button is clicked or Enter key is pressed. Receives current input value. */
    onSearch?: (value?: string) => void;
    /** Size of the search box. Defaults to 'small'. */
    size?: SearchBoxSize;
    /** Disables the search box. */
    disabled?: boolean;
}

const CISearchBox = forwardRef<HTMLDivElement, CISearchBoxProps>(
    (
        {
            value,
            onChange,
            placeholder = 'Search...',
            className = '',
            inputClassName = '',
            buttonClassName = '',
            onSearch,
            size = 'small',
            disabled = false,
        },
        ref,
    ) => {
        const handleButtonClick = () => {
            if (onSearch && !disabled) {
                onSearch(value);
            }
        };

        // Map size to button width classes (height is fixed at 34px)
        // small: 32px (w-8), medium: 36px (w-9), large: 40px (w-10)
        const widthClass = size === 'large' ? 'w-10' : size === 'medium' ? 'w-9' : 'w-8';

        // Map 'medium' to 'middle' for Ant Design Input component compatibility
        const inputSize = size === 'medium' ? 'middle' : size;

        return (
            <div ref={ref} className={className}>
                <Space.Compact className="w-full">
                    <Input
                        size={inputSize}
                        placeholder={placeholder}
                        value={value}
                        onChange={onChange}
                        disabled={disabled}
                        className={`!h-[34px] !rounded-l-[8px] !rounded-r-none !border-r-0 !text-sm focus-within:!border-r-0 hover:!border-r-0 focus:!border-r-0 md:!w-[280px] ${inputClassName}`}
                        onPressEnter={() => onSearch?.(value)}
                        aria-label="Search input"
                    />
                    <button
                        type="button"
                        onClick={handleButtonClick}
                        disabled={disabled}
                        aria-label="Search"
                        className={`inline-flex h-[34px] w-[34px] items-center justify-center p-2 ${widthClass} bg-cms-btn-primary-default-bg border-cms-btn-primary-default-bg hover:bg-cms-btn-primary-hover-bg hover:border-cms-btn-primary-hover-bg active:bg-cms-btn-primary-active-bg active:border-cms-btn-primary-active-bg disabled:bg-cms-btn-primary-disabled-bg disabled:border-cms-btn-primary-disabled-bg focus:ring-cms-btn-primary-default-bg/50 cursor-pointer rounded-l-none rounded-r-[8px] border border-l-0 transition-colors duration-200 hover:border-l-0 focus:ring-2 focus:ring-offset-1 focus:outline-none active:border-l-0 disabled:cursor-not-allowed disabled:border-l-0 ${buttonClassName} `
                            .replace(/\s+/g, ' ')
                            .trim()}
                    >
                        <img
                            src={getImagePath('icons/search_icon.png')}
                            alt=""
                            width={16}
                            height={16}
                            className="brightness-0 invert filter"
                            aria-hidden="true"
                        />
                    </button>
                </Space.Compact>
            </div>
        );
    },
);

CISearchBox.displayName = 'CISearchBox';

/**
 * Reusable search box component with integrated search button.
 *
 * @param {CISearchBoxProps} props - Component props
 *
 * **Props:**
 * - `value?: string` - Current input value (controlled component)
 * - `onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void` - Callback fired when input value changes
 * - `placeholder?: string` - Placeholder text (default: 'Search...')
 * - `className?: string` - Additional CSS classes for container div
 * - `inputClassName?: string` - Additional CSS classes for input element
 * - `buttonClassName?: string` - Additional CSS classes for search button
 * - `onSearch?: () => void` - Callback fired when search button clicked or Enter pressed
 * - `size?: SearchBoxSize` - Size of search box (default: 'small')
 *   - Available: 'small' | 'medium' | 'large'
 * - `disabled?: boolean` - Disables the search box (default: false)
 *
 * @example
 * // Basic usage
 * <CISearchBox
 *   value={searchTerm}
 *   onChange={(e) => setSearchTerm(e.target.value)}
 *   onSearch={handleSearch}
 * />
 *
 * @example
 * // With custom styling
 * <CISearchBox
 *   value={searchTerm}
 *   onChange={(e) => setSearchTerm(e.target.value)}
 *   onSearch={handleSearch}
 *   placeholder="Search users..."
 *   size="medium"
 *   className="w-full"
 *   inputClassName="custom-input"
 * />
 *
 * @example
 * // Disabled state
 * <CISearchBox
 *   value={searchTerm}
 *   onChange={(e) => setSearchTerm(e.target.value)}
 *   disabled={isLoading}
 * />
 */
const MemoizedCISearchBox = memo(CISearchBox);
MemoizedCISearchBox.displayName = 'CISearchBox';

export default MemoizedCISearchBox;
