import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Alert } from 'antd';

export type AlertType = 'success' | 'info' | 'warning' | 'error';

export interface AlertOptions {
    type: AlertType;
    /** Main title text of the alert (maps to AntD `title` prop; `message` is deprecated) */
    title: React.ReactNode;
    /** Optional secondary text under the title */
    description?: React.ReactNode;
    /** Auto close after N ms (set 0 or undefined to disable auto close) */
    durationMs?: number;
}

interface AlertItem extends AlertOptions {
    id: string;
}

interface AlertContextValue {
    showAlert: (options: AlertOptions) => void;
    success: (options: Omit<AlertOptions, 'type'>) => void;
    error: (options: Omit<AlertOptions, 'type'>) => void;
    info: (options: Omit<AlertOptions, 'type'>) => void;
    warning: (options: Omit<AlertOptions, 'type'>) => void;
    hideAlert: (id: string) => void;
    clearAlerts: () => void;
}

const AlertContext = createContext<AlertContextValue | undefined>(undefined);

export const AlertProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [alerts, setAlerts] = useState<AlertItem[]>([]);
    const timersRef = useRef<Record<string, number>>({});

    const hideAlert = useCallback((id: string) => {
        setAlerts((prev) => prev.filter((a) => a.id !== id));
        const timerId = timersRef.current[id];
        if (timerId) {
            clearTimeout(timerId);
            delete timersRef.current[id];
        }
    }, []);

    const clearAlerts = useCallback(() => {
        Object.values(timersRef.current).forEach((t) => clearTimeout(t));
        timersRef.current = {};
        setAlerts([]);
    }, []);

    const pushAlert = useCallback(
        ({ type, title, description, durationMs = 4000 }: AlertOptions) => {
            const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
            setAlerts((prev) => [...prev, { id, type, title, description, durationMs }]);

            if (durationMs && durationMs > 0) {
                const timerId = window.setTimeout(() => {
                    hideAlert(id);
                }, durationMs);
                timersRef.current[id] = timerId;
            }
        },
        [hideAlert],
    );

    // Clean up any remaining timers on unmount to avoid memory leaks
    useEffect(
        () => () => {
            Object.values(timersRef.current).forEach((t) => clearTimeout(t));
            timersRef.current = {};
        },
        [],
    );

    const contextValue = useMemo<AlertContextValue>(
        () => ({
            showAlert: (options) => pushAlert(options),
            success: (options) => pushAlert({ ...options, type: 'success' }),
            error: (options) => pushAlert({ ...options, type: 'error' }),
            info: (options) => pushAlert({ ...options, type: 'info' }),
            warning: (options) => pushAlert({ ...options, type: 'warning' }),
            hideAlert,
            clearAlerts,
        }),
        [pushAlert, hideAlert, clearAlerts],
    );

    return (
        <AlertContext.Provider value={contextValue}>
            {children}
            {alerts.length > 0 && (
                <div className="cms-global-alert">
                    {alerts.map((alert) => (
                        <Alert
                            key={alert.id}
                            type={alert.type}
                            // `title` is the recommended prop in newer Ant Design versions
                            // TS types may still mark it as `message`, so cast to any
                            {...({
                                title: alert.title,
                                description: alert.description,
                                showIcon: true,
                                closable: true,
                                onClose: () => hideAlert(alert.id),
                            } as any)}
                        />
                    ))}
                </div>
            )}
        </AlertContext.Provider>
    );
};

export const useAlert = (): AlertContextValue => {
    const ctx = useContext(AlertContext);
    if (!ctx) {
        throw new Error('useAlert must be used within an <AlertProvider>');
    }
    return ctx;
};


