import { useCompanies } from '@/hooks/useCompanies';
import type { Option } from '@/types/common';
import { Select, type SelectProps } from 'antd';
import { useCallback, type FC } from 'react';

interface CustomSelectProps extends Omit<SelectProps<string | number>, 'onChange'> {
    value?: string; // | number;
    onChange?: (value: string | null) => void;
}

const CICompanyDropdown: FC<CustomSelectProps> = (props) => {
    console.log('CICompanyDropdown Rendered::  props = ', props);

    const { data: companiesResponse, isLoading: isLoading } = useCompanies();

    const options: Option[] =
        companiesResponse?.isSuccessful && companiesResponse.payLoad
            ? companiesResponse.payLoad.map((x) => ({
                  label: x.name,
                  value: x.id,
              }))
            : [];

    const handleChange = useCallback(
        (value: string) => {
            if (props.onChange) {
                const option = options.find((o) => o.value == value);
                console.log('CICompanyDropdown onChange value', value, option);
                props.onChange(option?.label ?? null);
            }
        },
        [props.onChange, options],
    );

    // Get modal container for dropdowns to render within modal
    const getPopupContainer = useCallback((triggerNode: HTMLElement | null): HTMLElement => {
        if (!triggerNode) return document.body;
        const modalContainer = triggerNode.closest('.ant-modal-root');
        return (modalContainer as HTMLElement) || document.body;
    }, []);

    return (
        <Select
            value={props.value}
            onChange={handleChange}
            loading={isLoading}
            options={options}
            getPopupContainer={getPopupContainer}
            placeholder="Select a company"
        />
    );
};
export default CICompanyDropdown;
