import { CloseOutlined, DownOutlined } from '@ant-design/icons';
import { ColorPicker, Form, Input, Modal, Select, Tree, Spin } from 'antd';
import type { Color } from 'antd/es/color-picker';
import type { TreeProps } from 'antd';
import React, { useEffect, useState, useMemo, memo, useCallback } from 'react';
import type { SecurityLevelItem, PermissionNodeDto } from '@/types/securityLevel';
import { CIButton } from '@/components/common';
import { getImagePath } from '@/utils';
import { usePermissionTree } from '@/hooks/useUsers';
import { useCompanies } from '@/hooks/useCompanies';
import styles from './AddSecurityLevelModal.module.scss';
import { AdminAccessLevel, SecurityLevelConstants } from '@/constants';

const { TextArea } = Input;

// Constants for icon paths - computed once
const ICON_PATHS = {
    starFilled: getImagePath('icons/icon-star-filled.png'),
    starHalfFilled: getImagePath('icons/icon-star-half-filled.png'),
} as const;

// Constants for default values
const DEFAULT_COLOR = '#FF8C00';
const DEFAULT_TEXT_COLOR = '#FFFFFF';

// Text color options - constant to avoid recreation
const TEXT_COLOR_OPTIONS = [
    { value: '#FFFFFF', label: 'White' },
    { value: '#000000', label: 'Black' },
];

interface AddSecurityLevelModalProps {
    open: boolean;
    onClose: () => void;
    onSubmit: (values: SecurityLevelFormValues) => void;
    editingLevel?: SecurityLevelItem | null;
}

interface PermissionNode {
    key: string; // Required by Ant Design Tree type (will match id)
    id: string; // Use id as the identifier
    title: string;
    icon?: string;
    children?: PermissionNode[];
    isAdmin?: boolean;
}

interface RootCategory {
    key: string; // Required by Ant Design Tree type (will match id)
    id: string; // Use id as the identifier
    title: string;
    children?: PermissionNode[];
    isAdmin?: boolean;
}

export interface SecurityLevelFormValues {
    name: string;
    description?: string;
    backColor: string;
    foreColor: string;
    permissionIds: string[];
    companyId: string;
    accessLevel: AdminAccessLevel;
}

// Memoize countNodes function outside component
const countNodes = (nodes: PermissionNode[]): number => {
    let count = 0;
    nodes.forEach((node) => {
        count += 1;
        if (node.children) {
            count += countNodes(node.children);
        }
    });
    return count;
};

// Helper function to collect all node ids from a tree recursively
const getAllNodeIds = (nodes: PermissionNode[]): string[] => {
    const ids: string[] = [];
    nodes.forEach((node) => {
        ids.push(node.id);
        if (node.children && node.children.length > 0) {
            ids.push(...getAllNodeIds(node.children));
        }
    });
    return ids;
};

// Helper function to compute access level label for a category
const getCategoryAccessLevelLabel = (
    category: RootCategory,
    state: { checked: React.Key[]; isRootChecked?: boolean } | undefined
): string => {
    if (!state) return '';

    // If root is checked, it's full access for that category
    if (state.isRootChecked) {
        return 'Full Access';
    }

    // If category has no children (only root node), check if root is in checked ids
    if (!category.children || category.children.length === 0) {
        // If root id is in checked ids, it means full access
        if (state.checked.includes(category.id)) {
            return 'Full Access';
        }
        return '';
    }

    // Get all node ids that belong to this category's tree
    const categoryNodeIds = getAllNodeIds(category.children);
    const checkedIdsInCategory = (state.checked as string[]).filter((id) => categoryNodeIds.includes(id));
    const totalNodes = countNodes(category.children);
    const checkedCount = checkedIdsInCategory.length;

    if (checkedCount === 0) {
        return '';
    } else if (checkedCount === totalNodes) {
        return 'Full Access';
    } else {
        return 'Partial Access';
    }
};

// Memoized CategoryItem component to prevent unnecessary re-renders
interface CategoryItemProps {
    category: RootCategory;
    isSelected: boolean;
    categoryState: { checked: React.Key[]; isRootChecked?: boolean } | undefined;
    onSelect: (id: string) => void;
}

const CategoryItem = memo<CategoryItemProps>(({ category, isSelected, categoryState, onSelect }) => {
    const handleClick = useCallback(() => {
        onSelect(category.id);
    }, [category.id, onSelect]);

    // Compute access level label at component level
    const accessLevel = getCategoryAccessLevelLabel(category, categoryState);

    return (
        <div
            className={`mb-3 flex h-[35px] cursor-pointer items-center justify-between rounded-lg px-4 py-1 transition-colors ${isSelected ? 'bg-[#E6F4FF]' : 'bg-white hover:bg-[#f5f5f5]'}`}
            onClick={handleClick}
        >
            <div className="flex flex-1 items-center gap-2">
                <span className="text-cms-text-main text-sm">{category.title}</span>
                {category.isAdmin && accessLevel === 'Full Access' && (
                    <img
                        src={ICON_PATHS.starFilled}
                        alt="Full access"
                        width={16}
                        height={16}
                        className="flex-shrink-0"
                    />
                )}
                {category.isAdmin && accessLevel === 'Partial Access' && (
                    <img
                        src={ICON_PATHS.starHalfFilled}
                        alt="Partial access"
                        width={16}
                        height={16}
                        className="flex-shrink-0"
                    />
                )}
            </div>
            <div className="flex items-center gap-2">
                {accessLevel && <span className="text-xs text-[#8c8c8c]">{accessLevel}</span>}
            </div>
        </div>
    );
});

CategoryItem.displayName = 'CategoryItem';

const AddSecurityLevelModal: React.FC<AddSecurityLevelModalProps> = ({ open, onClose, onSubmit, editingLevel }) => {
    const [form] = Form.useForm();
    const { data: permissionTreeResponse, isLoading: isTreeLoading } = usePermissionTree();
    const { data: companiesResponse, isLoading: isCompaniesLoading } = useCompanies();
    const [selectedColor, setSelectedColor] = useState<Color | string>(DEFAULT_COLOR);
    const [textColor, setTextColor] = useState<string>(DEFAULT_TEXT_COLOR);
    const [selectedCategory, setSelectedCategory] = useState<string>('');
    const [categoryStates, setCategoryStates] = useState<
        Record<string, { checked: React.Key[]; isRootChecked?: boolean }>
    >({});

    // Watch form values for character count display
    const nameValue = Form.useWatch('name', form) || '';
    const descriptionValue = Form.useWatch('description', form) || '';

    const permissionTree = useMemo<PermissionNodeDto[]>(
        () => permissionTreeResponse?.payLoad ?? [],
        [permissionTreeResponse],
    );

    const mapToPermissionNodes = useCallback((nodes: PermissionNodeDto[]): PermissionNode[] => {
        return nodes.map((node) => ({
            key: node.id, // Required by Ant Design Tree type (matches id)
            id: node.id, // Use id as the identifier
            title: node.title,
            icon: node.icon ?? undefined,
            children: node.children ? mapToPermissionNodes(node.children) : [],
            isAdmin: node.isAdmin,
        }));
    }, []);

    const rootCategories: RootCategory[] = useMemo(
        () => mapToPermissionNodes(permissionTree),
        [mapToPermissionNodes, permissionTree],
    );

    const idToRootMap = useMemo<Record<string, string>>(() => {
        const map: Record<string, string> = {};
        const traverse = (nodes: PermissionNode[], rootId?: string) => {
            nodes.forEach((node) => {
                const resolvedRoot = rootId ?? node.id;
                map[node.id] = resolvedRoot;
                if (node.children && node.children.length > 0) {
                    traverse(node.children, resolvedRoot);
                }
            });
        };
        traverse(rootCategories);
        return map;
    }, [rootCategories]);

    // Helper function to collect all permission IDs recursively from a node
    const getAllPermissionIds = useCallback((node: PermissionNodeDto): string[] => {
        const ids: string[] = [node.id]; // Use id from API
        if (node.children && node.children.length > 0) {
            node.children.forEach((child) => {
                ids.push(...getAllPermissionIds(child));
            });
        }
        return ids;
    }, []);

    // Pre-fill form when editing - only run when modal opens or editingLevel changes
    useEffect(() => {
        if (!open) return;
        if (!rootCategories.length) return;

        if (editingLevel) {
            form.setFieldsValue({
                companyId: editingLevel.companyId || '',
                name: editingLevel.name,
                description: editingLevel.description,
            });
            setSelectedColor(editingLevel.backColor);
            setTextColor(editingLevel.foreColor || DEFAULT_TEXT_COLOR);
        } else {
            // Reset form for new level
            form.resetFields();
            setSelectedColor(DEFAULT_COLOR);
            setTextColor(DEFAULT_TEXT_COLOR);
        }

        // Initialize category states based on fetched permission tree
        const baseStates = rootCategories.reduce<Record<string, { checked: React.Key[]; isRootChecked?: boolean }>>(
            (acc, category) => {
                acc[category.id] = { checked: [], isRootChecked: false };
                return acc;
            },
            {},
        );

        let nextStates = { ...baseStates };
        if (editingLevel && editingLevel.permissionIds?.length) {
            const draftStates = { ...baseStates };
            editingLevel.permissionIds.forEach((pid) => {
                const rootId = idToRootMap[pid];
                if (rootId) {
                    draftStates[rootId] = draftStates[rootId] ?? { checked: [], isRootChecked: false };
                    draftStates[rootId].checked.push(pid);
                }
            });
            Object.keys(draftStates).forEach((id) => {
                draftStates[id].checked = Array.from(new Set(draftStates[id].checked));
            });

            // Check if any category has all its permissions selected - mark as root checked
            rootCategories.forEach((category) => {
                const state = draftStates[category.id];
                if (state && state.checked.length > 0) {
                    // If category has no children (only root node), check if root id is selected
                    if (!category.children || category.children.length === 0) {
                        if (state.checked.includes(category.id)) {
                            state.isRootChecked = true;
                            state.checked = [];
                        }
                    } else {
                        // Category has children - check if all are selected
                        const categoryNodeIds = getAllNodeIds(category.children);
                        const checkedIdsInCategory = state.checked.filter((id) =>
                            categoryNodeIds.includes(id as string),
                        );
                        const totalNodes = countNodes(category.children);

                        // If all nodes in category are checked, mark as root checked
                        if (checkedIdsInCategory.length === totalNodes) {
                            state.isRootChecked = true;
                            state.checked = [];
                        }
                    }
                }
            });

            nextStates = draftStates;
        }

        setCategoryStates(nextStates);
        setSelectedCategory((prev) => (prev && nextStates[prev] ? prev : (rootCategories[0]?.id ?? '')));
    }, [open, editingLevel, form, rootCategories, idToRootMap]);

    // Memoize color hex conversion
    const colorHex = useMemo(() => {
        return typeof selectedColor === 'string' ? selectedColor : selectedColor.toHexString();
    }, [selectedColor]);

    // Memoize selected category data
    const selectedCategoryData = useMemo(() => {
        return rootCategories.find((c) => c.id === selectedCategory);
    }, [selectedCategory, rootCategories]);

    // Build tree data with root node as first level
    const treeDataWithRoot = useMemo(() => {
        if (!selectedCategoryData) return [];

        return [
            {
                key: selectedCategoryData.id, // Required by Ant Design Tree type, but fieldNames uses 'id'
                id: selectedCategoryData.id,
                title: selectedCategoryData.title,
                children: selectedCategoryData.children || [],
            },
        ];
    }, [selectedCategoryData]);

    // Memoize company options
    const companyOptions = useMemo(() => {
        if (!companiesResponse?.isSuccessful || !companiesResponse?.payLoad) {
            return [];
        }
        return companiesResponse.payLoad.map((company) => ({
            value: company.id,
            label: company.name,
        }));
    }, [companiesResponse]);

    // Compute overall access level (F, P, N) based on all category states
    const computedAccessLevel = useMemo(() => {
        let hasAnyRootChecked = false;
        let hasAnyPartialChecked = false;
        let hasAnyChecked = false;

        rootCategories.forEach((category) => {
            const state = categoryStates[category.id];
            if (!state) return;

            // Check if root is checked for this category
            if (state.isRootChecked) {
                hasAnyRootChecked = true;
                hasAnyChecked = true;
                return;
            }

            // Check if category has no children (only root node)
            if (!category.children || category.children.length === 0) {
                if (state.checked.includes(category.id)) {
                    hasAnyRootChecked = true;
                    hasAnyChecked = true;
                }
                return;
            }

            // Get all node ids that belong to this category's tree
            const categoryNodeIds = getAllNodeIds(category.children);
            const checkedIdsInCategory = (state.checked as string[]).filter((id) => categoryNodeIds.includes(id));
            const totalNodes = countNodes(category.children);
            const checkedCount = checkedIdsInCategory.length;

            if (checkedCount > 0) {
                hasAnyChecked = true;
                if (checkedCount < totalNodes) {
                    hasAnyPartialChecked = true;
                } else if (checkedCount === totalNodes) {
                    hasAnyRootChecked = true;
                }
            }
        });

        // Determine overall access level
        if (hasAnyRootChecked) {
            return AdminAccessLevel.Full; // F - at least one root is fully checked
        } else if (hasAnyChecked || hasAnyPartialChecked) {
            return AdminAccessLevel.Partial; // P - some permissions are checked but not all roots
        } else {
            return AdminAccessLevel.None; // N - no permissions are checked
        }
    }, [categoryStates, rootCategories]);

    // Memoize callbacks to prevent unnecessary re-renders
    const handleColorChange = useCallback((color: Color) => {
        setSelectedColor(color);
    }, []);

    const handleCategorySelect = useCallback((categoryId: string) => {
        setSelectedCategory(categoryId);
    }, []);

    const handleTreeCheck = useCallback(
        (checkedKeysValue: React.Key[] | { checked: React.Key[]; halfChecked: React.Key[] }) => {
            if (!selectedCategory) return;

            const keys = Array.isArray(checkedKeysValue) ? checkedKeysValue : checkedKeysValue.checked;
            const checkedKeys = keys as string[];

            // Check if root node is checked
            const isRootChecked = checkedKeys.includes(selectedCategory);

            setCategoryStates((prev) => {
                if (isRootChecked) {
                    // If root is checked, give full access (clear individual selections)
                    return {
                        ...prev,
                        [selectedCategory]: {
                            checked: [],
                            isRootChecked: true,
                        },
                    };
                } else {
                    // Root is not checked, allow individual selections (remove root key if present)
                    const filteredKeys = checkedKeys.filter((key) => key !== selectedCategory);
                    return {
                        ...prev,
                        [selectedCategory]: {
                            checked: filteredKeys,
                            isRootChecked: false,
                        },
                    };
                }
            });
        },
        [selectedCategory],
    ) as TreeProps['onCheck'];

    const handleSubmit = useCallback(() => {
        form.validateFields()
            .then((values) => {
                // Collect all permission IDs from all categories
                const selectedPermissionIds = Array.from(
                    new Set(
                        rootCategories.flatMap((category) => {
                            const state = categoryStates[category.id];
                            if (!state) return [];

                            // If root is checked for a category, collect all its permission IDs (including root and all children)
                            if (state.isRootChecked) {
                                const rootNode = permissionTree.find((node) => node.id === category.id);
                                if (rootNode) {
                                    // Get all IDs including root and all descendants
                                    return getAllPermissionIds(rootNode);
                                }
                                return [];
                            }

                            // Otherwise, return individually selected permissions
                            return state.checked as string[];
                        }),
                    ),
                );

                const formData = {
                    ...values,
                    backColor: typeof selectedColor === 'string' ? selectedColor : selectedColor.toHexString(),
                    foreColor: textColor,
                    permissionIds: selectedPermissionIds,
                    companyId: values.companyId,
                    accessLevel: computedAccessLevel,
                };
                onSubmit(formData);
            })
            .catch((error) => {
                console.error('Validation failed:', error);
            });
    }, [form, selectedColor, textColor, categoryStates, onSubmit, rootCategories, permissionTree, getAllPermissionIds, computedAccessLevel]);

    // Memoize tree title render to prevent recreation
    const treeTitleRender = useCallback(
        (nodeData: any) => (
            <div className="flex items-center gap-2">
                {nodeData.icon && typeof nodeData.icon === 'string' && nodeData.icon.includes('.') && (
                    <img
                        src={getImagePath(nodeData.icon)}
                        alt={nodeData.title}
                        width={16}
                        height={16}
                        className="flex-shrink-0"
                    />
                )}
                <span className="text-[rgba(0,0,0,0.88)]">{nodeData.title}</span>
            </div>
        ),
        [],
    );

    // Get modal container for dropdowns to render within modal
    const getPopupContainer = useCallback((triggerNode: HTMLElement | null): HTMLElement => {
        if (!triggerNode) return document.body;
        const modalContainer = triggerNode.closest('.ant-modal-root');
        return (modalContainer as HTMLElement) || document.body;
    }, []);

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            width="90%"
            closeIcon={<CloseOutlined />}
            className={styles.modal}
        >
            <div className="border-cms-section-line-default border-b px-[18px] py-[15px]">
                <h3 className="m-0 text-lg font-semibold">{editingLevel?.id ? 'Edit Level' : 'New Level'}</h3>
            </div>

            <Form form={form} layout="vertical" className={styles.form}>
                {/* Combined container for all three rows */}
                <div className="bg-cms-bg-white mb-4 rounded-[10px] border-none p-4 shadow-[0px_2px_6px_0px_rgba(144,146,148,0.2)]">
                    {/* Row 1: Company and Security Level Name */}
                    <div className="mb-4 flex gap-2 max-md:flex-col max-md:gap-0">
                            <Form.Item
                            label={<span>Company:</span>}
                            name="companyId"
                            rules={[{ required: true, message: 'Please select a company' }]}
                            className="mb-0 min-w-0 flex-1 max-md:mb-4"
                        >
                            <Select
                                loading={isCompaniesLoading}
                                options={companyOptions}
                                getPopupContainer={getPopupContainer}
                                placeholder="Select a company"
                            />
                        </Form.Item>

                        <Form.Item
                            label={
                                <div className="flex items-start justify-between w-full flex-wrap">
                                    <span className="flex-1 min-w-0 pr-2">Security Level Name:</span>
                                    <span className="text-xs text-cms-text-main flex-shrink-0 whitespace-nowrap">{nameValue.length}/{SecurityLevelConstants.MaxLength_Name}</span>
                                </div>
                            }
                            name="name"
                            rules={[
                                { required: true, message: 'Please enter security level name' },
                                { max: SecurityLevelConstants.MaxLength_Name, message: `Security level name must not exceed ${SecurityLevelConstants.MaxLength_Name} characters` },
                            ]}
                            className={`mb-0 min-w-0 flex-1 max-md:mb-4 ${styles['form-item-with-label-count']}`}
                        >
                            <Input placeholder="Enter security level name" maxLength={SecurityLevelConstants.MaxLength_Name} />
                        </Form.Item>
                    </div>

                    {/* Row 2: Colors and Sample */}
                    <div className="mb-4 flex items-end gap-2 max-md:flex-col max-md:items-stretch max-md:gap-0">
                        <div className="flex flex-1 items-end gap-2 max-md:flex-col max-md:items-stretch">
                            <Form.Item label="Security Level Color:" className="mb-0 min-w-0 flex-1 max-md:mb-4">
                                <ColorPicker value={selectedColor} onChange={handleColorChange} showText format="hex" />
                            </Form.Item>

                            <Form.Item label="Text Color:" className="mb-0 min-w-0 flex-1 max-md:mb-4">
                                <Select
                                    value={textColor}
                                    onChange={setTextColor}
                                    options={TEXT_COLOR_OPTIONS}
                                    getPopupContainer={getPopupContainer}
                                />
                            </Form.Item>
                        </div>

                        <Form.Item label="Sample:" className="mb-0 flex-1 max-md:mt-3">
                            <CIButton
                                className="h-auto w-auto min-w-fit cursor-default rounded border-none px-3 py-1 text-sm hover:opacity-90 focus:opacity-90"
                                style={{
                                    backgroundColor: colorHex,
                                    color: textColor,
                                    borderColor: colorHex,
                                }}
                            >
                                Security Level Name
                            </CIButton>
                        </Form.Item>
                    </div>

                    {/* Row 3: Description (Full Width) */}
                    <div className="mb-0 flex gap-2">
                        <Form.Item
                            label={
                                <div className="flex items-start justify-between w-full flex-wrap">
                                    <span className="flex-1 min-w-0 pr-2">Description:</span>
                                    <span className="text-xs text-cms-text-main flex-shrink-0 whitespace-nowrap">{descriptionValue.length}/{SecurityLevelConstants.MaxLength_Description}</span>
                                </div>
                            }
                            name="description"
                            rules={[{ max: SecurityLevelConstants.MaxLength_Description, message: `Description must not exceed ${SecurityLevelConstants.MaxLength_Description} characters` }]}
                            className={`mb-0 w-full ${styles['form-item-with-label-count']}`}
                        >
                            <TextArea rows={3} placeholder="Enter description" maxLength={SecurityLevelConstants.MaxLength_Description} />
                        </Form.Item>
                    </div>
                </div>

                {/* Row 4: Permissions Section (Full Width) */}
                <div className="mt-2 flex min-h-[320px] flex-1 flex-col overflow-hidden rounded-none border-none p-0">
                    <div className="flex-shrink-0 py-3 text-sm font-medium">
                        <span>Select the categories this level should have access to</span>
                    </div>

                    <div className="flex flex-1 gap-3 overflow-hidden">
                        {/* Left Panel - Root Categories */}
                        <div className="flex-[0_0_200px] overflow-y-auto border-r-0 py-2">
                            {isTreeLoading ? (
                                <div className="flex items-center justify-center py-6">
                                    <Spin />
                                </div>
                            ) : (
                                rootCategories.map((category) => (
                                    <CategoryItem
                                        key={category.id}
                                        category={category}
                                        isSelected={selectedCategory === category.id}
                                        categoryState={categoryStates[category.id]}
                                        onSelect={handleCategorySelect}
                                    />
                                ))
                            )}
                        </div>

                        {/* Right Panel - Tree View */}
                        <div className="max-h-[300px] flex-1 overflow-y-auto rounded-lg border border-[#e5e9f0] bg-white p-4 shadow-[0px_2px_6px_0px_rgba(144,146,148,0.2)]">
                            {selectedCategoryData && treeDataWithRoot.length > 0 ? (
                                <Tree
                                    checkable
                                    defaultExpandAll
                                    checkedKeys={
                                        categoryStates[selectedCategory]?.isRootChecked
                                            ? [selectedCategory]
                                            : categoryStates[selectedCategory]?.checked || []
                                    }
                                    onCheck={handleTreeCheck}
                                    treeData={treeDataWithRoot}
                                    titleRender={treeTitleRender}
                                    switcherIcon={<DownOutlined />}
                                    fieldNames={{ key: 'id' }}
                                    disabled={editingLevel && !editingLevel.permissionsEditable || false}
                                />
                            ) : (
                                <div className="py-4 text-sm text-[#8c8c8c]">
                                    Select a category to view permissions.
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* Footer Buttons */}
                <div className="mt-auto flex flex-shrink-0 justify-end gap-3 px-0 py-4">
                    <CIButton variant="secondary" onClick={onClose} size="small">
                        Cancel
                    </CIButton>
                    <CIButton variant="primary2" onClick={handleSubmit} size="small">
                        {editingLevel?.id ? 'Update Level' : 'Add Level'}
                    </CIButton>
                </div>
            </Form>
        </Modal>
    );
};

export default memo(AddSecurityLevelModal);
