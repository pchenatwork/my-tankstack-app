import React, { useMemo } from 'react';
import { Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import type { Store } from '@/types/findStore';
import { useFindStoreStore } from '@/store/findStoreStore';

interface LocationMarkerProps {
    store: Store;
    isSelected: boolean;
}

const createMarkerIcon = (isSelected: boolean, isOnline: boolean) =>{
    const onlineStatusColor = isOnline ? "#0478C0" : "#FF0000";
    if(isSelected){
        return L.divIcon({
            className: 'location-marker-selected',
            html: `
            <svg width="32" height="40" viewBox="0 0 32 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M16 0C7.163 0 0 7.163 0 16c0 12 16 24 16 24s16-12 16-24C32 7.163 24.837 0 16 0z" fill="${onlineStatusColor}"/>
                    <circle cx="16" cy="16" r="6" fill="white"/>
                </svg>
            `,
            iconSize: [32, 40],
            iconAnchor: [16, 40],
            popupAnchor: [0, -25],
        });
    }
    else {
        return L.divIcon({
            className: 'custom-marker-dot',
            html: `
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="4" cy="4" r="4" fill="${onlineStatusColor}"/>
                </svg>
            `,
            iconSize: [16, 16],
            iconAnchor: [8, 8],
            popupAnchor: [0, -8],
        });
    }
}


export const LocationMarker = React.memo<LocationMarkerProps>(({store, isSelected}) => {
    // const selectedStoreId = useFindStoreStore(state => state.selectedStoreId);
    const setSelectedStoreId = useFindStoreStore(state => state.setSelectedStoreId);
    // const isSelected = selectedStoreId === store.id;
    const icon = useMemo(
        () => createMarkerIcon(isSelected, store.onlineStatus),
        [isSelected, store.onlineStatus]
    );

    // console.log('LocationMarker rendered', store.id);
    return (
        <Marker
        position={[store.coordinates.latitude, store.coordinates.longitude]}
        eventHandlers={{
            click: () => {
                setSelectedStoreId(store.id);
            }
        }}
        icon={icon}>
            <Popup>
                <div>{store.displayName}</div>
                <div>{store.address}</div>
                <div>{store.storeNumber}</div>
                <div>{store.city}</div>
                <div>{store.state}</div>
                <div>{store.zipCode}</div>
            </Popup>
        </Marker>
    );
}, (prevProps, nextProps) => {
    return (
        prevProps.isSelected === nextProps.isSelected &&
        prevProps.store.onlineStatus === nextProps.store.onlineStatus
    );
});
