import React from 'react';
import StoreListView from './StoreListView';
import StoreMapView from './StoreMapView';
import { useStores } from '@/hooks/useStores';
import type { Store } from '@/types/findStore';

interface MainContentProps {
    onStoreSelect?: (storeId: string) => void;
    searchTerm?: string;
}

const MainContent: React.FC<MainContentProps> = ({ onStoreSelect, searchTerm }) => {
    const hasQuery = !!searchTerm?.trim();
    const { data: stores, isLoading, error } = useStores(searchTerm, hasQuery);
    return (
        <div className="flex h-full">
            {/* Left Panel - Store List */}
            <div className="w-[375px] flex-shrink-0 h-full">
                <StoreListView stores={stores} isLoading={isLoading} error={error} searchTerm={searchTerm} onStoreSelect={onStoreSelect} />
            </div>

            {/* Right Panel - Map */}
            <div className="flex-1 h-full">
                <StoreMapView stores={stores?.results || [] as Store[]} />
            </div>
        </div>
    );
};

export default MainContent;

