import React, { useEffect } from 'react';
import StoreCard from './StoreCardView';
import { useDynamicRowHeight, List, useListRef } from 'react-window';
import type { Store } from '@/types/findStore';
import type { RowComponentProps } from 'react-window';
import { useFindStoreStore } from '@/store/findStoreStore';
import type { StoresResponse } from '@/types/findStore';

interface StoreListViewProps {
    onStoreSelect?: (storeId: string) => void;
    searchTerm?: string;
    stores?: StoresResponse;
    isLoading?: boolean;
    error: Error | null;
}

function StoreCardRowComponent({
    index,
    stores,
    style
  }: RowComponentProps<{
    stores: Store[];
  }>) {
    return (
        <div style={{
            ...style,
            // Add your custom styles below, e.g.:
            padding: '0 9px 0 9px'
        }}>
            <StoreCard
                key={stores[index].id}
                store={stores[index]}
            />
        </div>
    );
  }

const StoreListView: React.FC<StoreListViewProps> = ({stores, isLoading, error, searchTerm = ''}) => {
    const selectedStoreId = useFindStoreStore(state => state.selectedStoreId);
    const hasQuery = !!searchTerm.trim();
    // const { data: stores, isLoading, error } = useStores(searchTerm, hasQuery);
    const listRef = useListRef(null);
    const storeCardRowHeight = useDynamicRowHeight({
        defaultRowHeight: 100
    });

    useEffect(() => {
        if (!selectedStoreId || !stores?.results || !listRef.current) return;
        const selectedIndex = stores.results.findIndex(store => store.id === selectedStoreId);
        if (selectedIndex !== -1) {
            listRef.current.scrollToRow({ index: selectedIndex, align: 'center', behavior: 'instant' });
        }
    }, [selectedStoreId, stores?.results]);

    // Render content based on state
    const renderContent = () => {
        if (!hasQuery) {
            return (
                <div className="flex-1 flex items-center justify-center">
                    <p className="text-sm text-cms-text-explanatory">
                        Search for something to see results
                    </p>
                </div>
            );
        }

        if (isLoading) {
            return (
                <div className="flex-1 flex items-center justify-center">
                    <svg className="animate-spin h-8 w-8 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle
                            className="opacity-25"
                            cx="12"
                            cy="12"
                            r="10"
                            stroke="currentColor"
                            strokeWidth="4"
                        ></circle>
                        <path
                            className="opacity-75"
                            fill="currentColor"
                            d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
                        ></path>
                    </svg>
                </div>
            );
        }

        if (error) {
            return (
                <div className="flex-1 flex items-center justify-center">
                    <p className="text-sm text-cms-text-offline">Error: {error.message}</p>
                </div>
            );
        }

        if (!stores?.results || stores.results.length === 0) {
            return (
                <div className="flex-1 flex items-center justify-center">
                    <p className="text-sm text-cms-text-explanatory">No stores found</p>
                </div>
            );
        }


        return (
            <List
                listRef={listRef}
                rowComponent={StoreCardRowComponent}
                rowHeight={storeCardRowHeight}
                rowCount={stores.results.length}
                rowProps={{ stores: stores.results }}
            >
            </List>
          );
    };

    // Get store count for header
    const storeCount = stores?.count || stores?.results?.length || 0;

    return (
        <div
            className="flex flex-col h-full bg-white"
            style={{
                borderRadius: '10px 0 0 10px',
                border: '1px solid #D8D8D8',
                boxShadow: '0px 2px 6px 0px rgba(144, 146, 148, 0.2)',
            }}
        >
            {/* Header - Stores count */}
            <div className="px-4 py-3 flex-shrink-0">
                <span
                    className="text-sm font-semibold"
                    style={{
                        color: '#2B283D',
                        fontFamily: "'Open Sans', sans-serif",
                    }}
                >
                    Stores ({hasQuery ? storeCount : 0})
                </span>
            </div>

            {/* Store List Content */}
            {renderContent()}
        </div>
    );
};

export default StoreListView;
