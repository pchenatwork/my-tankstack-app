import React, { useState, useEffect } from 'react';
import { Modal } from 'antd';
import { CloseOutlined } from '@ant-design/icons';
import CISearchBox from '@/components/common/CISearchBox';
import MainContent from './MainContainer';
import { getImagePath } from '@/utils';
import { CIButton } from '../common';

interface FindStoreModalProps {
    open: boolean;
    onClose: () => void;
    onStoreSelect?: (storeId: string) => void;
}

const FindStoreModal: React.FC<FindStoreModalProps> = ({ open, onClose, onStoreSelect }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [debouncedSearchTerm, setDebouncedSearchTerm] = useState('');

    useEffect(() => {
        const timer = setTimeout(() => {
            setDebouncedSearchTerm(searchTerm);
        }, 500);
        return () => clearTimeout(timer);
    }, [searchTerm]);

    const handleSearch = () => {
        // TODO: Implement search functionality
        console.log('Searching for:', searchTerm);
    };

    const handleFilter = () => {
        // TODO: Implement filter functionality
        console.log('Opening filter');
    };

    return (
        <Modal
            open={open}
            onCancel={onClose}
            footer={null}
            width="90%"
            style={{ maxWidth: 1400 }}
            closeIcon={<CloseOutlined />}
            className="find-store-modal"
            destroyOnClose
            styles={{
                body: { height: '80vh', display: 'flex', flexDirection: 'column', padding: 0 },
            }}
        >
            <div className="flex flex-col h-full">
                {/* Header */}
                <div className="border-b border-cms-section-line-default  py-2">
                    <div className="flex items-center gap-2">
                        <img
                            src={getImagePath('icons/icon-store.png')}
                            alt="Store"
                            width={28}
                            height={28}
                            className="flex-shrink-0"
                        />
                        <h2 className="m-0 text-lg font-semibold text-cms-text-heading">Find a Store</h2>
                    </div>
                </div>

                {/* Search and Filter Bar */}
                <div className=" py-2">
                    <div className="flex items-center gap-3">
                        <div className="flex-1">
                            <CISearchBox
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                onSearch={handleSearch}
                                placeholder="Search by Store #, City, State or Zip"
                                size="medium"
                            />
                        </div>
                        <CIButton variant="tertiary" size="medium" onClick={handleFilter}>
                            <img src={getImagePath('icons/filter_icon.png')} alt="Filter" width={16} height={16} />
                            Filter
                        </CIButton>
                    </div>
                </div>

                {/* Main Content */}
                <div className="flex-1 overflow-hidden">
                    <MainContent onStoreSelect={onStoreSelect} searchTerm={debouncedSearchTerm} />
                </div>
            </div>
        </Modal>
    );
};

export default FindStoreModal;

