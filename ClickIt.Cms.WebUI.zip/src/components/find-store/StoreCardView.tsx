import React from 'react';
import { Button } from 'antd';
import { getImagePath } from '@/utils';
import type { Store } from '@/types/findStore';
import { useFindStoreStore } from '@/store/findStoreStore';
import { Card } from 'antd';

interface StoreCardProps {
    store: Store;
    isSelected?: boolean;
}

const StoreCard: React.FC<StoreCardProps> = ({ store }) => {
    const selectedStoreId: string | null = useFindStoreStore((state:any) => state.selectedStoreId);
    const setSelectedStoreId = useFindStoreStore((state:any) => state.setSelectedStoreId);
    const isSelected = selectedStoreId === store.id;
    
    const onClick = () => {
        setSelectedStoreId(store.id);
    };
    return (
        <Card
            type="inner"
            onClick={onClick}
            className="w-full text-left relative overflow-hidden"
            style={{
                backgroundColor: '#FFFFFF',
                border: `1px solid ${isSelected ? store.onlineStatus ? '#0478C0' : '#FF0000' : '#D8D8D8'}`,
                borderRadius: '4px',
                boxShadow: '0px 1.5px 4px 0px rgba(225,225,233,0.5)',
                padding: '0 0 0 0',
                marginBottom: '5px',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
            }}
        >
            {/* Blue vertical bar on the left */}
            {<div
                className="absolute left-0 top-0 bottom-0"
                style={{
                    width: isSelected ? '10px' : '0px',
                    backgroundColor: store.onlineStatus ? '#0478C0' : '#FF0000',
                    borderRadius: '3px 0 0 3px',
                    transition: 'all 0.2s ease',
                    opacity: isSelected ? 1 : 0,
                    visibility: isSelected ? 'visible' : 'hidden',
                }}
            />}

            {/* Content area */}
            <div className="flex items-start justify-between relative" >
                {/* Left section: Icon and store details */}
                <div className="flex-1 min-w-0" style={{ paddingTop: '0px' }}>
                    <div className="flex flex-col" style={{ gap: '4px' }}>
                        {/* Store name with location icon */}
                        <div className="flex items-center" style={{ gap: '3px' }}>
                            <img
                                src={getImagePath(store.onlineStatus ? 'icons/icon-link-online-blue.png' : 'icons/icon-link-offline-red.png')}
                                alt="Location"
                                width={20}
                                height={20}
                                className="flex-shrink-0"
                            />
                            <span
                                className="font-semibold text-sm text-cms-text-heading truncate"
                                style={{
                                    fontFamily: "'Open Sans', sans-serif",
                                    fontWeight: 600,
                                    fontSize: '14px',
                                    lineHeight: '1.5',
                                    letterSpacing: '0.28px',
                                    color: '#2B283D',
                                }}
                            >
                                {store.displayName}
                            </span>
                        </div>

                        {/* Store number */}
                        <p
                            className="text-sm text-cms-text-heading m-0"
                            style={{
                                fontFamily: "'Open Sans', sans-serif",
                                fontWeight: 400,
                                fontSize: '14px',
                                lineHeight: '1.5',
                                letterSpacing: '0.28px',
                                color: '#2B283D',
                            }}
                        >
                            Store #: {store.storeNumber}
                        </p>

                        {/* Address */}
                        <div className="flex flex-col">
                            <p
                                className="text-sm text-cms-text-heading m-0"
                                style={{
                                    fontFamily: "'Open Sans', sans-serif",
                                    fontWeight: 400,
                                    fontSize: '14px',
                                    lineHeight: '1.5',
                                    letterSpacing: '0.28px',
                                    color: '#2B283D',
                                }}
                            >
                                {store.address}
                            </p>
                            <p
                                className="text-sm text-cms-text-heading m-0"
                                style={{
                                    fontFamily: "'Open Sans', sans-serif",
                                    fontWeight: 400,
                                    fontSize: '14px',
                                    lineHeight: '1.5',
                                    letterSpacing: '0.28px',
                                    color: '#2B283D',
                                }}
                            >
                                {store.city} {store.state}, {store.zipCode}
                            </p>
                        </div>
                    </div>
                </div>

                {/* Right section: Select Store button - only show when selected */}
                {isSelected && (
                    <div className="flex-shrink-0" style={{ marginLeft: '16px', marginTop: '30px' }}>
                        <Button
                            type="primary"
                            size="small"
                            onClick={(e) => {
                                e.stopPropagation();
                                onClick?.();
                            }}
                            style={{
                                backgroundColor: '#054682',
                                borderColor: '#054682',
                                borderRadius: '4px',
                                padding: '6px 0',
                                height: 'auto',
                                minWidth: '86px',
                                fontFamily: "'Open Sans', sans-serif",
                                fontWeight: 600,
                                fontSize: '12px',
                                lineHeight: '1.5',
                                letterSpacing: '0.24px',
                                color: '#FFFFFF',
                            }}
                        >
                            Select Store
                        </Button>
                    </div>
                )}
            </div>
        </Card>
    );
};

export default StoreCard;
