import React from 'react';
import CIBaseMap from '@/components/common/CIBaseMap';
import { LocationsLayerView } from './LocationsLayerView';


interface StoreMapViewProps {
    stores: any;
}


const StoreMapView: React.FC<StoreMapViewProps> = ({ stores }) => {

    return (
        <div className="h-full w-full">
            <CIBaseMap style={{ height: '100%', width: '100%' }}
            >
                {/* <MapZoomTracker setZoomLevel={setZoomLevel} /> */}
                <LocationsLayerView stores={stores} />
            </CIBaseMap>
        </div>
    );
};

export default StoreMapView;

