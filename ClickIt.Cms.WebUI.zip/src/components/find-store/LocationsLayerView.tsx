import React, { useDeferredValue, useEffect, useMemo, useState } from 'react';
import { useFindStoreStore } from '@/store/findStoreStore';
import { LocationMarker } from './LocationMarker';
import type { Store } from '@/types/findStore';
import { useMap } from 'react-leaflet';

interface LocationsLayerViewProps {
    stores: Store[];
}

// Component that tracks zoom - must be inside MapContainer
function MapZoomTracker({setZoomLevel}: {setZoomLevel: (zoomLevel: number) => void}) {
    const map = useMap();
    

    React.useEffect(() => {
        // Set initial zoom
        setZoomLevel(map.getZoom());

        const updateZoom = () => {
            setZoomLevel(map.getZoom());
        };

        map.on('zoomend', updateZoom);

        return () => {
            map.off('zoomend', updateZoom);
        };
    }, [map, setZoomLevel]);

    return null; // This component doesn't render anything
}

const MIN_ZOOM_LEVEL = 8;

export const LocationsLayerView: React.FC<LocationsLayerViewProps> = ({ stores }) => {
    const map = useMap();

    const selectedStoreId = useFindStoreStore(state => state.selectedStoreId);
    const [zoomLevel, setZoomLevel] = useState(0);
    const [bounds, setBounds] = useState(map.getBounds());
    const [shouldShowLocPin, setShouldShowLocPin] = useState(false);
    const deferredStores = useDeferredValue(stores);

    const visibleStores = useMemo(() => deferredStores.filter((store: Store) => {
        if (!store.coordinates?.latitude || !store.coordinates?.longitude) {
            return false;
        }
        return bounds.contains({lat: store.coordinates.latitude, lng: store.coordinates.longitude});
        // return true;
    }), [deferredStores, bounds]);
    
    // 2. Update bounds on map movement
    useEffect(() => {
        const updateBounds = () => {
            setBounds(map.getBounds());

        };
        
        map.on('moveend', updateBounds);
        map.on('zoomend', updateBounds);
        
        return () => {
            map.off('moveend', updateBounds);
            map.off('zoomend', updateBounds);
        };
    }, [map]);

    useEffect(() => {
        const selectedStore: Store | undefined= stores.find(store => store.id === selectedStoreId);
        if (selectedStore && !bounds.contains({lat: selectedStore.coordinates.latitude, lng: selectedStore.coordinates.longitude})) {
            map.flyTo([selectedStore.coordinates.latitude, selectedStore.coordinates.longitude], zoomLevel, {duration: 0.5});
        }
    }, [selectedStoreId]);
    

    useEffect(() => {
        if (zoomLevel >= MIN_ZOOM_LEVEL || visibleStores.length < 300) {
            setShouldShowLocPin(true);
        } else {
            setShouldShowLocPin(false);
        }
    }, [zoomLevel, bounds, visibleStores]);

 

    if(!shouldShowLocPin) {
    return (
        <>
            <MapZoomTracker setZoomLevel={setZoomLevel} />
            <div
                style={{
                    position: 'absolute',
                    top: 5,
                    left: '50%',
                    transform: 'translateX(-50%)',
                    zIndex: 9999,
                    background: '#1A68AD',
                    color: '#fff',
                    padding: '5px 20px',
                    borderRadius: '8px',
                    fontWeight: 600,
                    fontFamily: "'Open Sans', sans-serif",
                    boxShadow: '0 2px 8px rgba(0,0,0,0.07)',
                    fontSize: '15px',
                }}
                className="shadow-md"
            >
                Zoomed out too far or too many stores! Zoom in to see stores.
            </div>
        </>
    );
}
    

    return (
        <>
        <MapZoomTracker setZoomLevel={setZoomLevel} />
        <div
            style={{
                position: 'absolute',
                top: 5,
                left: '50%',
                transform: 'translateX(-50%)',
                zIndex: 9999,
                background: '#1A68AD',
                color: '#fff',
                padding: '5px 20px',
                borderRadius: '8px',
                fontWeight: 600,
                fontFamily: "'Open Sans', sans-serif",
                boxShadow: '0 2px 8px rgba(0,0,0,0.07)',
                fontSize: '15px',
            }}
            className="shadow-md"
        >
            {visibleStores.length} stores shown
        </div>
        {visibleStores.map((store: Store) => {
            if (store.coordinates?.latitude && store.coordinates?.longitude) {
                return (
                    <LocationMarker 
                        key={store.id} 
                        store={store} 
                        isSelected={selectedStoreId === store.id} 
                    />
                );
            }
            return null; // React ignores null and doesn't require a key
        })}
        </>
    );
};