import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '@/api/client';
import type { SecurityLevelResponse, SingleSecurityLevelResponse, SecurityLevelDto } from '@/types/securityLevel';
import { useAlert } from '@/components/common';

// API functions
export const getSecurityLevels = () =>
    api.get<SecurityLevelResponse>('/security-levels').then((r) => r.data);

export const getSecurityLevelById = (id: string) =>
    api.get<SingleSecurityLevelResponse>(`/security-levels/${id}`).then((r) => r.data);

export const createSecurityLevel = (dto: SecurityLevelDto) =>
    api.post<SingleSecurityLevelResponse>('/security-levels', dto).then((r) => r.data);

export const updateSecurityLevel = (id: string, dto: SecurityLevelDto) =>
    api.put<SingleSecurityLevelResponse>(`/security-levels/${id}`, dto).then((r) => r.data);

export const deleteSecurityLevel = (id: string) =>
    api.delete<SingleSecurityLevelResponse>(`/security-levels/${id}`).then((r) => r.data);

// Hook to get all security levels
export const useSecurityLevels = () => {
    return useQuery<SecurityLevelResponse, Error>({
        queryKey: ['securityLevels'],
        queryFn: getSecurityLevels,
    });
};

// Hook to get a single security level
export const useSecurityLevel = (id: string) => {
    return useQuery<SingleSecurityLevelResponse, Error>({
        queryKey: ['securityLevel', id],
        queryFn: () => getSecurityLevelById(id),
        enabled: !!id,
    });
};

// Hook for creating a security level
export const useCreateSecurityLevel = () => {
    const queryClient = useQueryClient();
    const { success, error } = useAlert();
    
    return useMutation({
        mutationFn: createSecurityLevel,
        onSuccess: (data) => {
            if (data.isSuccessful) {
                queryClient.invalidateQueries({ queryKey: ['securityLevels'] });
                const successMsg = data.userMessages?.[0]?.message || 'Success! Security level added successfully.';
                success({
                    title: successMsg,
                });
            } else {
                const errorMsg = data.userMessages?.[0]?.message || 'Error! Unable to add security level. Please try again.';
                error({
                    title: errorMsg,
                });
            }
        },
        onError: (err: any) => {
            const msg = err.response?.data?.userMessages?.[0]?.message || 'Error! Unable to add security level. Please try again.';
            error({ title: msg });
        },
    });
};

// Hook for updating a security level
export const useUpdateSecurityLevel = () => {
    const queryClient = useQueryClient();
    const { success, error } = useAlert();
    
    return useMutation({
        mutationFn: ({ id, dto }: { id: string; dto: SecurityLevelDto }) => updateSecurityLevel(id, dto),
        onSuccess: (data) => {
            if (data.isSuccessful) {
                queryClient.invalidateQueries({ queryKey: ['securityLevels'] });
                queryClient.invalidateQueries({ queryKey: ['securityLevel'] });
                const successMsg = data.userMessages?.[0]?.message || 'Success! Security level updated successfully.';
                success({
                    title: successMsg,
                });
            } else {
                const errorMsg = data.userMessages?.[0]?.message || 'Error! Unable to update security level. Please try again.';
                error({
                    title: errorMsg,
                });
            }
        },
        onError: (err: any) => {
            const msg = err.response?.data?.userMessages?.[0]?.message || 'Error! Unable to update security level. Please try again.';
            error({ title: msg });
        },
    });
};

// Hook for deleting a security level
export const useDeleteSecurityLevel = () => {
    const queryClient = useQueryClient();
    const { success, error } = useAlert();
    
    return useMutation({
        mutationFn: deleteSecurityLevel,
        onSuccess: (data) => {
            if (data.isSuccessful) {
                queryClient.invalidateQueries({ queryKey: ['securityLevels'] });
                const successMsg = data.userMessages?.[0]?.message || 'Success! Security level deleted successfully.';
                success({
                    title: successMsg,
                });
            } else {
                const errorMsg = data.userMessages?.[0]?.message || 'Error! Unable to delete security level. Please try again.';
                error({
                    title: errorMsg,
                });
            }
        },
        onError: (err: any) => {
            const msg = err.response?.data?.userMessages?.[0]?.message || 'Error! Unable to delete security level. Please try again.';
            error({ title: msg });
        },
    });
};

