import { useQuery } from '@tanstack/react-query';
import { getStores } from '@/api/stores';
import type { StoresResponse } from '@/types/findStore';

/**
 * Hook to fetch stores with optional query parameter
 * @param query - Optional query string for filtering stores (Store #, City, State, or Zip)
 * @returns Query result with stores data
 */
export const useStores = (query?: string, enabled: boolean = true) => {
    return useQuery<StoresResponse, Error>({
        queryKey: ['stores', query],
        queryFn: () => getStores(query),
        enabled: enabled && !!query, // Only fetch if query is provided and enabled is true
    });
};


