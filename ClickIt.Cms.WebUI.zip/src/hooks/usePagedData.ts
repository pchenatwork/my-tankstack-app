import { keepPreviousData, useQuery } from '@tanstack/react-query';
import type { ApiResponse, PagedRequest, RequestQueryKey, PagedResponse } from '../types/common';
import { api } from '@/api';

async function fetchPagedDateAsync<T>(path: string, params: PagedRequest<T>): Promise<PagedResponse<T>> {
    const response = await api.post<ApiResponse<PagedResponse<T>>>(path, params);
    if (!response.data.isSuccessful) {
        // Note from PCH: HTTP error seems already handled by Axios+useQuery. JS execution won't reach here if there are HTTP errors.
        // TODO: Handle errors more gracefully
        response.data.userMessages?.forEach((element) => {
            console.error(`fetchPagedDateAsync('${path}', ...) Error: ${element.message}`);
        });
        throw new Error('API Call was not okay : blar blar blar ');
    }
    return response.data.payLoad as PagedResponse<T>;
}

/**
 * Hook for getting a generic PagedResponse\<T\> from API, limited to 'POST'.
 * @param path API EndPoint
 * @param queryKey  \{ name: queryName; params: PagedRequest\<T\> }
 * @returns PagedResponse\<T\>
 */
const usePagedData = <T>(path: string, queryKey: RequestQueryKey<PagedRequest<T>>) => {
    return useQuery({
        queryKey: [queryKey.name, queryKey.params],
        queryFn: () => fetchPagedDateAsync<T>(path, queryKey.params),
        placeholderData: keepPreviousData,
    });
};
export default usePagedData;
