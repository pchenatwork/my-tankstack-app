import { useQuery } from '@tanstack/react-query';

//import type { UserResponse } from '@/types/user';
import type { PermissionTreeResponse } from '@/types/securityLevel';

//import { getUsers } from '../api';
import { api } from '@/api/client';

/* TODO : PCH Obsoleted by usePagedData.ts
export const useUsers = (pageNumber: number, pageSize: number) => {
    return useQuery<UserResponse, Error>({
        queryKey: ['users', pageNumber, pageSize],
        queryFn: () => getUsers({ pageNumber, pageSize }),
    });
};
*/

// Permission tree API (part of users API)
export const getPermissionTree = () =>
    api.get<PermissionTreeResponse>('/users/security-level-permissions').then((r) => r.data);

// Hook to get permission tree
export const usePermissionTree = () => {
    return useQuery<PermissionTreeResponse, Error>({
        queryKey: ['permissionTree'],
        queryFn: getPermissionTree,
    });
};
