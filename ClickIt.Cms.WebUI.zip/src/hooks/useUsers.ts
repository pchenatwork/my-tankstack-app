import { keepPreviousData, useQuery } from '@tanstack/react-query';

import type { PagedRequestGetUsers, PagedResponseGetUsers, UserResponse } from '@/types/user';
import type { PermissionTreeResponse } from '@/types/securityLevel';

import { getUsers, getUsersNew } from '../api';
import { api } from '@/api/client';

/** TODO : PCH To be obsoleted, use 'useUsersNew'  */
export const useUsers = (pageNumber: number, pageSize: number) => {
    return useQuery<UserResponse, Error>({
        queryKey: ['users', pageNumber, pageSize],
        queryFn: () => getUsers({ pageNumber, pageSize }),
    });
};

// Permission tree API (part of users API)
export const getPermissionTree = () =>
    api.get<PermissionTreeResponse>('/users/security-level-permissions').then((r) => r.data);

// Hook to get permission tree
export const usePermissionTree = () => {
    return useQuery<PermissionTreeResponse, Error>({
        queryKey: ['permissionTree'],
        queryFn: getPermissionTree,
    });
};

// TODO: PCH Introduced 12/16/2025. 'useUsers' hook above to be obsoleted
export const useUsersNew = (req: PagedRequestGetUsers, debouncedfilterString?: string) => {
    var x: PagedRequestGetUsers = { ...req, filterString: debouncedfilterString ?? req.filterString };
    return useQuery<PagedResponseGetUsers, Error>({
        queryKey: ['usersNew', x],
        queryFn: () => getUsersNew(x),
        placeholderData: keepPreviousData,
    });
};
