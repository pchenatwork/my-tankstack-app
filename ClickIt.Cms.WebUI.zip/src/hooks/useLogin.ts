import { useMutation, useQueryClient } from '@tanstack/react-query';
import { auth, type LoginPayload } from '@/api/auth';
import { STORAGE_KEYS } from '@/constants/storage';

type LoginVariables = LoginPayload & {
    rememberMe: boolean;
};

export const useLogin = () => {
    const queryClient = useQueryClient();

    return useMutation({
        // variables = { username, password, rememberMe }
        mutationFn: ({ username, password }: LoginVariables) => auth.login({ username, password }),

        onSuccess: (_, variables) => {
          console.log('Login successful');
            const { username, rememberMe } = variables;

            // Remember Me logic ONLY after successful login
            if (rememberMe) {
                localStorage.setItem(STORAGE_KEYS.USERNAME, username);
            } else {
                localStorage.removeItem(STORAGE_KEYS.USERNAME);
            }

            // Invalidate profile so useProfile refetches and syncs Zustand
            queryClient.invalidateQueries({ queryKey: ['profile'] });
        },
    });
};
