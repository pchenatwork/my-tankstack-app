import { useQuery } from '@tanstack/react-query';
import { useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

import { auth } from '@/api/auth';
import { useAuthStore } from '@/store/authStore';
import type { UserProfile } from '@/types/user';

/**
 * Hook to fetch and sync user profile/permissions from the API
 * - Automatically updates auth store on success
 * - Redirects to login on auth failures (except when already on login page)
 * - Triggered on mount and can be manually refetched via query client
 */
export const useProfile = () => {
    const setUser = useAuthStore((s) => s.setUser);
    const clearUser = useAuthStore((s) => s.clearUser);
    const navigate = useNavigate();
    const { pathname } = useLocation();
    const previousPathnameRef = useRef(pathname);

    const query = useQuery<UserProfile, Error>({
        queryKey: ['profile'],
        queryFn: auth.profile,
        retry: false,
    });

    useEffect(() => {
        // Handle successful response
        if (query.isSuccess && query.data?.isSuccessful) {
            setUser(query.data);
            previousPathnameRef.current = pathname;
            return;
        }

        // Handle auth failures - redirect to login
        if (query.isError || (query.isSuccess && query.data && !query.data.isSuccessful)) {
            // Prevent redirect loops
            if (pathname !== '/login') {
                clearUser();
                navigate('/login', {
                    replace: true,
                    state: { from: { pathname: previousPathnameRef.current } },
                });
            }
        }

        previousPathnameRef.current = pathname;
    }, [query.isSuccess, query.isError, query.data, pathname, setUser, clearUser, navigate]);

    return query;
};
