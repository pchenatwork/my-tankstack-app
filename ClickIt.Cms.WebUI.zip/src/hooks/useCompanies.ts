import { useQuery } from '@tanstack/react-query';
import { api } from '@/api/client';
import type { CompanyResponse } from '@/types/securityLevel';
import type { CompanyDetailsParameters } from '@/types/company';

// API function to get companies
export const getCompanies = () =>
    api.get<CompanyResponse>('/companies').then((r) => r.data);

// Hook to get companies
export const useCompanies = () => {
    return useQuery<CompanyResponse, Error>({
        queryKey: ['companies'],
        queryFn: getCompanies,
    });
};

// API function to update company
export const updateCompany = (companyId: number, companyData: CompanyDetailsParameters) =>
    api.put<CompanyResponse>(`/companies/${companyId}`, companyData).then((r) => r.data);

// API function to create company (using POST)
export const createCompany = (companyData: CompanyDetailsParameters) =>
    api.post<CompanyResponse>('/companies', companyData).then((r) => r.data);

// API function to delete company
export const deleteCompany = (companyId: number, deleteDVRs: boolean = false) =>
    api.delete<CompanyResponse>(`/companies/${companyId}`, { params: { deleteDVRs } }).then((r) => r.data);

