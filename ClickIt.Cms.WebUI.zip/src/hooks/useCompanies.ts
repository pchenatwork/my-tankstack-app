import { useQuery } from '@tanstack/react-query';
import { api } from '@/api/client';
import type { CompanyResponse } from '@/types/securityLevel';
import type { Company, CompanyDetailsParameters } from '@/types/company';
import type { ApiResponse } from '@/types/common';

// API function to get companies
export const getCompanies = () => api.get<ApiResponse<Company[]>>('/companies').then((r) => r.data);

// Hook to get companies
export const useCompanies = () => {
    return useQuery<ApiResponse<Company[]>, Error>({
        queryKey: ['companies'],
        queryFn: getCompanies,
        staleTime: 5 * 60 * 1000, // don't reload if < 5 minutes
    });
};

// API function to update company
export const updateCompany = (companyId: number, companyData: CompanyDetailsParameters) =>
    api.put<CompanyResponse>(`/companies/${companyId}`, companyData).then((r) => r.data);

// API function to create company (using POST)
export const createCompany = (companyData: CompanyDetailsParameters) =>
    api.post<CompanyResponse>('/companies', companyData).then((r) => r.data);

// API function to delete company
export const deleteCompany = (companyId: number, deleteDVRs: boolean = false) =>
    api.delete<CompanyResponse>(`/companies/${companyId}`, { params: { deleteDVRs } }).then((r) => r.data);
