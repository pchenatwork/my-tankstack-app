import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { App as AntApp } from 'antd';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';

import { AlertProvider } from '@/components/common';
import LoginPage from '@/pages/login/LoginPage';

import { RedirectIfAuth, RequireAuth } from './components/auth';
import Layout from './Layout';
import CompanySetupPage from './pages/cms-settings/CompanySetupPage';
import EnterpriseOverviewPage from './pages/investigation-module/enterprise-overview/EnterpriseOverviewPage';
import SelectAStorePage from './pages/investigation-module/investigation-builder/SelectAStorePage';
import OverviewPage from './pages/OverviewPage';
import SecurityLevelsPage from './pages/user-management/SecurityLevelsPage';
import VideoPlaybackPage from './pages/vms/webClient/VideoPlaybackPage';
//import UserSetupPage from './pages/user-management/UserSetupPage';
import { createPlaceholder } from './utils/placeholderUtils';
import UserSetupPage2 from './pages/user-management/UserSetupPage2';

const AlertsPage = createPlaceholder('Alerts');


// Dynamic route component that extracts title from pathname and renders directly
const DynamicRoute = () => {
    const location = useLocation();
    const pathSegments = location.pathname.split('/').filter(Boolean);
    const title =
        pathSegments.length > 0
            ? pathSegments[pathSegments.length - 1]
                .split('-')
                .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                .join(' ')
            : 'Page';

    return (
        <div style={{ padding: 16 }}>
            <h2 style={{ margin: '10px 0', color: 'var(--color-text-strong)' }}>{title}</h2>
            <p style={{ color: 'var(--color-text)' }}>This page is a placeholder. Content coming soon.</p>
        </div>
    );
};

// Create QueryClient outside component to prevent recreation on every render
// Configure with sensible defaults to prevent unnecessary refetches
const queryClient = new QueryClient({
    defaultOptions: {
        queries: {
            // Don't refetch on window focus to prevent unwanted refreshes
            refetchOnWindowFocus: false,
            // Don't refetch on reconnect
            refetchOnReconnect: false,
            // TODO: revisit if required, Retry failed requests once
            retry: 0,
        },
    },
});

export default function App() {
    return (
        <QueryClientProvider client={queryClient}>
            <AntApp>
                <AlertProvider>
                    <Routes>
                        <Route
                            path="/login"
                            element={
                                <RedirectIfAuth redirectTo="/overview">
                                    <LoginPage />
                                </RedirectIfAuth>
                            }
                        />
                        <Route
                            element={
                                <RequireAuth>
                                    <Layout />
                                </RequireAuth>
                            }
                        >
                            <Route path="/" element={<Navigate to="/overview" replace />} />
                            <Route path="/overview" element={<OverviewPage />} />
                            <Route path="/alerts" element={<AlertsPage />} />
                            <Route path="/vms/web-client/video-playback" element={<VideoPlaybackPage />} />
                    {/* Dynamic routes from API - catch-all for any nested paths */}
                            <Route path="/vms/*" element={<DynamicRoute />} />
                            <Route
                                path="/admin/operation-center/user-management/user-configuration"
                                element={<UserSetupPage2 />}
                            />
                            <Route
                                path="/admin/operation-center/user-management/security-levels"
                                element={<SecurityLevelsPage />}
                            />
                            <Route
                                path="/admin/operation-center/cms-settings/company-setup"
                                element={<CompanySetupPage />}
                            />
                            {/* InvestigationModule */}
                            <Route
                                path="/vms/investigation-module/enterprise-overview"
                                element={<EnterpriseOverviewPage />}
                            />
                            <Route
                                path="/vms/investigation-module/investigation-builder"
                                element={<SelectAStorePage />}
                            />
                            <Route path="/admin/*" element={<DynamicRoute />} />
                            {/* Fallback catch-all for any other dynamic routes */}
                            <Route path="*" element={<DynamicRoute />} />
                        </Route>
                    </Routes>
                </AlertProvider>
            </AntApp>
        </QueryClientProvider>
    );
}
