import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { StyleProvider } from '@ant-design/cssinjs';
import { ConfigProvider } from 'antd';
import App from '@/App';

// Import order: Tailwind base -> Fonts -> SCSS -> other styles
import '@/tailwind.css';

// Font imports (moved from SCSS to avoid @import deprecation)
import '@fontsource/open-sans/300.css';
import '@fontsource/open-sans/400.css';
import '@fontsource/open-sans/600.css';
import '@fontsource/open-sans/700.css';
import '@fontsource/open-sans/800.css';

import '@/styles/main.scss';
import './styles.css';

import { antdTheme } from '@/theme/antdTheme';

import { applyTokensToCssVars } from './theme/applyTokens';

applyTokensToCssVars();

// Get basename from env variable
const basename = import.meta.env.VITE_CI_APP_BASE_URL || '/';

ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
        <StyleProvider hashPriority="low">
            <ConfigProvider theme={antdTheme}>
                <BrowserRouter basename={basename}>
                    <App />
                </BrowserRouter>
            </ConfigProvider>
        </StyleProvider>
    </React.StrictMode>,
);
