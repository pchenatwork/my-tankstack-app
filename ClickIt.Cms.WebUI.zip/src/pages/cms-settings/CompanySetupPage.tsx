import { useQueryClient } from '@tanstack/react-query';
import { App, Dropdown, Pagination, Space, Spin, Table } from 'antd';
import type { ColumnsType } from 'antd/es/table';
import React, { useMemo, useState } from 'react';

import type { Company, CompanyDetailsParameters } from '@/types/company';
import { getImagePath } from '@/utils';
import { useCompanies, createCompany, updateCompany, deleteCompany } from '@/hooks/useCompanies';
import CompanyDetailsModal from '@/components/cms-settings/company-setup/CompanyDetailsModal';
import CompanyEditModal, { type CompanyFormValues } from '@/components/cms-settings/company-setup/CompanyEditModal';
import { CIButton } from '../../components/common';

const CompanySetupPage: React.FC = () => {
    const { modal, message } = App.useApp();
    const queryClient = useQueryClient();
    const { data: companiesResponse, isLoading: loading, isError } = useCompanies();
    const [pageNumber, setPageNumber] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
    const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editingCompany, setEditingCompany] = useState<Company | null>(null);
    const [editMode, setEditMode] = useState<'edit' | 'add'>('edit');

    // Map the response to match our Company interface
    const allCompanies = useMemo<Company[]>(() => {
        if (!companiesResponse?.isSuccessful || !companiesResponse.payLoad) {
            return [];
        }
        return companiesResponse.payLoad.map((company: any) => ({
            id: company.id || company.Id || 0,
            name: company.name || company.Name || '',        
            address1: company.address1 || company.Address1 || '',
            address2: company.address2 || company.Address2 || '',
            city: company.city || company.City || '',
            state: company.state || company.State || '',
            zip: company.zip || company.Zip || '',
            country: company.country || company.Country || '',
            phone: company.phone || company.Phone || '',
            fax: company.fax || company.Fax || '',
            emailServer: company.emailServer || company.EmailServer || '',
            emailAccount: company.emailAccount || company.EmailAccount || '',
            emailPassword: company.emailPassword || company.EmailPassword || '',
            customPortNumber: company.customPortNumber || company.CustomPortNumber || 0,
            cmsManager: company.cmsManager || company.CmsManager || '',
            extension: company.extension || company.Extension || '',
            companyUrl: company.companyUrl || company.CompanyUrl || '',
            companyLogo: company.companyLogo || company.CompanyLogo || '',
        }));
    }, [companiesResponse]);

    // Calculate paginated companies
    const totalCount = allCompanies.length;
    const startIndex = (pageNumber - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    const companies = allCompanies.slice(startIndex, endIndex);

    const refreshCompanies = () => {
        queryClient.invalidateQueries({ queryKey: ['companies'] });
    };

    const handleNewCompany = () => {
        setEditingCompany(null);
        setEditMode('add');
        setIsEditModalOpen(true);
    };

    const handleCloseEditModal = () => {
        setIsEditModalOpen(false);
        setEditingCompany(null);
    };

    const handleCompanyClick = (company: Company) => {
        setSelectedCompany(company);
        setIsDetailsModalOpen(true);
    };

    const handleCloseDetailsModal = () => {
        setIsDetailsModalOpen(false);
        setSelectedCompany(null);
    };

    const handleDetails = (company: Company) => {
        setSelectedCompany(company);
        setIsDetailsModalOpen(true);
    };

    const handleEdit = (company: Company) => {
        setEditingCompany(company);
        setEditMode('edit');
        setIsEditModalOpen(true);
    };

    // Helper function to extract messages from userMessages array
    const extractUserMessages = (userMessages?: any[]): string => {
        if (!userMessages || userMessages.length === 0) {
            return '';
        }
        return userMessages
            .map((msg) => (typeof msg === 'string' ? msg : msg?.Message || ''))
            .filter((msg) => msg)
            .join('\n');
    };

    // Helper function to extract messages from both userMessages and systemMessages arrays
    const extractAllMessages = (userMessages?: any[], systemMessages?: any[]): string => {
        const userMsg = extractUserMessages(userMessages);
        const systemMsg = extractUserMessages(systemMessages);
        const messages = [userMsg, systemMsg].filter((msg) => msg);
        return messages.join('\n');
    };

    const handleSubmitCompany = async (values: CompanyFormValues) => {
        try {
            // Map CompanyFormValues to CompanyDetailsParameters
            const companyData: CompanyDetailsParameters = {
                UAPID: 0, // Backend will set this from CurrentUapid
                CompanyId: editMode === 'add' || !editingCompany ? 0 : editingCompany.id,
                CompanyName: values.name,
                Address1: values.address1 || '',
                Address2: values.address2 || '',
                City: values.city || '',
                State: values.state || '',
                Zip: values.zip || '',
                Phone: values.phone || '',
                Ext: editingCompany?.extension || '', // Preserve existing extension when updating
                Fax: values.fax || '',
                EmailServer: values.emailServer || '',
                EmailAccount: values.emailAccount || '',
                EmailPassword: values.emailPassword || '',
                UseSSL: values.useTlsSsl || false,
                UseCustomPort: values.useCustomPort || false,
                EncryptData: false, // Default value
                AutoLiveIsOn: false, // Default value
                AutoLiveRefreshSeconds: 0, // Default value
                AutoUpdateDVRDescription: false, // Default value
                HideOfflineSystems: false, // Default value
                CustomPort: values.customPortNumber || 25,
                CmsManager: values.cmsManager || '',
                EmailEventTypes: values.notifications?.join(',') || '',
                DvrLogCategories: '', // Default value
                MapZoomLevel: undefined,
                MapCenterLatitude: undefined,
                MapCenterLongitude: undefined,
                IsManagedByClickIt: false, // Default value
                //AutoLiveHVRLocalTime: new Date().toISOString(), // Default value
                VluSummary: false, // Default value
                VluReporting: false, // Default value
                VluPathAnalysis: false, // Default value
                Country: values.country || '',
                CompanyURL: values.companyUrl || '',
                CompanyLogo: values.companyLogo || '',
            };

            let response;
            if (editMode === 'add' || !editingCompany) {
                // Create new company
                response = await createCompany(companyData);
            } else {
                // Update existing company
                response = await updateCompany(editingCompany.id, companyData);
            }

            if (response.isSuccessful) {
                const successMessage =
                    extractUserMessages(response.userMessages) ||
                    (editMode === 'add' || !editingCompany
                        ? `Company "${values.name}" has been created.`
                        : `Company "${values.name}" has been updated.`);
                message.success(successMessage);
                setIsEditModalOpen(false);
                setEditingCompany(null);
                refreshCompanies();
            } else {
                const errorMessage =
                    extractUserMessages(response.userMessages) ||
                    `Failed to ${editMode === 'add' ? 'create' : 'update'} company. Please try again.`;
                message.error(errorMessage);
            }
        } catch (error: any) {
            // Extract error message from API response if available
            let errorMessage = `Failed to ${editMode === 'add' ? 'create' : 'update'} company. Please try again.`;
            
            if (error?.response?.data) {
                const responseData = error.response.data;
                const apiErrorMessage = extractAllMessages(responseData.UserMessages, responseData.SystemMessages);
                if (apiErrorMessage) {
                    errorMessage = apiErrorMessage;
                } else if (responseData.message) {
                    errorMessage = responseData.message;
                }
            } else if (error?.message) {
                errorMessage = error.message;
            }
            
            message.error(errorMessage);
            console.error('Company update/create error:', error);
        }
    };

    const handleDelete = (company: Company) => {
        modal.confirm({
            title: 'Delete Company',
            content: `Are you sure you want to delete "${company.name}"?`,
            okText: 'Delete',
            okType: 'danger',
            cancelText: 'Cancel',
            onOk: async () => {
                try {
                    const response = await deleteCompany(company.id, false);
                    if (response.isSuccessful) {
                        const successMessage = extractUserMessages(response.userMessages) || 
                            `Company "${company.name}" has been deleted.`;
                        message.success(successMessage);
                        refreshCompanies();
                    } else {
                        const errorMessage = extractUserMessages(response.userMessages) || 
                            `Failed to delete company "${company.name}". Please try again.`;
                        message.error(errorMessage);
                    }
                } catch (error: any) {
                    // Extract error message from API response if available
                    let errorMessage = `Failed to delete company "${company.name}". Please try again.`;
                    
                    if (error?.response?.data) {
                        const responseData = error.response.data;
                        const apiErrorMessage = extractAllMessages(responseData.UserMessages, responseData.SystemMessages);
                        if (apiErrorMessage) {
                            errorMessage = apiErrorMessage;
                        } else if (responseData.message) {
                            errorMessage = responseData.message;
                        }
                    } else if (error?.message) {
                        errorMessage = error.message;
                    }
                    
                    message.error(errorMessage);
                    console.error('Company delete error:', error);
                }
            },
        });
    };

    const getActionItems = (company: Company) => [
        {
            key: 'details',
            label: (
                <Space size="small">
                    <img src={getImagePath('icons/icon-company.png')} alt="Details" width={16} />
                    <span>Company Details</span>
                </Space>
            ),
            onClick: () => handleDetails(company),
        },
        {
            key: 'edit',
            label: (
                <Space size="small">
                    <img src={getImagePath('icons/edit_icon.png')} alt="Edit" width={16} />
                    <span>Edit</span>
                </Space>
            ),
            onClick: () => handleEdit(company),
        },
        {
            key: 'delete',
            label: (
                <Space size="small">
                    <img src={getImagePath('icons/delete_icon.png')} alt="Delete" width={16} />
                    <span>Delete</span>
                </Space>
            ),
            onClick: () => handleDelete(company),
            danger: true,
        },
    ];

    const columns: ColumnsType<Company> = [
        {
            title: 'Name',
            dataIndex: 'name',
            key: 'name',
            render: (text: string) => (
                <span
                    style={{
                        fontFamily: 'var(--font-body)',
                        fontSize: 'var(--font-size-body)',
                        fontWeight: 400,
                        color: 'var(--color-text-main)',
                    }}
                >
                    {text}
                </span>
            ),
        },
        {
            title: 'Address',
            dataIndex: 'address',
            key: 'address',
            render: (text: string, record: Company) => (
                <span
                    style={{
                        fontFamily: 'var(--font-body)',
                        fontSize: 'var(--font-size-body)',
                        fontWeight: 400,
                        color: 'var(--color-text-main)',
                    }}
                >
                    {text || record.address1 || ''}
                </span>
            ),
        },
        {
            title: 'City',
            dataIndex: 'city',
            key: 'city',
            render: (text: string) => (
                <span
                    style={{
                        fontFamily: 'var(--font-body)',
                        fontSize: 'var(--font-size-body)',
                        fontWeight: 400,
                        color: 'var(--color-text-main)',
                    }}
                >
                    {text || ''}
                </span>
            ),
        },
        {
            title: 'State',
            dataIndex: 'state',
            key: 'state',
            render: (text: string) => (
                <span
                    style={{
                        fontFamily: 'var(--font-body)',
                        fontSize: 'var(--font-size-body)',
                        fontWeight: 400,
                        color: 'var(--color-text-main)',
                    }}
                >
                    {text || ''}
                </span>
            ),
        },
        {
            title: 'Zipcode',
            dataIndex: 'zip',
            key: 'zip',
            render: (text: string) => (
                <span
                    style={{
                        fontFamily: 'var(--font-body)',
                        fontSize: 'var(--font-size-body)',
                        fontWeight: 400,
                        color: 'var(--color-text-main)',
                    }}
                >
                    {text || ''}
                </span>
            ),
        },
        {
            title: 'Country',
            dataIndex: 'country',
            key: 'country',
            render: (text: string) => (
                <span
                    style={{
                        fontFamily: 'var(--font-body)',
                        fontSize: 'var(--font-size-body)',
                        fontWeight: 400,
                        color: 'var(--color-text-main)',
                    }}
                >
                    {text || ''}
                </span>
            ),
        },
        {
            title: 'Actions',
            key: 'actions',
            width: 80,
            align: 'center',
            render: (_: any, record: Company) => (
                <div onClick={(e) => e.stopPropagation()}>
                    <Dropdown menu={{ items: getActionItems(record) }} trigger={['click']}>
                        <img
                            src={getImagePath('icons/3dots.png')}
                            alt="Menu"
                            className="cursor-pointer"
                            width={24}
                            style={{ opacity: 0.6 }}
                        />
                    </Dropdown>
                </div>
            ),
        },
    ];

    return (
        <div className="min-h-screen p-6">
            {/* Header */}
            <div className="mb-6 flex items-center justify-between">
                <h1
                    style={{
                        fontFamily: 'var(--font-heading)',
                        fontSize: 'var(--font-size-heading)',
                        fontWeight: 700,
                        color: 'var(--color-text-headings)',
                        lineHeight: 1.2,
                        letterSpacing: '0.36px',
                        margin: 0,
                    }}
                >
                    Company Setup
                </h1>

                <CIButton variant="primary1" size="small" onClick={handleNewCompany}>
                    New Company
                </CIButton>
            </div>

            {/* Main Container with Table */}
            <div
                className="mb-6 bg-white p-4"
                style={{
                    borderRadius: 'var(--container-border-radius)',
                    boxShadow: 'var(--container-shadow)',
                }}
            >
                {/* Toolbar */}
                <div className="mb-4 flex items-center justify-between">
                    <span
                        style={{
                            fontFamily: 'var(--font-body)',
                            fontSize: 'var(--font-size-body)',
                            fontWeight: 400,
                            color: 'var(--color-text-main)',
                            lineHeight: 1.5,
                            letterSpacing: '0.28px',
                        }}
                    >
                        Companies: <span style={{ fontWeight: 600 }}>{totalCount}</span>
                    </span>
                </div>

                {/* Table */}
                {loading ? (
                    <div className="flex h-64 items-center justify-center">
                        <Spin size="large" />
                    </div>
                ) : isError ? (
                    <div className="flex h-64 items-center justify-center">
                        <span style={{ color: 'var(--color-text-error)' }}>Failed to load companies</span>
                    </div>
                ) : (
                    <Table
                        columns={columns}
                        dataSource={companies}
                        rowKey="id"
                        pagination={false}
                        rowClassName={(_, index) =>
                            index % 2 === 0 ? 'bg-white cursor-pointer' : 'bg-gray-50 cursor-pointer'
                        }
                        size="small"
                        onRow={(record) => ({
                            onClick: () => handleCompanyClick(record),
                        })}
                    />
                )}

                {/* Pagination */}
                {totalCount > 10 && (
                    <div className="mt-6 flex justify-end">
                        <Pagination
                            current={pageNumber}
                            pageSize={pageSize}
                            total={totalCount}
                            onChange={(page, size) => {
                                setPageNumber(page);
                                setPageSize(size);
                            }}
                            showSizeChanger
                            showTotal={(total) => `Total ${total} items`}
                        />
                    </div>
                )}
            </div>

            {/* Company Details Modal */}
            <CompanyDetailsModal
                company={selectedCompany}
                open={isDetailsModalOpen}
                onClose={handleCloseDetailsModal}
                onEdit={handleEdit}
            />

            {/* Add / Edit Company Modal */}
            <CompanyEditModal
                open={isEditModalOpen}
                mode={editMode === 'add' || !editingCompany ? 'add' : 'edit'}
                initialCompany={editingCompany ?? undefined}
                onCancel={handleCloseEditModal}
                onSubmit={handleSubmitCompany}
            />
        </div>
    );
};

export default CompanySetupPage;
