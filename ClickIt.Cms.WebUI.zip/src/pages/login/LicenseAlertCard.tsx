import { type FC } from 'react';
import { ExclamationCircleFilled, PhoneOutlined, MailOutlined } from '@ant-design/icons';

type LicenseStatus = 'expiring' | 'expired' | 'none';

interface LicenseAlertItem {
    label: string;
    remaining: number;
}

interface LicenseAlertCardProps {
    status: LicenseStatus;
    daysLeft?: number;
    items?: LicenseAlertItem[];
}

export const LicenseAlertCard: FC<LicenseAlertCardProps> = ({ status, daysLeft, items = [] }) => {
    if (status === 'none') return null;

    const isExpired = status === 'expired';

    return (
        <div className="w-full bg-side-panel-background rounded-xl p-4 shadow-sm border border-none my-4">
            {/* Header */}
            <div className="flex items-center gap-2 text-cms-text-offline font-bold mb-2 text-base">
                <ExclamationCircleFilled className="text-red-500" />
                <span>Attention</span>
            </div>

            {/* Red Banner */}
            <div className="bg-negative text-white font-bold rounded-lg px-4 py-2 text-base">
                {isExpired ? <>Central License is Expired</> : <>Central License Expiring in {daysLeft} Days</>}
            </div>

            {/* License warnings (only for expiring state) */}
            {!isExpired && items.length > 0 && (
                <div className="mt-3 space-y-1">
                    {items.map((item, idx) => (
                        <div key={idx} className="cms-error-pill text-xs font-normal">
                            {item.label}: <span className="text-xs">{item.remaining}</span>
                        </div>
                    ))}
                </div>
            )}

            {/* Support Info */}
            <div className="mt-4 flex items-center gap-4 text-cms-text-main text-xs flex-wrap font-normal">
                <span className="font-medium">Contact ClickIt Support:</span>

                <a href="tel:+16316862950" className="flex items-center gap-1">
                    <PhoneOutlined /> (631) 686-2950
                </a>

                <a href="mailto:support@clickitinc.com" className="flex items-center gap-1">
                    <MailOutlined /> support@clickitinc.com
                </a>
            </div>
        </div>
    );
};
