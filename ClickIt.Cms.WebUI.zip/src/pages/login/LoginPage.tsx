// src/pages/LoginPage.tsx
import type { FC } from 'react';
import { Form, Input, Button, Checkbox } from 'antd';
import type { FormProps } from 'antd';
import { useLocation, useNavigate } from 'react-router-dom';
import { useLogin } from '@/hooks/useLogin';
import styles from './login.module.scss';

import cmsLogoLarge from '@/assets/clickit-cms-logo-large.png';
import clickitLogo from '@/assets/clickit-logo.png';
import dashBoardImg from '@/assets/clickit-login-page-dashboard.png';
import { LicenseAlertCard } from './LicenseAlertCard';
import { STORAGE_KEYS } from '@/constants/storage';


type LoginFormValues = {
    username: string;
    password: string;
    rememberMe: boolean;
};

const LoginPage: FC = () => {
    const [form] = Form.useForm<LoginFormValues>();
    const navigate = useNavigate();
    const location = useLocation() as { state?: { from?: Location } };

    const { mutate, isPending, error } = useLogin();

    const from = location.state?.from?.pathname || '/';

    // Load username from localStorage
    const savedUsername = localStorage.getItem(STORAGE_KEYS.USERNAME) ?? '';

    const handleFinish: FormProps<LoginFormValues>['onFinish'] = (values) => {
        const { username, password, rememberMe } = values;

        mutate(
            { username, password, rememberMe },
            {
                onSuccess: () => {
                    navigate(from, { replace: true });
                },
                onError: () => {
                    // Clear password field
                    form.resetFields(['password']);
                },
            },
        );
    };

    return (
        <div className={`${styles['cms-login']} login-page min-h-screen w-full flex items-stretch justify-center`}>
            <div className={`flex w-full min-h-screen flex-1 bg-white py-6 `}>
                <div className="flex w-full md:w-1/2 h-full flex-col bg-white xl:px-[120px] px-6">
                    <div className="flex flex-col items-center w-full pt-2 text-center">
                        <div className="flex flex-col items-center whitespace-nowrap">
                            <img src={cmsLogoLarge} alt="Central Management" className="h-auto w-full max-w-[353px]" />

                            <div className="flex items-center justify-center gap-2 mt-1">
                                <span className="text-sm text-cms-text-main shrink-0">Powered by</span>

                                <img src={clickitLogo} alt="ClickIt" className="h-auto h-auto w-full max-w-[125px]" />
                            </div>
                        </div>
                    </div>

                    {false && <LicenseAlertCard
                        status="expiring"
                        daysLeft={5}
                        items={[
                            { label: 'Limited Maintenance Licenses. Remaining', remaining: 5 },
                            { label: 'Limited Store in Store Licenses. Remaining', remaining: 5 },
                        ]}
                    />}
                    <div className="flex flex-col flex-1 justify-center">
                        {error && <div className="cms-error-pill whitespace-pre-line">{(error as Error).message}</div>}
                        <Form
                            form={form}
                            layout="vertical"
                            className="w-full"
                            initialValues={{ username: savedUsername, rememberMe: !!savedUsername }}
                            onFinish={handleFinish}
                        >
                            <Form.Item
                                label="Username"
                                name="username"
                                required={false}
                                rules={[{ required: true, message: 'Please enter your username' }]}
                            >
                                <Input size="large" className={styles['cms-login__input']} />
                            </Form.Item>

                            <Form.Item
                                label="Password"
                                name="password"
                                required={false}
                                rules={[{ required: true, message: 'Please enter your password' }]}
                            >
                                <Input.Password size="large" className={styles['cms-login__input']} />
                            </Form.Item>

                            <div className="mb-6 flex items-center justify-between">
                                <Form.Item name="rememberMe" valuePropName="checked" noStyle>
                                    <Checkbox className={styles['cms-login__checkbox']}>Remember me</Checkbox>
                                </Form.Item>
                            </div>

                            <Form.Item>
                                <Button type="primary" htmlType="submit" size="large" block loading={isPending}>
                                    {isPending ? 'Logging in…' : 'Log In'}
                                </Button>
                            </Form.Item>
                        </Form>
                    </div>

                    <div>
                        <div className="mt-8 text-base font-normal text-center">Copyright 2025 ClickIt Inc.</div>
                    </div>
                </div>

                <div className="hidden h-full w-1/2 md:flex items-center justify-center bg-login-page-blue text-white rounded-[10px] mr-6">
                    <div className="flex w-full flex-col items-start justify-center text-left py-8 md:py-12 lg:py-20 w-[90%]">
                        <div className=" mx-auto justify-center">
                            <div className="mb-6 ml-[43px]">
                                <h2 className="mb-2 text-[32px] font-semibold">Your role, your view!</h2>
                                <p className="text-[32px] font-semibold">Central Management Personalized.</p>
                            </div>
                            <div className="flex">
                                <div className="overflow-hidden">
                                    <img
                                        src={dashBoardImg}
                                        alt="Central Management dashboard preview"
                                        className="block h-auto w-full rounded-[16px] max-h-[480px]"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LoginPage;
