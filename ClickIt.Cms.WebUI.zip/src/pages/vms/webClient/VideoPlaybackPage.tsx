import { useState } from 'react';
import { getImagePath } from '@/utils';
import { FindStoreModal } from '@/components/find-store';

export default function VideoPlaybackPage() {
    const storeIcon = getImagePath('icons/icon-store.png');
    const [isModalOpen, setIsModalOpen] = useState(false);

    const handleStoreSelect = (storeId: string) => {
        console.log('Selected store:', storeId);
        // TODO: Handle store selection - navigate to video playback for selected store
        setIsModalOpen(false);
    };

    return (
        <>
            <section className="flex h-full flex-col bg-cms-bg-main">
                {/* Page title */}
                <div className="px-8 pt-6 pb-4">
                    <h1 className="text-lg font-bold tracking-wide text-cms-text-heading">Video Playback</h1>
                </div>

                {/* Centered content */}
                <div className="flex flex-1 items-start justify-center">
                    <div className="mt-16 flex flex-col items-center">
                        <p className="mb-8 text-sm tracking-wide text-cms-text-main">
                            Select a store to view Video Playback
                        </p>

                        <button
                            type="button"
                            onClick={() => setIsModalOpen(true)}
                            className="group relative flex h-[300px] w-[300px] cursor-pointer items-center justify-center rounded-[10px] bg-cms-bg-main outline-none"
                        >
                            <div className="absolute inset-[24px] rounded-[10px] border border-dashed border-cms-input-stroke-dropdown-hover bg-cms-bg-white transition-colors group-hover:border-cms-input-stroke-active">
                                <div className="flex h-full flex-col items-center justify-center gap-4">
                                    <img src={storeIcon} alt="" className="h-[74px] w-[74px]" />
                                    <span className="text-base font-semibold tracking-wide text-cms-text-main">Select Store</span>
                                </div>
                            </div>
                        </button>
                    </div>
                </div>
            </section>

            <FindStoreModal
                open={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onStoreSelect={handleStoreSelect}
            />
        </>
    );
}








