
import StoreIcon from '@/assets/images/icon-store.png';

const onSelectStoreButtonClick = () => {
};

function SelectArea() {

    const divStyle = {
        cursor: 'pointer',
    }

  return (
    <div className="absolute content-stretch flex items-center  top-[220px]" data-name="Cards">
          <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
              <div className="[grid-area:1_/_1] grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[24px] mt-[29px] place-items-start relative">
                  <div onClick={onSelectStoreButtonClick} style={divStyle} className="[grid-area:1_/_1] bg-white border border-[#4d5154] border-dashed h-[201px] ml-0 mt-0 rounded-[10px] w-[192px]" />
                  <div onClick={onSelectStoreButtonClick} style={divStyle} className="[grid-area:1_/_1] ml-[59px] mt-[59px] relative size-[74px]" data-name="Icons">
                      <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={StoreIcon} />
                  </div>
                  <div className="[grid-area:1_/_1] content-stretch flex items-center justify-center ml-0 mt-[212px] p-[10px] relative w-[192px]">
                      <p className="font-['Open_Sans:SemiBold',sans-serif] font-semibold leading-[1.5] relative shrink-0 text-[#4d5154] text-[16px] text-nowrap tracking-[0.32px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                          Select Store
                      </p>
                  </div>
                  
              </div>
              <div className="[grid-area:1_/_1] bg-[#f4f7fa] h-[300px] ml-0 mt-0 rounded-[10px] w-[240px]" />
          </div>
    </div>
  );
}

export default function SelectAStorePage() {

    const divStyle = {
        display: 'flex',    //  block and inline-block are utterly useless, use 'flex'
        justifyContent: 'center',
        alignItems: 'center',
        width: '100%',
    }

    return (
        <div className="relative size-full">
            <div className="content-stretch flex flex-col items-start relative shrink-0" data-name="Title">
                <p className="font-['Manrope:Bold',sans-serif] font-bold leading-[1.2] relative shrink-0 text-[#2b283d] text-[18px] text-nowrap tracking-[0.36px]">
                    Investigation Builder
                </p>
            </div>

            <div style={divStyle}>
                <p className="absolute font-['Open_Sans:SemiBold',sans-serif] font-semibold leading-[1.3] text-[#4d5154] text-[16px] text-nowrap top-[187px] tracking-[0.32px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                    Select a store to build Investigation
                </p>
                <SelectArea />
          </div>
        </div >

  );
}
