//import type { FC } from 'react';

//  Note:
//
//  These import declarationsare buggy, if you change the last part of the file path it doesn't
//  always find the component even though the path is right...it seems you have to remove the
//  line altogether and re-add it with the new name and then it finds the file
//
import InvestigationModuleOverview from '../../../components/investigation-module/enterprise-overview/InvestigationModuleOverview';
import InvestigationsByMonthChart from '../../../components/investigation-module/enterprise-overview/InvestigationsByMonthChart';

export default function IMEnterpriseOverview() {

    const divStyle = {
        marginBottom: "10px",
    }

    const boldStyle = {
        fontWeight: 600,
    }

    const filler = {
        height: "16px",
    }

  return (
      <div className="bg-#F4F7FA relative size-full w-[1088px]" data-name="IMEnterpriseOverview">
          <div style={divStyle} >
              <span style={boldStyle}>Investigations - Enterprise Overview</span>
          </div>

          {/*TODO: Get the actual data from API call*/}
          <InvestigationModuleOverview
              openTotal={54}
              openVideoAvailable={38}
              openVideoExpiringSoon={12}
              openVideoExpired={4}
              closedTotal={1204}
              closedArchived={204}
              closedDeleted={1000}
              averageDurationInDays={295}
              totalInvestigations={2104}
              yearToDate={204}
          />

          <div style={filler} />
          
          <InvestigationsByMonthChart />
    </div>
  );
}
