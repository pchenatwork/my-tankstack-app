export default function OverviewPage() {
    return (
        <section className="overview-wrap">
          <div className="content-body"></div>
        </section>
    );
}
