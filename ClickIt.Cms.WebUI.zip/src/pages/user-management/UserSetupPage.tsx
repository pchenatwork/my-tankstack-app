import { useQueryClient } from '@tanstack/react-query';
import { DatePicker, Modal, Pagination, Popover, Select, Spin } from 'antd';
import React, { useEffect, useState } from 'react';

import { addUser, deleteUser, doAdd, updateUser } from '@/api';
import { CIButton, CISearchBox, StatusDialog, useAlert } from '@/components/common';
import type { UpSertUserRequest, UserType } from '@/types/user';
import { getImagePath } from '@/utils';

import type { ViewType } from '../../components/user-cards/types';
import UserCard from '../../components/user-cards/UserCard';
import UserDetailsModal from '../../components/user-cards/UserDetailsModal';
import UserEditModal, { type UserFormValues } from '../../components/user-cards/UserEditModal';
import UserList from '../../components/user-cards/UserList';
import ViewToggle from '../../components/user-cards/ViewToggle';
import { AdminAccessLevel } from '@/constants';
import usePagedData from '@/hooks/usePagedData';
import type { PagedRequest, RequestQueryKey } from '@/types/common';
import { useCompanies } from '@/hooks/useCompanies';

type PagedRequestGetUsers = PagedRequest<UserType> & {
    securityLevel: string;
    adminAccess: AdminAccessLevel;
    lastLogin?: string | null;
};

const UserSetupPage: React.FC = () => {
    const queryClient = useQueryClient();
    const { success, error: showError } = useAlert();
    const [view, setView] = useState<ViewType>('grid');

    const [searchTerm, setSearchTerm] = useState('');
    const [filters, setFilters] = useState<PagedRequestGetUsers>({
        securityLevel: 'All',
        adminAccess: AdminAccessLevel.Full,
        lastLogin: null,
        searchingStr: '',
        pageNumber: 1,
        pageSize: 10,
        sortBy: 'fullName',
        //sortOrder: 'asc',
        isDescending: false,
    });

    const myQueryKey: RequestQueryKey<PagedRequestGetUsers> = {
        name: 'users',
        params: filters,
    };

    const { data: usersData, isLoading, isError, error } = usePagedData<UserType>('/users/query', myQueryKey);
    const { data: companies } = useCompanies();

    const [selectedUser, setSelectedUser] = useState<UserType | null>(null);
    const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editingUser, setEditingUser] = useState<UserType | null>(null);
    const [editMode, setEditMode] = useState<'edit' | 'duplicate'>('edit');
    const [statusDialog, setStatusDialog] = useState<{
        open: boolean;
        type: 'success' | 'error';
        title: string;
        message: string;
    }>({
        open: false,
        type: 'success',
        title: '',
        message: '',
    });

    useEffect(() => {
        if (isError || error != null) {
            showError({
                title: 'Failed to load users',
                description: error?.message,
            });
        }
    }, [isError, error]);

    //#region Event Handlers

    const handleUserClick = (user: UserType) => {
        setSelectedUser(user);
        setEditingUser(user);
        setIsDetailsModalOpen(true);
    };

    const handleCloseDetailsModal = () => {
        setIsDetailsModalOpen(false);
    };

    const handleOpenAddUser = () => {
        setEditingUser(null);
        setEditMode('edit');
        setIsEditModalOpen(true);
    };

    const handleCloseEditModal = () => {
        setIsEditModalOpen(false);
        setEditingUser(null);
    };

    const refreshUsers = () => {
        queryClient.invalidateQueries({ queryKey: [myQueryKey.name, myQueryKey.params] });
    };

    const handleDetails = (user: UserType) => {
        setSelectedUser(user);
        setIsDetailsModalOpen(true);
    };

    const handleEdit = (user: UserType) => {
        setEditingUser(user);
        setEditMode('edit');
        setIsEditModalOpen(true);
    };

    const handleDuplicate = (user: UserType) => {
        setEditingUser(user);
        setEditMode('duplicate');
        setIsEditModalOpen(true);
    };

    const handleDelete = (user: UserType) => {
        Modal.confirm({
            title: 'Delete User',
            content: `Are you sure you want to delete "${user.fullName}"?`,
            okText: 'Delete',
            okType: 'danger',
            cancelText: 'Cancel',
            onOk: async () => {
                try {
                    const response = await deleteUser(user.uapid);
                    if (response.isSuccessful) {
                        success({ title: `User "${user.fullName}" has been deleted.` });
                        refreshUsers();
                    } else {
                        showError({ title: 'Failed to delete user', description: response.userMessages?.join('\n') });
                    }
                } catch {
                    showError({ title: 'Failed to delete user' });
                }
            },
        });
    };

    const formatValidationErrors = (userMessages?: unknown[], systemMessages?: unknown[]): string => {
        const errors: string[] = [];

        if (userMessages && Array.isArray(userMessages)) {
            userMessages.forEach((msg) => {
                if (typeof msg === 'string') {
                    errors.push(msg);
                } else if (typeof msg === 'object' && msg !== null && 'message' in msg) {
                    errors.push(String((msg as { message: string }).message));
                }
            });
        }

        if (systemMessages && Array.isArray(systemMessages)) {
            systemMessages.forEach((msg) => {
                if (typeof msg === 'string') {
                    errors.push(msg);
                } else if (typeof msg === 'object' && msg !== null && 'message' in msg) {
                    errors.push(String((msg as { message: string }).message));
                }
            });
        }

        if (errors.length === 0) {
            return 'Please check all required fields are filled correctly.';
        }

        return errors.join('\n');
    };

    const handleSubmitUser2 = async (values: UserFormValues) => {
        const companyId = companies?.payLoad?.find((c) => c.name === values.companyName)?.id || -11;
        const req: UpSertUserRequest = {
            companyId: companyId,
            locationId: -12,
            firstName: values.firstName,
            lastName: values.lastName,
            userName: values.username,
            email: values.email,
            jobTitle: values.jobTitle,
            password: values.password,
            //userGroupId: values.userGroupIds || [],
            // allLocations: values.allLocations || false,
        };

        debugger;
        //const response2 = await addUser2(req);
        const response = await doAdd<UpSertUserRequest>('/users', req);

        if (response.isSuccessful) {
            setStatusDialog({
                open: true,
                type: 'success',
                title: 'Success!',
                message: `User "${values.username}" has been created.`,
            });
            setIsEditModalOpen(false);
            setEditingUser(null);
            refreshUsers();
        } else {
            const errorMessage = formatValidationErrors(response.userMessages, response.systemMessages);
            setStatusDialog({
                open: true,
                type: 'error',
                title: 'Missing Information',
                message: `Before adding this user, please provide the following:\n${errorMessage}`,
            });
        }
    };

    const handleSubmitUser = async (values: UserFormValues) => {
        try {
            if (editMode === 'duplicate' || !editingUser) {
                // Add new user (duplicate or new)
                const response = await addUser({
                    company: values.companyName,
                    entryMethod: values.entryMethod,
                    firstName: values.firstName,
                    lastName: values.lastName,
                    email: values.email,
                    jobTitle: values.jobTitle,
                    username: values.username,
                    password: values.password,
                    securityLevelKey: values.securityLevelKey,
                    adminAccess: values.adminAccess,
                    hiddenCameras: values.hiddenCameras,
                    enableEmail: values.enableEmail,
                });
                if (response.isSuccessful) {
                    setStatusDialog({
                        open: true,
                        type: 'success',
                        title: 'Success!',
                        message: `User "${values.username}" has been created.`,
                    });
                    setIsEditModalOpen(false);
                    setEditingUser(null);
                    refreshUsers();
                } else {
                    const errorMessage = formatValidationErrors(response.userMessages, response.systemMessages);
                    setStatusDialog({
                        open: true,
                        type: 'error',
                        title: 'Missing Information',
                        message: `Before adding this user, please provide the following:\n${errorMessage}`,
                    });
                }
            } else {
                // Update existing user
                const response = await updateUser(editingUser.uapid, {
                    company: values.companyName,
                    entryMethod: values.entryMethod,
                    firstName: values.firstName,
                    lastName: values.lastName,
                    email: values.email,
                    jobTitle: values.jobTitle,
                    username: values.username,
                    password: values.password,
                    securityLevelKey: values.securityLevelKey,
                    adminAccess: values.adminAccess,
                    hiddenCameras: values.hiddenCameras,
                    enableEmail: values.enableEmail,
                });
                if (response.isSuccessful) {
                    setStatusDialog({
                        open: true,
                        type: 'success',
                        title: 'Success!',
                        message: response.userMessages?.join('\n') || `User "${values.username}" has been updated.`,
                    });
                    setIsEditModalOpen(false);
                    setEditingUser(null);
                    refreshUsers();
                } else {
                    const errorMessage = formatValidationErrors(response.userMessages, response.systemMessages);
                    setStatusDialog({
                        open: true,
                        type: 'error',
                        title: 'Missing Information',
                        message: `Before updating this user, please provide the following:\n${errorMessage}`,
                    });
                }
            }
        } catch {
            setStatusDialog({
                open: true,
                type: 'error',
                title: 'Error',
                message: `Failed to ${editMode === 'duplicate' || !editingUser ? 'create' : 'update'} user. Please try again.`,
            });
        }
    };
    //#endregion

    const FilterContent = (
        <div className="w-80 p-4">
            <div className="mb-4">
                <label className="mb-1 block text-sm font-medium text-gray-700">Security Level:</label>
                <Select
                    className="w-full"
                    value={filters.securityLevel}
                    onChange={(val) => setFilters({ ...filters, securityLevel: val })}
                    options={[
                        { value: 'All', label: 'All' },
                        { value: 'Admin', label: 'Admin' },
                        { value: 'User', label: 'User' },
                    ]}
                />
            </div>
            <div className="mb-4">
                <label className="mb-1 block text-sm font-medium text-gray-700">Admin:</label>
                <Select
                    className="w-full"
                    value={filters.adminAccess}
                    onChange={(val) => setFilters({ ...filters, adminAccess: val })}
                    options={[
                        { value: AdminAccessLevel.All, label: 'All' },
                        { value: AdminAccessLevel.Full, label: 'Full' },
                        { value: AdminAccessLevel.Partial, label: 'Partial' },
                        { value: AdminAccessLevel.None, label: 'None' },
                    ]}
                />
            </div>
            <div className="mb-4">
                <label className="mb-1 block text-sm font-medium text-gray-700">Last Login:</label>
                <DatePicker
                    className="w-full"
                    onChange={(_, dateString) => setFilters({ ...filters, lastLogin: dateString as string })}
                />
            </div>
        </div>
    );

    return (
        <div className="min-h-screen p-6">
            {/* Header */}
            <div className="mb-6 flex items-center justify-between">
                <h1
                    style={{
                        fontFamily: 'var(--font-heading)',
                        fontSize: 'var(--font-size-heading)',
                        fontWeight: 700,
                        color: 'var(--color-text-headings)',
                        lineHeight: 1.2,
                        letterSpacing: '0.36px',
                        margin: 0,
                    }}
                >
                    User Configuration
                </h1>
                <CIButton variant="primary1" size="small" onClick={handleOpenAddUser}>
                    New User
                </CIButton>
            </div>

            {/* Main Container with Toolbar and Content */}
            <div
                className="mb-6 bg-white p-4"
                style={{
                    borderRadius: 'var(--container-border-radius)',
                    boxShadow: 'var(--container-shadow)',
                }}
            >
                {/* Toolbar */}
                <div className="mb-4 flex flex-col items-center justify-between md:flex-row">
                    <div className="flex items-center gap-4">
                        <span
                            style={{
                                fontFamily: 'var(--font-body)',
                                fontSize: 'var(--font-size-body)',
                                fontWeight: 400,
                                color: 'var(--color-text-main)',
                                lineHeight: 1.5,
                                letterSpacing: '0.28px',
                            }}
                        >
                            Users: <span style={{ fontWeight: 600 }}>{usersData?.totalCount}</span>
                        </span>
                        <ViewToggle view={view} onChange={setView} />
                    </div>

                    <div className="flex items-center gap-4">
                        <Popover content={FilterContent} trigger="click" placement="bottomRight">
                            <CIButton
                                variant="tertiary"
                                size="small"
                                icon={
                                    <img
                                        src={getImagePath('icons/icon_sort.png')}
                                        alt="Filter"
                                        width={14}
                                        height={14}
                                    />
                                }
                            >
                                Filter
                            </CIButton>
                        </Popover>
                        <CISearchBox
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            onSearch={(v) => setFilters({ ...filters, searchingStr: v ?? '' })}
                            placeholder="Search by Username or Name"
                            size="small"
                            className="w-[316px]"
                        />
                    </div>
                </div>

                {/* Content */}
                {isLoading && (
                    <div className="flex h-64 items-center justify-center">
                        <Spin size="large" />
                    </div>
                )}

                {usersData && view === 'grid' && (
                    <div className="flex flex-wrap gap-6">
                        {usersData?.payLoad?.map((user) => (
                            <UserCard
                                key={user.uapid}
                                user={user}
                                onClick={handleUserClick}
                                onDetails={handleDetails}
                                onEdit={handleEdit}
                                onDuplicate={handleDuplicate}
                                onDelete={handleDelete}
                            />
                        ))}
                    </div>
                )}

                {usersData && view === 'list' && (
                    <UserList
                        users={usersData?.payLoad || []}
                        onUserClick={handleUserClick}
                        onDetails={handleDetails}
                        onEdit={handleEdit}
                        onDuplicate={handleDuplicate}
                        onDelete={handleDelete}
                        onSort={(columnKey, isDescending) => {
                            setFilters({ ...filters, sortBy: columnKey as keyof UserType, isDescending: isDescending });
                        }}
                    />
                )}
            </div>

            {/* Pagination */}
            <div className="mt-6 flex justify-end">
                <Pagination
                    current={filters.pageNumber}
                    pageSize={filters.pageSize}
                    total={usersData?.totalCount || 0}
                    onChange={(page, size) => {
                        setFilters((prev) => ({ ...prev, pageNumber: page, pageSize: size }));
                    }}
                    showSizeChanger
                    showTotal={(total) => `Total ${total} items`}
                />
            </div>

            {/* User Details Modal */}
            {isDetailsModalOpen && (
                <UserDetailsModal
                    user={selectedUser}
                    open={isDetailsModalOpen}
                    onClose={handleCloseDetailsModal}
                    onEdit={handleEdit}
                />
            )}

            {/* Add / Edit User Modal */}
            {isEditModalOpen && (
                <UserEditModal
                    open={isEditModalOpen}
                    mode={editMode === 'duplicate' || !editingUser ? 'add' : 'edit'}
                    initialUser={editingUser ?? undefined}
                    onCancel={handleCloseEditModal}
                    // onSubmit={handleSubmitUser}
                    onSubmit={handleSubmitUser2}
                />
            )}

            {/* Status Dialog */}
            {statusDialog.open && (
                <StatusDialog
                    open={statusDialog.open}
                    type={statusDialog.type}
                    title={statusDialog.title}
                    message={statusDialog.message}
                    onClose={() => setStatusDialog((prev) => ({ ...prev, open: false }))}
                />
            )}
        </div>
    );
};

export default UserSetupPage;
