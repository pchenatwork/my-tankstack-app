import { useQueryClient } from '@tanstack/react-query';
import { DatePicker, Modal, Pagination, Popover, Select, Spin } from 'antd';
import React, { useEffect, useState } from 'react';

import { addUser, deleteUser, updateUser } from '@/api';
import { CIButton, CISearchBox, StatusDialog, useAlert } from '@/components/common';
import type { UserType } from '@/types/user';
import { getImagePath } from '@/utils';

import type { UserFilterState, ViewType } from '../../components/user-cards/types';
import UserCard from '../../components/user-cards/UserCard';
import UserDetailsModal from '../../components/user-cards/UserDetailsModal';
import UserEditModal, { type UserFormValues } from '../../components/user-cards/UserEditModal';
import UserList from '../../components/user-cards/UserList';
import ViewToggle from '../../components/user-cards/ViewToggle';
import { useUsers } from '../../hooks/useUsers';

const UserSetupPage: React.FC = () => {
    const queryClient = useQueryClient();
    const { success, error: showError } = useAlert();
    const [view, setView] = useState<ViewType>('grid');
    const [filter, setFilter] = useState<UserFilterState>({
        securityLevel: 'All',
        admin: 'All',
        lastLogin: null,
        search: '',
    });

    const [pageNumber, setPageNumber] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    const { data, isLoading: loading, isError } = useUsers(pageNumber, pageSize);
    const [users, setUsers] = useState<UserType[]>([]);
    const [totalCount, setTotalCount] = useState(0);
    const [selectedUser, setSelectedUser] = useState<UserType | null>(null);
    const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editingUser, setEditingUser] = useState<UserType | null>(null);
    const [editMode, setEditMode] = useState<'edit' | 'duplicate'>('edit');
    const [statusDialog, setStatusDialog] = useState<{
        open: boolean;
        type: 'success' | 'error';
        title: string;
        message: string;
    }>({
        open: false,
        type: 'success',
        title: '',
        message: '',
    });

    useEffect(() => {
        if (data?.isSuccessful && data.payLoad) {
            setUsers(data.payLoad.items);
            setTotalCount(data.payLoad.totalCount);
        } else if (isError || (data && !data.isSuccessful)) {
            showError({
                title: 'Failed to load users',
                description: data && !data.isSuccessful ? data.userMessages?.join('\n') : undefined,
            });
        }
    }, [data, isError, showError]);

    const handleUserClick = (user: UserType) => {
        setSelectedUser(user);
        setEditingUser(user);
        setIsDetailsModalOpen(true);
    };

    const handleCloseDetailsModal = () => {
        setIsDetailsModalOpen(false);
    };

    const handleOpenAddUser = () => {
        setEditingUser(null);
        setEditMode('edit');
        setIsEditModalOpen(true);
    };

    const handleCloseEditModal = () => {
        setIsEditModalOpen(false);
        setEditingUser(null);
    };

    const refreshUsers = () => {
        queryClient.invalidateQueries({ queryKey: ['users', pageNumber, pageSize] });
    };

    const handleDetails = (user: UserType) => {
        setSelectedUser(user);
        setIsDetailsModalOpen(true);
    };

    const handleEdit = (user: UserType) => {
        setEditingUser(user);
        setEditMode('edit');
        setIsEditModalOpen(true);
    };

    const handleDuplicate = (user: UserType) => {
        setEditingUser(user);
        setEditMode('duplicate');
        setIsEditModalOpen(true);
    };

    const handleDelete = (user: UserType) => {
        Modal.confirm({
            title: 'Delete User',
            content: `Are you sure you want to delete "${user.fullName}"?`,
            okText: 'Delete',
            okType: 'danger',
            cancelText: 'Cancel',
            onOk: async () => {
                try {
                    const response = await deleteUser(user.uapid);
                    if (response.isSuccessful) {
                        success({ title: `User "${user.fullName}" has been deleted.` });
                        refreshUsers();
                    } else {
                        showError({ title: 'Failed to delete user', description: response.userMessages?.join('\n') });
                    }
                } catch {
                    showError({ title: 'Failed to delete user' });
                }
            },
        });
    };

    const formatValidationErrors = (userMessages?: unknown[], systemMessages?: unknown[]): string => {
        const errors: string[] = [];

        if (userMessages && Array.isArray(userMessages)) {
            userMessages.forEach((msg) => {
                if (typeof msg === 'string') {
                    errors.push(msg);
                } else if (typeof msg === 'object' && msg !== null && 'message' in msg) {
                    errors.push(String((msg as { message: string }).message));
                }
            });
        }

        if (systemMessages && Array.isArray(systemMessages)) {
            systemMessages.forEach((msg) => {
                if (typeof msg === 'string') {
                    errors.push(msg);
                } else if (typeof msg === 'object' && msg !== null && 'message' in msg) {
                    errors.push(String((msg as { message: string }).message));
                }
            });
        }

        if (errors.length === 0) {
            return 'Please check all required fields are filled correctly.';
        }

        return errors.join('\n');
    };

    const handleSubmitUser = async (values: UserFormValues) => {
        try {
            if (editMode === 'duplicate' || !editingUser) {
                // Add new user (duplicate or new)
                const response = await addUser({
                    company: values.company,
                    entryMethod: values.entryMethod,
                    firstName: values.firstName,
                    lastName: values.lastName,
                    email: values.email,
                    jobTitle: values.jobTitle,
                    username: values.username,
                    password: values.password,
                    securityLevelKey: values.securityLevelKey,
                    adminAccess: values.adminAccess,
                    hiddenCameras: values.hiddenCameras,
                    enableEmail: values.enableEmail,
                });
                if (response.isSuccessful) {
                    setStatusDialog({
                        open: true,
                        type: 'success',
                        title: 'Success!',
                        message: `User "${values.username}" has been created.`,
                    });
                    setIsEditModalOpen(false);
                    setEditingUser(null);
                    refreshUsers();
                } else {
                    const errorMessage = formatValidationErrors(response.userMessages, response.systemMessages);
                    setStatusDialog({
                        open: true,
                        type: 'error',
                        title: 'Missing Information',
                        message: `Before adding this user, please provide the following:\n${errorMessage}`,
                    });
                }
            } else {
                // Update existing user
                const response = await updateUser(editingUser.uapid, {
                    company: values.company,
                    entryMethod: values.entryMethod,
                    firstName: values.firstName,
                    lastName: values.lastName,
                    email: values.email,
                    jobTitle: values.jobTitle,
                    username: values.username,
                    password: values.password,
                    securityLevelKey: values.securityLevelKey,
                    adminAccess: values.adminAccess,
                    hiddenCameras: values.hiddenCameras,
                    enableEmail: values.enableEmail,
                });
                if (response.isSuccessful) {
                    setStatusDialog({
                        open: true,
                        type: 'success',
                        title: 'Success!',
                        message: response.userMessages?.join('\n') || `User "${values.username}" has been updated.`,
                    });
                    setIsEditModalOpen(false);
                    setEditingUser(null);
                    refreshUsers();
                } else {
                    const errorMessage = formatValidationErrors(response.userMessages, response.systemMessages);
                    setStatusDialog({
                        open: true,
                        type: 'error',
                        title: 'Missing Information',
                        message: `Before updating this user, please provide the following:\n${errorMessage}`,
                    });
                }
            }
        } catch {
            setStatusDialog({
                open: true,
                type: 'error',
                title: 'Error',
                message: `Failed to ${editMode === 'duplicate' || !editingUser ? 'create' : 'update'} user. Please try again.`,
            });
        }
    };

    const filteredUsers = users.filter((user) => {
        const searchTerm = filter.search.toLowerCase();
        const matchesSearch =
            user.fullName.toLowerCase().includes(searchTerm) || user.userName.toLowerCase().includes(searchTerm);

        // Add more filter logic here if needed (security level, etc.)

        return matchesSearch;
    });

    const FilterContent = (
        <div className="w-80 p-4">
            <div className="mb-4">
                <label className="mb-1 block text-sm font-medium text-gray-700">Security Level:</label>
                <Select
                    className="w-full"
                    value={filter.securityLevel}
                    onChange={(val) => setFilter({ ...filter, securityLevel: val })}
                    options={[
                        { value: 'All', label: 'All' },
                        { value: 'Admin', label: 'Admin' },
                        { value: 'User', label: 'User' },
                    ]}
                />
            </div>
            <div className="mb-4">
                <label className="mb-1 block text-sm font-medium text-gray-700">Admin:</label>
                <Select
                    className="w-full"
                    value={filter.admin}
                    onChange={(val) => setFilter({ ...filter, admin: val })}
                    options={[
                        { value: 'All', label: 'All' },
                        { value: 'Full', label: 'Full' },
                        { value: 'Partial', label: 'Partial' },
                        { value: 'None', label: 'None' },
                    ]}
                />
            </div>
            <div className="mb-4">
                <label className="mb-1 block text-sm font-medium text-gray-700">Last Login:</label>
                <DatePicker
                    className="w-full"
                    onChange={(_, dateString) => setFilter({ ...filter, lastLogin: dateString as string })}
                />
            </div>
        </div>
    );

    return (
        <div className="min-h-screen p-6">
            {/* Header */}
            <div className="mb-6 flex items-center justify-between">
                <h1
                    style={{
                        fontFamily: 'var(--font-heading)',
                        fontSize: 'var(--font-size-heading)',
                        fontWeight: 700,
                        color: 'var(--color-text-headings)',
                        lineHeight: 1.2,
                        letterSpacing: '0.36px',
                        margin: 0,
                    }}
                >
                    User Configuration
                </h1>
                <CIButton variant="primary1" size="small" onClick={handleOpenAddUser}>
                    New User
                </CIButton>
            </div>

            {/* Main Container with Toolbar and Content */}
            <div
                className="mb-6 bg-white p-4"
                style={{
                    borderRadius: 'var(--container-border-radius)',
                    boxShadow: 'var(--container-shadow)',
                }}
            >
                {/* Toolbar */}
                <div className="mb-4 flex flex-col items-center justify-between md:flex-row">
                    <div className="flex items-center gap-4">
                        <span
                            style={{
                                fontFamily: 'var(--font-body)',
                                fontSize: 'var(--font-size-body)',
                                fontWeight: 400,
                                color: 'var(--color-text-main)',
                                lineHeight: 1.5,
                                letterSpacing: '0.28px',
                            }}
                        >
                            Users: <span style={{ fontWeight: 600 }}>{filteredUsers.length}</span>
                        </span>
                        <ViewToggle view={view} onChange={setView} />
                    </div>

                    <div className="flex items-center gap-4">
                        <Popover content={FilterContent} trigger="click" placement="bottomRight">
                            <CIButton
                                variant="tertiary"
                                size="small"
                                icon={
                                    <img
                                        src={getImagePath('icons/icon_sort.png')}
                                        alt="Filter"
                                        width={14}
                                        height={14}
                                    />
                                }
                            >
                                Filter
                            </CIButton>
                        </Popover>
                        <CISearchBox
                            value={filter.search}
                            onChange={(e) => setFilter((prev) => ({ ...prev, search: e.target.value }))}
                            placeholder="Search by Username or Name"
                            size="small"
                            className="w-[316px]"
                        />
                    </div>
                </div>

                {/* Content */}
                {loading ? (
                    <div className="flex h-64 items-center justify-center">
                        <Spin size="large" />
                    </div>
                ) : view === 'grid' ? (
                    <div className="flex flex-wrap gap-6">
                        {filteredUsers.map((user) => (
                            <UserCard
                                key={user.uapid}
                                user={user}
                                onClick={handleUserClick}
                                onDetails={handleDetails}
                                onEdit={handleEdit}
                                onDuplicate={handleDuplicate}
                                onDelete={handleDelete}
                            />
                        ))}
                    </div>
                ) : (
                    <UserList
                        users={filteredUsers}
                        onUserClick={handleUserClick}
                        onDetails={handleDetails}
                        onEdit={handleEdit}
                        onDuplicate={handleDuplicate}
                        onDelete={handleDelete}
                    />
                )}
            </div>

            {/* Pagination */}
            <div className="mt-6 flex justify-end">
                <Pagination
                    current={pageNumber}
                    pageSize={pageSize}
                    total={totalCount}
                    onChange={(page, size) => {
                        setPageNumber(page);
                        setPageSize(size);
                    }}
                    showSizeChanger
                    showTotal={(total) => `Total ${total} items`}
                />
            </div>

            {/* User Details Modal */}
            <UserDetailsModal user={selectedUser} open={isDetailsModalOpen} onClose={handleCloseDetailsModal} />

            {/* Add / Edit User Modal */}
            <UserEditModal
                open={isEditModalOpen}
                mode={editMode === 'duplicate' || !editingUser ? 'add' : 'edit'}
                initialUser={editingUser ?? undefined}
                onCancel={handleCloseEditModal}
                onSubmit={handleSubmitUser}
            />

            {/* Status Dialog */}
            <StatusDialog
                open={statusDialog.open}
                type={statusDialog.type}
                title={statusDialog.title}
                message={statusDialog.message}
                onClose={() => setStatusDialog((prev) => ({ ...prev, open: false }))}
            />
        </div>
    );
};

export default UserSetupPage;
