import { Dropdown, Modal, Popover, Select, Space, Table, Tag, Typography, Spin} from 'antd';
import type { ColumnType } from 'antd/es/table';
import React, { useState, useMemo, useCallback } from 'react';
import type { SecurityLevelItem } from '@/types/securityLevel';
import { mapDtoToItem, mapItemToDto } from '@/types/securityLevel';
import AddSecurityLevelModal from '@/components/security-levels/AddSecurityLevelModal';
import type { SecurityLevelFormValues } from '@/components/security-levels/AddSecurityLevelModal';
import { useSecurityLevels, useCreateSecurityLevel, useUpdateSecurityLevel, useDeleteSecurityLevel } from '@/hooks/useSecurityLevels';
import { CIButton, CISearchBox } from '@/components/common';
import { getImagePath } from '@/utils';
import { useAuthStore } from '@/store/authStore';

const { Text } = Typography;

type AdminFilter = 'All' | 'Full' | 'Partial' | 'Non Admin';

type ActionMenuItem = {
    key: string;
    label: React.ReactNode;
    onClick: () => void;
    danger?: boolean;
};

// Constants for icon paths - computed once
const ICON_PATHS = {
    edit: getImagePath('icons/edit_icon.png'),
    duplicate: getImagePath('icons/duplicate_icon.png'),
    delete: getImagePath('icons/delete_icon.png'),
    starFilled: getImagePath('icons/icon-star-filled.png'),
    starHalfFilled: getImagePath('icons/icon-star-half-filled.png'),
    threeDots: getImagePath('icons/3dots.png'),
    sort: getImagePath('icons/icon_sort.png'),
} as const;

// Filter options - constant to avoid recreation
const ADMIN_FILTER_OPTIONS = [
    { value: 'All', label: 'All' },
    { value: 'Full', label: 'Full' },
    { value: 'Partial', label: 'Partial' },
    { value: 'Non Admin', label: 'Non Admin' },
];

const SecurityLevelsPage: React.FC = () => {
    const [searchTerm, setSearchTerm] = useState('');
    const [adminFilter, setAdminFilter] = useState<AdminFilter>('All');
    const [filterOpen, setFilterOpen] = useState(false);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [editingLevel, setEditingLevel] = useState<SecurityLevelItem | null>(null);

    // Current user (for permissions)
    const user = useAuthStore((s) => s.user)?.payLoad?.user;
    const canAdd = user?.canAddSecurityLevels ?? false;
    const canEdit = user?.canEditSecurityLevels ?? false;
    const canDelete = user?.canDeleteSecurityLevels ?? false;

    // Fetch security levels from API
    const { data: securityLevelsResponse, isLoading, error } = useSecurityLevels();
    const createMutation = useCreateSecurityLevel();
    const updateMutation = useUpdateSecurityLevel();
    const deleteMutation = useDeleteSecurityLevel();

    // Convert DTOs to items for display
    const securityLevels = useMemo(() => {
        if (!securityLevelsResponse?.isSuccessful || !securityLevelsResponse?.payLoad) {
            return [];
        }
        return securityLevelsResponse.payLoad.map(mapDtoToItem);
    }, [securityLevelsResponse]);

    const handleEdit = useCallback((record: SecurityLevelItem) => {
        setEditingLevel(record);
        setIsAddModalOpen(true);
    }, []);

    const handleDuplicate = useCallback((record: SecurityLevelItem) => {
        const duplicatedLevel: SecurityLevelItem = {
            ...record,
            id: '', // Will be assigned new ID on save
            name: `${record.name} - Copy`,
            userCount: 0,
            permissionIds: record.permissionIds ?? [],
        };
        setEditingLevel(duplicatedLevel);
        setIsAddModalOpen(true);
    }, []);

    const handleDelete = useCallback((record: SecurityLevelItem) => {
        Modal.confirm({
            title: 'Delete Security Level',
            content: (
                <div>
                    <p>Are you sure you want to delete the security level <strong>"{record.name}"</strong>?</p>
                    <p>This action cannot be undone.</p>
                </div>
            ),
            okText: 'Delete',
            okType: 'danger',
            cancelText: 'Cancel',
            onOk() {
                deleteMutation.mutate(record.id);
            },
        });
    }, [deleteMutation]);

    const handleAddLevel = useCallback((values: SecurityLevelFormValues) => {
        if (editingLevel && editingLevel.id) {
            // Update existing level
            const updatedItem: SecurityLevelItem = {
                ...editingLevel,
                name: values.name,
                description: values.description || undefined,
                backColor: values.backColor,
                foreColor: values.foreColor,
                accessLevel: values.accessLevel, // Use computed accessLevel from form
                permissionIds: values.permissionIds,
                companyId: values.companyId,
            };
            const dto = mapItemToDto(updatedItem);
            updateMutation.mutate(
                { id: editingLevel.id, dto },
                {
                    onSuccess: (data) => {
                        // Only close modal if operation was successful
                        if (data.isSuccessful) {
                            setIsAddModalOpen(false);
                            setEditingLevel(null);
                        }
                    },
                }
            );
        } else {
            // Add new level
            const newItem: SecurityLevelItem = {
                id: '', // Will be generated by backend
                name: values.name,
                description: values.description || undefined,
                userCount: 0,
                backColor: values.backColor,
                foreColor: values.foreColor,
                accessLevel: values.accessLevel, // Use computed accessLevel from form (defaults to N)
                permissionIds: values.permissionIds,
                companyId: values.companyId,
            };
            const dto = mapItemToDto(newItem);
            createMutation.mutate(dto, {
                onSuccess: (data) => {
                    // Only close modal if operation was successful
                    if (data.isSuccessful) {
                        setIsAddModalOpen(false);
                        setEditingLevel(null);
                    }
                },
            });
        }
    }, [editingLevel, updateMutation, createMutation]);

    const handleModalClose = useCallback(() => {
        setIsAddModalOpen(false);
        setEditingLevel(null);
    }, []);

    const getActionItems = useCallback(
        (record: SecurityLevelItem): ActionMenuItem[] => {
            const items: ActionMenuItem[] = [];

            // Show edit option if user has edit permission and record is editable
            if (canEdit) {
                items.push({
                    key: 'edit',
                    label: (
                        <Space size="small">
                            <img src={ICON_PATHS.edit} alt="Edit" width={16} />
                            <span>Edit</span>
                        </Space>
                    ),
                    onClick: () => handleEdit(record),
                });
            }

            // Show duplicate option if user has edit permission and record is editable
            if (canAdd) {
                items.push({
                    key: 'duplicate',
                    label: (
                        <Space size="small">
                            <img src={ICON_PATHS.duplicate} alt="Duplicate" width={16} />
                            <span>Duplicate</span>
                        </Space>
                    ),
                    onClick: () => handleDuplicate(record),
                });
            }

            // Show delete option if user has delete permission and record is editable
            if (canDelete) {
                items.push({
                    key: 'delete',
                    label: (
                        <Space size="small">
                            <img src={ICON_PATHS.delete} alt="Delete" width={16} />
                            <span>Delete</span>
                        </Space>
                    ),
                    onClick: () => handleDelete(record),
                    danger: true,
                });
            }

            return items;
        },
        [handleEdit, handleDuplicate, handleDelete, canEdit, canDelete],
    );

    const columns: ColumnType<SecurityLevelItem>[] = useMemo(() => [
        {
            title: 'Security Level',
            dataIndex: 'name',
            key: 'name',
            sorter: (a: SecurityLevelItem, b: SecurityLevelItem) => {
                return a.name.localeCompare(b.name);
            },
            render: (text: string, record: SecurityLevelItem) => {
                const level = record.accessLevel;
                const isFull = level === 'F';
                const isPartial = level === 'P';

                const starSrc = isFull
                    ? ICON_PATHS.starFilled
                    : isPartial
                        ? ICON_PATHS.starHalfFilled
                        : undefined;
                const alt =
                    level === 'F' ? 'Full Access' : level === 'P' ? 'Partial Access' : 'No Access';

                return (
                    <Space size="small">
                        <Tag
                            variant="filled"
                            className="px-3 !py-1 !text-sm !m-0"
                            style={{
                                backgroundColor: record.backColor,
                                color: record.foreColor || '#FFFFFF',
                            }}
                        >
                            {text}
                        </Tag>
                        {starSrc && (
                            <img
                                src={starSrc}
                                alt={alt}
                                width={20}
                            />
                        )}
                    </Space>
                );
            },
        },
        {
            title: 'Description',
            dataIndex: 'description',
            key: 'description',
            render: (text: string | null | undefined) => (
                <p className="text-sm font-normal text-cms-text-main">{text || ''}</p>
            ),
        },
        {
            title: '# of Users',
            dataIndex: 'userCount',
            key: 'userCount',
            align: 'center' as const,
            render: (count: number) => <p className="text-sm font-normal text-cms-text-main">{count.toLocaleString()}</p>,
        },
        {
            title: 'Actions',
            key: 'actions',
            align: 'center' as const,
            width: 80,
            render: (_: any, record: SecurityLevelItem) => (
                <div className="flex justify-center items-center">
                    <Dropdown menu={{ items: getActionItems(record) }} trigger={['click']} placement="bottomRight">
                        <CIButton variant="tertiary" icon={<img src={ICON_PATHS.threeDots} alt="Actions" width={20} />} />
                    </Dropdown>
                </div>
            ),
        },
    ], [getActionItems]);

    const filteredLevels = useMemo(() => {
        const searchLower = searchTerm.toLowerCase();

        return securityLevels.filter((level) => {
            // Search filter
            const matchesSearch = level.name.toLowerCase().includes(searchLower);

            // Admin filter - simplified logic
            const matchesAdminFilter =
                adminFilter === 'All' ||
                (adminFilter === 'Full' && level.accessLevel === 'F') ||
                (adminFilter === 'Partial' && level.accessLevel === 'P') ||
                (adminFilter === 'Non Admin' && level.accessLevel === 'N');

            return matchesSearch && matchesAdminFilter;
        });
    }, [securityLevels, searchTerm, adminFilter]);

    if (error) {
        return (
            <div className="p-0">
                <div className="text-center p-8">
                    <Text type="danger">Failed to load security levels. Please try again later.</Text>
                </div>
            </div>
        );
    }

    const handleFilterChange = useCallback((value: AdminFilter) => {
        setAdminFilter(value);
        setFilterOpen(false);
    }, []);

    const FilterContent = useMemo(() => (
        <div className="p-0 max-w-[316px]">
            <p className="text-sm font-medium text-cms-text-main">Admin</p>
            <div className="flex items-center justify-between gap-3 pt-1">
                <Select
                    className="min-w-[170px] w-full [&_.ant-select-selector]:!h-[34px] [&_.ant-select-selector]:!border-cms-text-main [&_.ant-select-selector]:!rounded-[7px] [&_.ant-select-selector]:!flex [&_.ant-select-selector]:!items-center"
                    value={adminFilter}
                    onChange={handleFilterChange}
                    options={ADMIN_FILTER_OPTIONS}
                    size="middle"
                    popupMatchSelectWidth={false}
                />
            </div>
        </div>
    ), [adminFilter, handleFilterChange]);

    return (
        <div className="p-0">
            {/* Header */}
            <div className="flex justify-between items-center !mb-4">
                <h4 className="m-0 text-lg leading-[1.2] font-bold">Security Levels</h4>
                {canAdd && (
                    <CIButton variant="primary1" size="small" onClick={() => setIsAddModalOpen(true)}>
                        Add New Level
                    </CIButton>
                )}
            </div>

            {/* Toolbar and Table Container */}
            <div className="bg-cms-bg-white rounded-lg shadow-sm p-2">
                {/* Toolbar */}
                <div className="px-2 py-4">
                    <div className="flex justify-between items-center gap-4 flex-wrap">
                        <Text className="text-sm font-medium flex-shrink-0 whitespace-nowrap">
                            Levels: {filteredLevels.length}
                        </Text>

                        <div className="flex justify-end items-center gap-2 flex-shrink-0">
                            <Popover
                                content={FilterContent}
                                trigger="click"
                                open={filterOpen}
                                onOpenChange={setFilterOpen}
                                placement="bottomRight"
                            >
                                <CIButton
                                    variant="tertiary"
                                    icon={<img src={ICON_PATHS.sort} alt="Filter" width={14} height={14} />}
                                    className="flex-shrink-0"
                                >
                                    <span className="hidden sm:inline">Filter</span>
                                </CIButton>
                            </Popover>

                            <CISearchBox
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                placeholder="Search by Security Level"
                                size="small"
                                className="w-[200px] sm:w-[250px]"
                            />
                        </div>
                    </div>
                </div>

                <div className="p-2 overflow-x-auto overflow-y-visible [&::-webkit-scrollbar]:h-2 [&::-webkit-scrollbar-track]:bg-[#f1f1f1] [&::-webkit-scrollbar-track]:rounded [&::-webkit-scrollbar-thumb]:bg-[#c1c1c1] [&::-webkit-scrollbar-thumb]:rounded [&::-webkit-scrollbar-thumb:hover]:bg-[#a8a8a8]">
                    {/* Table */}
                    <Spin spinning={isLoading}>
                        <Table
                            columns={columns}
                            dataSource={filteredLevels}
                            rowKey="id"
                            pagination={false}
                            showSorterTooltip={false}
                            rowClassName={(_, index) => index % 2 === 0 ? 'bg-white' : 'bg-cms-grid-alternating-row-bg'}
                            components={{
                                body: {
                                    row: (props: any) => (
                                        <tr
                                            {...props}
                                            className={`${props.className} [&:hover>td]:!bg-inherit`}
                                        />
                                    ),
                                },
                            }}
                            scroll={{ x: 'max-content' }}
                            className="security-levels-table"
                        />
                    </Spin>
                </div>
            </div>

            {/* Add/Edit Security Level Modal */}
            <AddSecurityLevelModal
                open={isAddModalOpen}
                onClose={handleModalClose}
                onSubmit={handleAddLevel}
                editingLevel={editingLevel}
            />
        </div>
    );
};

export default SecurityLevelsPage;
