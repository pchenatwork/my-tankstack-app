//////###############  Need to be deleted later ############### //////
import axios from 'axios';

import type { AddUserRequest, ApiResponse, PagedRequestGetUsers, PagedResponseGetUsers, UpdateUserRequest, UserRequest, UserResponse, UserType } from '@/types/user';
import type { GenericApiResponse, PagedResponse } from './types/common';

// Get timezone information for API headers
const getTimezoneHeaders = () => ({
    'X-ClickIt-TimeZone': Intl.DateTimeFormat().resolvedOptions().timeZone,
    'X-ClickIt-UtcOffset': String(new Date().getTimezoneOffset()),
});

const baseURL = import.meta.env.VITE_CI_API_BASE_URL || 'https://localhost:8088';
export const api = axios.create({
    baseURL,
    headers: {
        ...getTimezoneHeaders(),
    },
});

export type TotalSystems = { totalSystems: number; systemsOnline: number; systemsOffline: number };
export type OlderSoftware = { systemCount: number; olderSystemCount: number };
export type CertCount = { certificateCount: number };
export type PatchCount = { securityPatchUpdateCount: number };
export type HighPriorityItem = {
    issueIcon: string;
    issueName: string;
    systemCount: number;
    trendPercent: number;
    trend: 'up' | 'down' | 'flat';
};

export const getTotalSystems = () => api.get<TotalSystems>('/status/total-systems').then((r) => r.data);
export const getOlderSoftware = () => api.get<OlderSoftware>('/status/older-software').then((r) => r.data);
export const getCertificateCount = () => api.get<CertCount>('/status/certificate-count').then((r) => r.data);
export const getSecurityPatchUpdateCount = () =>
    api.get<PatchCount>('/status/security-patch-update-count').then((r) => r.data);
export const getHighPriorityItems = () =>
    api.get<HighPriorityItem[]>('/status/high-priority-items').then((r) => r.data);

export const getUsers = (req: UserRequest) => api.post<UserResponse>('/users/ui', req).then((r) => r.data);

export const addUser = (user: AddUserRequest) => api.post<ApiResponse>('/users/add', user).then((r) => r.data);

export const updateUser = (userId: string | null, user: UpdateUserRequest) =>
    api.put<ApiResponse>(`/users/${userId}`, user).then((r) => r.data);

export const deleteUser = (userId: string | null) => api.delete<ApiResponse>(`/users/${userId}`).then((r) => r.data);

//# introduced to obsolete 'getUsers' above
export const getUsersNew = (req: PagedRequestGetUsers) => api.post<PagedResponseGetUsers>('/users/ui/get-users-pch', req).then((r) => r.data);
