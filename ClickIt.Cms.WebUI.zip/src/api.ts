//////###############  Need to be deleted later ############### //////
import axios from 'axios';

import type { AddUserRequest, UpdateUserRequest, UpSertUserRequest } from '@/types/user';
import type { ApiResponse } from '@/types/common';

// Get timezone information for API headers
const getTimezoneHeaders = () => ({
    'X-ClickIt-TimeZone': Intl.DateTimeFormat().resolvedOptions().timeZone,
    'X-ClickIt-UtcOffset': String(new Date().getTimezoneOffset()),
});

const baseURL = import.meta.env.VITE_CI_API_BASE_URL || 'https://localhost:8088';
export const api = axios.create({
    baseURL,
    headers: {
        ...getTimezoneHeaders(),
    },
});

export type TotalSystems = { totalSystems: number; systemsOnline: number; systemsOffline: number };
export type OlderSoftware = { systemCount: number; olderSystemCount: number };
export type CertCount = { certificateCount: number };
export type PatchCount = { securityPatchUpdateCount: number };
export type HighPriorityItem = {
    issueIcon: string;
    issueName: string;
    systemCount: number;
    trendPercent: number;
    trend: 'up' | 'down' | 'flat';
};

export const getTotalSystems = () => api.get<TotalSystems>('/status/total-systems').then((r) => r.data);
export const getOlderSoftware = () => api.get<OlderSoftware>('/status/older-software').then((r) => r.data);
export const getCertificateCount = () => api.get<CertCount>('/status/certificate-count').then((r) => r.data);
export const getSecurityPatchUpdateCount = () =>
    api.get<PatchCount>('/status/security-patch-update-count').then((r) => r.data);
export const getHighPriorityItems = () =>
    api.get<HighPriorityItem[]>('/status/high-priority-items').then((r) => r.data);

// TODO: PCH obsoleted, use 'usePagedData' hook instead'
// export const getUsers = (req: PagedRequest<UserType>) => api.post<UserResponse>('/users/query', req).then((r) => r.data);

export const addUser = (user: AddUserRequest) => api.post<ApiResponse>('/users/add', user).then((r) => r.data);
export const doAdd = <T>(path: string, data: T) => api.post<ApiResponse>(path, data).then((r) => r.data);
/**
 * Generic Update API call
 * @param path HTTP 'PUT' path in form of '/{resource}/{id}'
 * @param id of the entity to be updated
 * @param data entity to be updated
 * @returns
 */
export const doUpdate = <T>(path: string, id: string | number, data: T) =>
    api.put<ApiResponse>(`${path}/${id}`, data).then((r) => r.data);
/**
 * Generic Delete API call
 * @param path HTTP 'DELETE' path
 * @param id
 * @returns
 */
export const doDelete = (path: string, id: string | number) =>
    api.delete<ApiResponse>(`${path}/${id}`).then((r) => r.data);

export const updateUser = (userId: string | null, user: UpdateUserRequest) =>
    api.put<ApiResponse>(`/users/${userId}`, user).then((r) => r.data);

export const deleteUser = (userId: string | null) => api.delete<ApiResponse>(`/users/${userId}`).then((r) => r.data);
