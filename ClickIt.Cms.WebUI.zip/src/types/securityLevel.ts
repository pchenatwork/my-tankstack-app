import type { AdminAccessLevel } from '../constants';
import type { Company, CompanyResponse } from './company';

// Re-export Company types for backward compatibility
export type { Company, CompanyResponse };

export interface SecurityLevelItem {
    id: string;
    name: string;
    description?: string | null;
    userCount: number;
    backColor: string;
    foreColor?: string;
    /**
     * Overall access level for this security level:
     * F = full, P = partial, N = none
     */
    accessLevel?: AdminAccessLevel;
    permissionIds?: string[];
    companyId?: string;
    permissionsEditable?: boolean;
}

export interface PermissionNodeDto {
    id: string;
    title: string;
    icon?: string | null;
    children: PermissionNodeDto[];
    isAdmin?: boolean;
}

export interface PermissionTreeResponse {
    isSuccessful: boolean;
    payLoad: PermissionNodeDto[];
    userMessages?: any[];
    systemMessages?: any[];
}

// Backend DTO structure (matches actual API response)
export interface SecurityLevelDto {
    id: string;
    name: string;
    description?: string;
    userCount: number;
    backColor: string;
    foreColor: string;
    /**
     * Overall access level for this security level:
     * F = full, P = partial, N = none
     *
     * Frontend does NOT send this on create/update; it is computed by backend
     * from permissionIds and returned in responses.
     */
    accessLevel?: AdminAccessLevel;
    permissionIds: string[];
    companyId?: string;
    permissionsEditable?: boolean;
}


// API Response structure
export interface SecurityLevelResponse {
    isSuccessful: boolean;
    payLoad: SecurityLevelDto[];
    userMessages?: any[];
    systemMessages?: any[];
}

export interface SingleSecurityLevelResponse {
    isSuccessful: boolean;
    payLoad: SecurityLevelDto;
    userMessages?: any[];
    systemMessages?: any[];
}

export interface SecurityLevelRequest {
    pageNumber: number;
    pageSize: number;
}

export interface SecurityLevelFilterState {
    search: string;
    favoriteOnly?: boolean;
}

// Helper function to convert backend DTO to frontend item
export const mapDtoToItem = (dto: SecurityLevelDto): SecurityLevelItem => ({
    id: dto.id,
    name: dto.name,
    description: dto.description,
    userCount: dto.userCount,
    backColor: dto.backColor,
    foreColor: dto.foreColor,
    accessLevel: dto.accessLevel,
    permissionIds: dto.permissionIds ?? [],
    companyId: dto.companyId,
    permissionsEditable: dto.permissionsEditable,
});

// Helper function to convert frontend item to backend DTO
export const mapItemToDto = (item: SecurityLevelItem): SecurityLevelDto => {
    const dto: SecurityLevelDto = {
        id: item.id,
        name: item.name,
        userCount: item.userCount,
        backColor: item.backColor,
        foreColor: item.foreColor || '#FFFFFF',
        permissionIds: item.permissionIds ?? [],
        permissionsEditable: item.permissionsEditable,
    };

    // Only include description if it has a non-empty value
    if (item.description && typeof item.description === 'string' && item.description.trim()) {
        dto.description = item.description;
    }

    // Include companyId if present
    if (item.companyId) {
        dto.companyId = item.companyId;
    }

    // Include accessLevel if present (computed from permissions)
    if (item.accessLevel) {
        dto.accessLevel = item.accessLevel;
    }

    return dto;
};

