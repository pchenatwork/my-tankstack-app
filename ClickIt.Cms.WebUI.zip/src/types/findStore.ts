export interface StoresResponse {
    count: string;
    results: Store[];
}


export interface StoreCoordinates {
    latitude: number;
    longitude: number;
}


export type Store = {
    id: string;     // for now store number will be the id. TODO: change later, should probably come from db or something
    displayName: string;
    storeNumber: string;        
    address: string;
    city: string;
    state: string;
    zipCode: string;
    onlineStatus: boolean;        // whether store is online or offline
    coordinates: StoreCoordinates;
};