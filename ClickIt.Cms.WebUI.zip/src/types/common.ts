export type KeyValuePair<K, V> = {
    key: K;
    value: V;
};

/** Generic option type for HTML dropdowns and selects */
export type Option = {
    label: string;
    value: string | number;
};

export type ApiResponseMessage = {
    level: number | string | null;
    message: string;
};

/** Generic type for API response */
export type ApiResponse<T = void> = {
    isSuccessful: boolean;
    payLoad?: T;
    userMessages?: ApiResponseMessage[];
    systemMessages?: ApiResponseMessage[];
};

export type SortOrder = 'asc' | 'desc';

/** Generic type for paged request to API */
export type PagedRequest<T> = {
    searchingStr?: string;
    pageNumber: number;
    pageSize: number;
    sortBy: keyof T;
    //sortOrder: SortOrder;
    isDescending: boolean;
};

/** Generic type for paged response from API */
export type PagedResponse<T> = {
    payLoad: T[];
    /** Total count after applying filters */
    totalCount: number;
    pageNumber: number;
    pageSize: number;
};

/** Generic type for queryKey parameter used by 'useQuery()' *
 * @param T - Type of the params object send to API
 */
export type RequestQueryKey<T> = {
    name: string;
    params: T;
};
