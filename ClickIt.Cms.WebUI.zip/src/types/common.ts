export type KeyValuePair<K, V> = {
    key: K;
    value: V;
};

export type Option = {
    label: string;
    value: string | number;
};

export type GenericApiResponse<T> = {
    isSuccessful: boolean;
    payLoad?: T;
    userMessages?: any[];
    systemMessages?: any[];
};

export type SortDirection = 'asc' | 'desc';

export type PagedRequest = {
    filterString?: string;
    pageNumber: number;
    pageSize: number;
    sortBy?: string;
    isDescending: boolean;
};

export type PagedResponse<T> = {
    payLoad: T[];
    totalCount: number;
    pageNumber: number;
    pageSize: number;
};
