export interface Company {
    id: number;
    name: string; 
    address1?: string;
    address2?: string;
    city?: string;
    state?: string;
    zip?: string;
    country?: string;
    phone?: string;
    fax?: string;
    emailServer?: string;
    emailAccount?: string;
    emailPassword?: string;
    customPortNumber: number;
    cmsManager?: string;
    extension?: string;
    companyUrl?: string;
    companyLogo?: string;
}

export interface CompanyResponse {
    isSuccessful: boolean;
    payLoad: Company[];
    userMessages?: any[];
    systemMessages?: any[];
}

// Type for company create/update request
export interface CompanyDetailsParameters {
    UAPID: number;
    CompanyId: number;
    Company?: string;
    CompanyName: string;
    Address1?: string;
    Address2?: string;
    City?: string;
    State?: string;
    Zip?: string;
    Phone?: string;
    Ext?: string;
    Fax?: string;
    EmailServer?: string;
    EmailAccount?: string;
    EmailPassword?: string;
    UseSSL: boolean;
    UseCustomPort: boolean;
    EncryptData: boolean;
    AutoLiveIsOn: boolean;
    AutoLiveRefreshSeconds: number;
    AutoUpdateDVRDescription: boolean;
    HideOfflineSystems: boolean;
    CustomPort: number;
    CmsManager?: string;
    EmailEventTypes?: string;
    DvrLogCategories?: string;
    MapZoomLevel?: number;
    MapCenterLatitude?: string;
    MapCenterLongitude?: string;
    IsManagedByClickIt: boolean;
    //AutoLiveHVRLocalTime: string;
    VluSummary: boolean;
    VluReporting: boolean;
    VluPathAnalysis: boolean;
    Country?: string;
    CompanyURL?: string;
    CompanyLogo?: string;
}

