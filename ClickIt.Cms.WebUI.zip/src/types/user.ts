import type { AdminAccessLevel } from '../constants';

export type MenuItem = {
    id?: number;
    order: number;
    text: string;
    isSticky?: boolean;
    tooltip?: string;
    icon: string | null;
    viewOption?: 'N' | 'A' | 'S';
    embedChildren?: boolean;
    route: string | null;
    children: MenuItem[] | null;
};

export type UserType = {
    uapid: string | null;
    userName: string;
    fullName: string;
    firstName: string;
    lastName: string;
    hasFullAccess: boolean;
    accessLevel: AdminAccessLevel;
    isCurrentUser: boolean;
    lastLogin?: string;
    securityLevel: SecurityLevel;
    companyName?: string;
    email?: string;
    jobTitle?: string;
    activeSince?: string;
    canAddSecurityLevels: boolean;
    canEditSecurityLevels: boolean;
    canDeleteSecurityLevels: boolean;
};

export type UserPayload = {
    user: UserType;
    permissions?: MenuItem[];
    viewOptionIcons: {
        companyIconId: number;
        regionIconId: number;
        districtIconId: number;
        storeIconId: number;
    };
};

export type UserProfile = {
    isSuccessful: boolean;
    payLoad: UserPayload;
    userMessages?: string[];
    systemMessages?: string[];
};

export type UserMessageResponse = {
    level: number;
    message: string;
    returnCode: string | null;
};

export type LoginResponse = {
    userMessages: UserMessageResponse[];
    systemMessages: any;
    isSuccessful: boolean;
};

export type SecurityLevel = {
    name: string;
    /**
     * Overall access level for this user's security level:
     * F = full, P = partial, N = none
     */
    accessLevel: AdminAccessLevel;
    backColor: string;
    foreColor?: string;

    hasFullAccess: boolean;
    hasPartialAccess: boolean;
};

export type User = {
    apiUserId: string;
    userName: string;
    fullName: string;
    securityLevel: SecurityLevel;
    lastLogin: string;
    email?: string;
    companyName?: string;
    jobTitle?: string;
    activeSince?: string;
    isCurrentUser?: boolean;
};

/** TODO: Obsoluted, generic PagedRequest<> was introduced
export type UserRequest = {
    pageNumber: number;
    pageSize: number;
};
// Obsoluted. use generic ApiResponse<PagedResponse<UserType>> instead
export type UserResponse = {
    isSuccessful: boolean;
    payLoad: {
        items: UserType[];
        totalCount: number;
    };
    // TODO: Define the structure of userMessages and systemMessages when being used
    userMessages: any[];
    systemMessages: any[];
};
 */

export type AddUserRequest = {
    company?: string;
    entryMethod?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    jobTitle?: string;
    username?: string;
    password?: string;
    securityLevelKey?: string;
    adminAccess?: AdminAccessLevel;
    hiddenCameras?: string[];
    enableEmail?: boolean;
};

export type UpdateUserRequest = {
    company?: string;
    entryMethod?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    jobTitle?: string;
    username?: string;
    password?: string;
    securityLevelKey?: string;
    adminAccess?: AdminAccessLevel;
    hiddenCameras?: string[];
    enableEmail?: boolean;
};

/**
 * Type for user create/update request, matched to 'InsertUpdateUserRequest' DTO in the API
 */
export type UpSertUserRequest = {
    companyId: number;
    locationId: number;
    firstName: string;
    lastName: string;
    email: string;
    jobTitle: string;
    userName: string;
    password: string;
    /*
    userGroupId: number[];
    allLocations: boolean;
    securityLevelId?: number;
    hasFullAccess?: boolean;
    adminAccess?: string;
    */
};
