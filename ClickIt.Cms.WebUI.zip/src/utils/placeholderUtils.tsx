import React from 'react';

export function createPlaceholder(title: string) {
  const Page: React.FC = () => (
    <div style={{ padding: 16 }}>
      <h2 style={{ margin: '10px 0', color: 'var(--color-text-strong)' }}>{title}</h2>
      <p style={{ color: 'var(--color-text)' }}>This page is a placeholder. Content coming soon.</p>
    </div>
  );
  Page.displayName = title.replace(/\s+/g, '') + 'Page';
  return Page;
}

