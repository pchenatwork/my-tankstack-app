/**
 * Get the correct path for assets in the public folder.
 * Handles base path for both development and production environments.
 *
 * @param path - Asset path relative to public folder (e.g., "icons/edit.png")
 * @returns Full path with correct base URL prefix
 */
export const getImagePath = (path: string): string => {
    // Remove leading slash if present to ensure relative path
    const cleanPath = path.startsWith('/') ? path.slice(1) : path;
    return `${import.meta.env.VITE_CI_APP_BASE_URL}/${cleanPath}`;
};
