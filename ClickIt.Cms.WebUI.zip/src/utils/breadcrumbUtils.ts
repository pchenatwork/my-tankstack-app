import type { MenuItem } from '@/types/user';

// Cache for slug generation to avoid repeated string operations
const slugCache = new Map<string, string>();

/**
 * Generate slug from text (cached)
 */
function getSlug(text: string): string {
  if (slugCache.has(text)) {
    return slugCache.get(text)!;
  }
  const slug = text.toLowerCase().replace(/\s+/g, '-');
  slugCache.set(text, slug);
  return slug;
}

/**
 * Builds a route-to-label map from the permissions tree.
 * 
 * This map includes:
 * - Direct route mappings (e.g., "vms/web-client/live-view" -> "Live View")
 * - Parent segment mappings by extracting from full routes (e.g., "vms" -> "VMS", "vms/web-client" -> "Web Client")
 * 
 * @param permissions - Array of MenuItem from permissions data
 * @returns Map where key is route path and value is the label text
 */
export function buildRouteMap(permissions: MenuItem[] | undefined): Map<string, string> {
  const routeMap = new Map<string, string>();

  if (!permissions || permissions.length === 0) {
    return routeMap;
  }

  /**
   * Recursively traverse the permissions tree and build the route map
   * Tracks parent items to build segment mappings
   * Optimized to reduce string operations and array copying
   */
  function traverse(
    items: MenuItem[],
    parentPathSegments: string[] = [],
    parentLabels: string[] = []
  ): void {
    for (const item of items) {
      // Skip sticky items (view option icons) as they don't have routes
      if (item.isSticky) {
        continue;
      }

      const currentLabel = item.text;
      let currentPathSegments: string[];

      if (item.route) {
        // Item has explicit route - use it
        currentPathSegments = item.route.split('/').filter(Boolean);
        // Map the full route to this item's text
        routeMap.set(item.route, currentLabel);

        // Map parent segments by matching route segments to parent items
        // Build segment paths incrementally to avoid repeated joins
        let segmentPath = '';
        for (let i = 0; i < currentPathSegments.length - 1; i++) {
          segmentPath = segmentPath 
            ? `${segmentPath}/${currentPathSegments[i]}`
            : currentPathSegments[i];
          
          // If already mapped, skip
          if (routeMap.has(segmentPath)) {
            continue;
          }

          // Match segment index to parent item index
          if (i < parentLabels.length) {
            // Use the corresponding parent item's label
            routeMap.set(segmentPath, parentLabels[i]);
          }
        }
      } else {
        // Item doesn't have route - build path from hierarchy
        const slug = getSlug(currentLabel);
        currentPathSegments = parentPathSegments.length > 0
          ? [...parentPathSegments, slug]
          : [slug];
      }

      // Build current path string once
      const currentPathStr = currentPathSegments.join('/');
      
      // Build new parent arrays (only when needed for recursion)
      const newParentPathSegments = currentPathSegments;
      const newParentLabels = [...parentLabels, currentLabel];

      // If no route exists for this path yet, add it (for items without explicit routes)
      if (!item.route && !routeMap.has(currentPathStr)) {
        routeMap.set(currentPathStr, currentLabel);
      }

      // Recursively process children
      if (item.children && item.children.length > 0) {
        traverse(item.children, newParentPathSegments, newParentLabels);
      }
    }
  }

  traverse(permissions);
  return routeMap;
}

/**
 * Gets the label for a route path from the route map, with fallback formatting
 * 
 * @param routePath - The route path to look up (e.g., "vms/web-client")
 * @param routeMap - The route-to-label map
 * @param fallbackSegment - The last segment to format if not found in map
 * @returns The label text
 */
export function getRouteLabel(
  routePath: string,
  routeMap: Map<string, string>,
  fallbackSegment: string
): string {
  // Try exact match first
  const label = routeMap.get(routePath);
  if (label !== undefined) {
    return label;
  }

  // Fallback: format the last segment
  return fallbackSegment
    .replace(/-/g, ' ')
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

