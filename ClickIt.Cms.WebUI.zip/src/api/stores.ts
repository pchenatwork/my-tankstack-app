import axios from 'axios';
import type { StoresResponse } from '@/types/findStore';


/**
 * Create a separate axios instance for the stores API
 * since it uses a different base URL
 */
const storesApi = axios.create({
    baseURL: '/dummy-stores-api',       // TODO: change to env
    headers: {
        'Content-Type': 'application/json',
        
    },
    timeout: 30000, // 30 seconds timeout
});

/**
 * Fetch stores from the API
 * @param query - Optional query string for filtering stores
 * @returns Promise with stores response
 */
export const getStores = async (query?: string): Promise<StoresResponse> => {
    const params = query ? { query } : {};
    const res = await storesApi.get<StoresResponse>('/stores', { params });
    return res.data;
};


