import axios from 'axios';

// Get timezone information for API headers (conditionally included based on env)
const getTimezoneHeaders = () => {
    if (import.meta.env.VITE_CI_INCLUDE_TIMEZONE_HEADERS) {
        return {
            'X-ClickIt-TimeZone': Intl.DateTimeFormat().resolvedOptions().timeZone,
            'X-ClickIt-UtcOffset': String(new Date().getTimezoneOffset()),
        };
    }
    return {};
};

export const api = axios.create({
    baseURL: import.meta.env.VITE_CI_API_BASE_URL ?? '/ci-api',
    withCredentials: true,
    headers: {
        'Content-Type': 'application/json',
        ...getTimezoneHeaders(),
    },
    timeout: 30000, // 30 seconds timeout
});
