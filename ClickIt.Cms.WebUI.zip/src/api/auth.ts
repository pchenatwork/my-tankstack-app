import { api } from './client';
import type { UserProfile, LoginResponse, UserMessageResponse } from '@/types/user';

export type LoginPayload = {
  username: string;
  password: string;
};

/**
 * frame user messages into strings
 * @param messages 
 * @param fallback 
 * @returns 
 */
const getMessages = (messages?: UserMessageResponse[], fallback = 'Request failed') : string[] => {
  if (!messages || messages.length === 0) return [fallback];
  return messages.map((m) => m.message);
};

/**
 * Handle login method result. Login method will return 200 OK with isSuccessful false.
 * @param data 
 * @param fallbackMessage 
 * @returns 
 */
const ensureAuthSuccess = (data: LoginResponse, fallbackMessage: string): LoginResponse => {
  if (data.isSuccessful) return data;
  const messages = getMessages(data.userMessages, fallbackMessage);
  throw new Error(messages.join('\n'));
};

/**
 * Authentication API methods
 */
export const auth = {
  /**
   * Login user post request
   * @param payload 
   * @returns 
   */
  login: async (payload: LoginPayload): Promise<LoginResponse> => {
    const res = await api.post<LoginResponse>('/authentication', payload);
    return ensureAuthSuccess(res.data, 'Login failed');
  },

  /**
   * Get user profile and permissions
   * @returns 
   */
  profile: async (): Promise<UserProfile> => {
    const res = await api.get<UserProfile>('/users/permissions');
    return res.data;
  },

  /**
   * Logout user
   */
  logout: async (): Promise<any> => {
    await api.post('/authentication/logout');
  }
};
