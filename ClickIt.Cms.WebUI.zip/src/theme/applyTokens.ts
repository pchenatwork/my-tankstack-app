// src/theme/applyTokens.ts
import { tokens } from './tokens';

// Build a CSS var name from a path of keys, e.g. ['colors', 'brandClickitBlue']
// => --cms-brand-clickit-blue   (we drop the leading "colors" segment on purpose)
const cssVarName = (path: string[]) => {
  const withoutRootPrefix =
    path[0] === 'colors' && path.length > 1 ? path.slice(1) : path;

  const joined = withoutRootPrefix.join('-'); // e.g. "brandClickitBlue"
  const kebab = joined.replace(/[A-Z]/g, (m) => '-' + m.toLowerCase()); // brand-clickit-blue

  return `--cms-${kebab}`;
};

export const applyTokensToCssVars = () => {
  const root = document.documentElement;

  const walk = (obj: unknown, path: string[] = []) => {
    if (!obj || typeof obj !== 'object') return;

    Object.entries(obj as Record<string, unknown>).forEach(([key, value]) => {
      const nextPath = [...path, key];

      if (typeof value === 'string' || typeof value === 'number') {
        // String/number-like token -> write CSS var
        root.style.setProperty(cssVarName(nextPath), String(value));
      } else if (value && typeof value === 'object') {
        // Nested object -> recurse
        walk(value, nextPath);
      }
    });
  };

  walk(tokens);
};
