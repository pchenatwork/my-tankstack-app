type Hex = `#${string}`;

export type Tokens = Readonly<{
    colors: {
        //
        // Brand
        //
        brandClickitBlue: Hex;
        brandScrollBar: Hex;
        brandCardSelectedBg: Hex;

        //
        // Section Line
        //
        sectionLineDefault: Hex;
        sectionLineActive: Hex;

        //
        // Backgrounds
        //
        bgMain: Hex;
        bgWhite: Hex;
        bgSidePanelOptions: Hex;
        bgAddWidget: Hex;
        bgWarningSoft: Hex;

        //
        // Grid
        //
        gridAlternatingRowBg: Hex;
        gridHeader1Bg: Hex;
        gridLinesColor: Hex;
        gridHeader2Bg: Hex;

        //
        // Text
        //
        textMain: Hex;
        textHeading: Hex;
        textHyperlink: Hex;
        textOffline: Hex;
        textExplanatory: Hex;
        textSelectedSidePanel: Hex;
        textInactive: Hex;
        textWhite: Hex;

        //
        // Trend
        //
        trendNegativeBg: Hex;
        trendNegativeText: Hex;
        trendPositiveBg: Hex;
        trendPositiveText: Hex;
        trendStableBg: Hex;
        trendStableText: Hex;

        //
        // Charts
        //
        chartBlue: Hex;
        chartGreen: Hex;
        chartLightBlue: Hex;
        chartOrange1: Hex;
        chartOrange2: Hex;
        chartOrange3: Hex;
        chartGrey: Hex;
        chartPurple1: Hex;
        chartPurple2: Hex;
        chartRed: Hex;
        chartYellow: Hex;
        chartMaroon: Hex;

        //
        // Side Panel
        //
        sidePanelViewOptionSelectedBg: Hex;
        sidePanelExpandedBg: Hex;
        sidePanelHoverPressedBg: Hex;
        sidePanelSelectedBg: Hex;
        sidePanelMenuOptionsLine: Hex;
        sidePanelMenuOptionsLineSelected: Hex;

        //
        // Tabs
        //
        tabSelectedBg: Hex;
        tabActiveBg: Hex;
        tabDefaultBg: Hex;
        tabHoverBg: Hex;

        //
        // Radio
        //
        radioUnselectedBg: Hex;
        radioUnselectedStroke: Hex;
        radioSelectedBg: Hex;
        radioSelectedStroke: Hex;

        //
        // Toggle
        //
        toggleOn: Hex;
        toggleOff: Hex;

        //
        // Primary Button
        //
        btnPrimaryDefaultBg: Hex;
        btnPrimaryHoverBg: Hex;
        btnPrimaryActiveBg: Hex;
        btnPrimaryDisabledBg: Hex;
        btnPrimaryLoadingBg: Hex;
        btnPrimaryStroke: Hex;

        //
        // Secondary Button
        //
        btnSecondaryDefaultTextStroke: Hex;
        btnSecondaryHoverTextStroke: Hex;
        btnSecondaryHoverBg: Hex;
        btnSecondaryActiveTextStroke: Hex;
        btnSecondaryActiveBg: Hex;
        btnSecondaryLoadingTextStroke: Hex;
        btnSecondaryTextDisabled: Hex;

        //
        // Input / Dropdown
        //
        inputStrokeDefault: Hex;
        inputStrokeActive: Hex;
        inputStrokeError: Hex;
        inputFillInactive: Hex;
        inputStrokeDropdownHover: Hex;

        //
        // Tag
        //
        tagBg: Hex;

        //
        // Security Levels
        //
        levelYellow: Hex;
        levelMaroon: Hex;
        levelGreen: Hex;
        levelPurple: Hex;
        levelOrange: Hex;
        levelBlue: Hex;
        levelGrey: Hex;
        levelRed: Hex;

        //
        // Login Page
        //
        loginBlue: Hex;

        alertWarningBg: Hex;
    };
}>;

export const tokens: Tokens = {
    colors: {
        //
        // Brand
        //
        brandClickitBlue: '#0478C0',
        brandScrollBar: '#797B7C',
        brandCardSelectedBg: '#F0F7FF',

        //
        // Section Line
        //
        sectionLineDefault: '#D8D8D8',
        sectionLineActive: '#0168A7',

        //
        // Backgrounds
        //
        bgMain: '#F4F7FA',
        bgWhite: '#FFFFFF',
        bgSidePanelOptions: '#F5F5F5',
        bgAddWidget: '#E5EBF0',
        bgWarningSoft: '#FFF3F3',

        //
        // Grid
        //
        gridAlternatingRowBg: '#F5F5F5',
        gridHeader1Bg: '#DEDEDE',
        gridLinesColor: '#C6C6C6',
        gridHeader2Bg: '#0168A7',

        //
        // Text
        //
        textMain: '#4D5154',
        textHeading: '#2B283D',
        textHyperlink: '#0168A7',
        textOffline: '#FF0000',
        textExplanatory: '#7A7C7F',
        textSelectedSidePanel: '#110D59',
        textInactive: '#C8C8C8',
        textWhite: '#FFFFFF',

        //
        // Trends
        //
        trendNegativeBg: '#FFE1E2',
        trendNegativeText: '#FF0000',
        trendPositiveBg: '#D6EFEA',
        trendPositiveText: '#009908',
        trendStableBg: '#ECECEC',
        trendStableText: '#8A8A8A',

        //
        // Charts
        //
        chartBlue: '#0168A7',
        chartGreen: '#00AA28',
        chartLightBlue: '#4ABDE8',
        chartOrange1: '#FFCB84',
        chartOrange2: '#FFAE41',
        chartOrange3: '#F47600',
        chartGrey: '#D9D9D9',
        chartPurple1: '#0F01A3',
        chartPurple2: '#6200FF',
        chartRed: '#FF0000',
        chartYellow: '#FFE45A',
        chartMaroon: '#BF0484',

        //
        // Side Panel
        //
        sidePanelViewOptionSelectedBg: '#FFE45A',
        sidePanelExpandedBg: '#ACF450',
        sidePanelHoverPressedBg: '#F0F7FF',
        sidePanelSelectedBg: '#D9F2FF',
        sidePanelMenuOptionsLine: '#D8D8D8',
        sidePanelMenuOptionsLineSelected: '#110D59',

        //
        // Tabs
        //
        tabSelectedBg: '#D9EDFF',
        tabActiveBg: '#ECF5FA',
        tabDefaultBg: '#F4F7FA',
        tabHoverBg: '#F0F0F0',

        //
        // Radio
        //
        radioUnselectedBg: '#FFFFFF',
        radioUnselectedStroke: '#AAAAAA',
        radioSelectedBg: '#F4F7FA',
        radioSelectedStroke: '#00598F',

        //
        // Toggle
        //
        toggleOn: '#0168A7',
        toggleOff: '#AFAFAF',

        //
        // Primary Button
        //
        btnPrimaryDefaultBg: '#054682',
        btnPrimaryHoverBg: '#07599E',
        btnPrimaryActiveBg: '#043A69',
        btnPrimaryDisabledBg: '#D9D9D9',
        btnPrimaryLoadingBg: '#054682',
        btnPrimaryStroke: '#054682',

        //
        // Secondary Button
        //
        btnSecondaryDefaultTextStroke: '#054682',
        btnSecondaryHoverTextStroke: '#07599E',
        btnSecondaryHoverBg: '#F0F6FA',
        btnSecondaryActiveTextStroke: '#043A69',
        btnSecondaryActiveBg: '#E6EFF5',
        btnSecondaryLoadingTextStroke: '#054682',
        btnSecondaryTextDisabled: '#D9D9D9',

        //
        // Inputs
        //
        inputStrokeDefault: '#AAAAAA',
        inputStrokeActive: '#0168A7',
        inputStrokeError: '#FF4D4F',
        inputFillInactive: '#F5F5F5',
        inputStrokeDropdownHover: '#4D5154',

        //
        // Tag
        //
        tagBg: '#E6F4FF',

        //
        // Levels
        //
        levelYellow: '#FBD75A',
        levelMaroon: '#BF0484',
        levelGreen: '#009908',
        levelPurple: '#5655D7',
        levelOrange: '#F18524',
        levelBlue: '#007BFF',
        levelGrey: '#D9D9D9',
        levelRed: '#FF0000',

        //
        // Login
        //
        loginBlue: '#00578D',
        alertWarningBg: '#FFEED6',
    },
};
