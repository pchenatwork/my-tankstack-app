// src/theme/antdTheme.ts
import type { ThemeConfig } from 'antd';
import { tokens } from './tokens';

export const antdTheme: ThemeConfig = {
    token: {
        fontFamily:
            "'Open Sans', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif",
        colorPrimary: tokens.colors.brandClickitBlue,
        colorText: tokens.colors.textMain,
        colorBgBase: tokens.colors.bgMain,
    },
    components: {
        Menu: {
            itemHoverBg: tokens.colors.sidePanelHoverPressedBg,
            itemActiveBg: tokens.colors.sidePanelSelectedBg,
            itemSelectedColor: tokens.colors.sidePanelSelectedBg,
            horizontalItemHoverColor: tokens.colors.sidePanelHoverPressedBg,
            colorText: '#1a1a1a',
        },
        Button: {
            // PRIMARY (type="primary")
            colorPrimary: tokens.colors.btnPrimaryDefaultBg,
            colorPrimaryHover: tokens.colors.btnPrimaryHoverBg,
            colorPrimaryActive: tokens.colors.btnPrimaryActiveBg,
            primaryShadow: 'none',

            // DEFAULT / SECONDARY (type="default")
            defaultColor: tokens.colors.btnSecondaryDefaultTextStroke,
            defaultBorderColor: tokens.colors.btnSecondaryDefaultTextStroke,
            defaultBg: '#ffffff',
            defaultHoverBg: tokens.colors.btnSecondaryHoverBg,
            defaultHoverColor: tokens.colors.btnSecondaryHoverTextStroke,
            defaultActiveBg: tokens.colors.btnSecondaryActiveBg,
            defaultActiveColor: tokens.colors.btnSecondaryLoadingTextStroke,

            // Disabled
            colorTextDisabled: tokens.colors.btnPrimaryDisabledBg,
            colorBgContainerDisabled: tokens.colors.btnPrimaryDisabledBg,
            colorPrimaryBgHover: tokens.colors.btnPrimaryHoverBg,
            //   colorBorderDisabled: tokens.colors.btnPrimaryDisabledBg,


            // Border and styling
            borderRadius: 4,
            fontWeight: 600,
            borderColorDisabled: tokens.colors.btnSecondaryTextDisabled,

            // Button content font sizes
            contentFontSize: 14,
            contentFontSizeSM: 12,
            contentFontSizeLG: 14,

            // Button heights
            controlHeight: 34, // Medium
            controlHeightSM: 32, // Small
            controlHeightLG: 44, // Large (if needed)

            // Button padding
            paddingInline: 16,
            paddingInlineSM: 12,
            paddingInlineLG: 20,
        },
        Form: {
            labelFontSize: 16,
        },
        Avatar: {
            textFontSize: 12,
            textFontSizeSM: 12,
            textFontSizeLG: 26,
            containerSize: 28,
            containerSizeSM: 28,
            containerSizeLG: 48,
        },
        Table: {
            headerBg: tokens.colors.gridHeader1Bg,
            // colorBgContainer: tokens.colors.bgWhite,
            rowHoverBg: 'transparent', // Disable row hover background
            cellPaddingBlock: 8,
            cellPaddingInline: 12,
        },
        Alert: {
            colorSuccess: tokens.colors.trendPositiveText,
            colorSuccessBg: tokens.colors.trendPositiveBg,
            colorError: tokens.colors.trendNegativeText,
            colorErrorBg: tokens.colors.trendNegativeBg,
            colorWarning: tokens.colors.chartOrange3,
            colorWarningBg: tokens.colors.alertWarningBg,
            colorText: tokens.colors.trendPositiveText,
        },
        Tooltip: {
            colorBgSpotlight: tokens.colors.bgWhite,
            colorText: tokens.colors.textMain,
            colorTextLightSolid: tokens.colors.textMain
        }
    },
};
