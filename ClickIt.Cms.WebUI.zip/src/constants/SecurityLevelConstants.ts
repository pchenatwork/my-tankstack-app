export const SecurityLevelConstants = {
    MaxLength_Name: 50,
    MaxLength_Description: 150,
} as const;
