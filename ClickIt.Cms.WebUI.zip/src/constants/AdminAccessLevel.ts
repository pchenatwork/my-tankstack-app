export const AdminAccessLevel = {
    Full: 'F',
    Partial: 'P',
    None: 'N',
    All: 'A'
} as const;

export type AdminAccessLevel = (typeof AdminAccessLevel)[keyof typeof AdminAccessLevel];


