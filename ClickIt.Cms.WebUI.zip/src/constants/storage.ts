// src/constants/storage.ts
export const STORAGE_KEYS = {
  USERNAME: 'cms_username'
} as const;
