import { Outlet } from 'react-router-dom';
import { useEffect, useState } from 'react';
import Sidebar from './components/Sidebar';
import HeadBar from './components/headbar/HeadBar';


export default function Layout() {
    const [collapsed, setCollapsed] = useState(false);
    const [mobile, setMobile] = useState(false);
    const [view, setView] = useState<string>('global');

    useEffect(() => {
        const mq = window.matchMedia('(max-width: 768px)');
        const handler = (e: MediaQueryListEvent | MediaQueryList) => {
            const m = 'matches' in e ? e.matches : (e as MediaQueryList).matches;
            setMobile(m);
            setCollapsed(m); // collapsed by default on mobile
        };
        handler(mq);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        if ('addEventListener' in mq) mq.addEventListener('change', handler as any);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        else (mq as any).addListener(handler);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        return () => {
            if ('removeEventListener' in mq)
                mq.removeEventListener('change', handler as any); // eslint-disable-next-line @typescript-eslint/no-explicit-any
            else (mq as any).removeListener(handler);
        };
    }, []);

    return (
        <div className={`app-shell ${collapsed ? 'collapsed' : 'sidebar-open'}`}>
            <Sidebar
                collapsed={collapsed}
                onCollapse={() => setCollapsed(!collapsed)}
                mobile={mobile}
                view={view}
                onViewChange={setView}
            />

            <section className="content">
              <HeadBar></HeadBar>
                <main className="main">
                    <Outlet />
                </main>
                {!collapsed && <div className="scrim" onClick={() => setCollapsed(true)}></div>}
            </section>
        </div>
    );
}
