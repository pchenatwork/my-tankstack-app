/** @type {import('tailwindcss').Config} */
module.exports = {
  // Files Tailwind scans for class names
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
    "./src/styles/**/*.{scss}",
  ],

  // IMPORTANT: Set to true to ensure Tailwind utilities override Ant Design when needed
  // This helps resolve CSS specificity conflicts
  important: true,

  // Design tokens / theme customizations
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "#1677ff",
        },
      }
    },
  },

  // Disable preflight to avoid conflicts with Ant Design's base styles
  corePlugins: {
    preflight: false,
  },

  // Extra plugins (optional)
  plugins: [
    // require("@tailwindcss/forms"),
    // require("@tailwindcss/typography"),
    // require("@tailwindcss/aspect-ratio"),
  ],
};
